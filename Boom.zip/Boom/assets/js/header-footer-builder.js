/**
 * Boom Header & Footer Builder - admin drag & drop
 * چیدمان ویجت‌ها در ناحیه‌ها، مودال تنظیمات، و serialize به input مخفی.
 */
jQuery(document).ready(function ($) {
    'use strict';

    if (typeof hfbData === 'undefined') return;

    var LABELS = $.extend({}, hfbData.headerLabels, hfbData.footerLabels);

    // اسکیمای فیلدهای هر ویجت (ویجت‌های بدون فیلد، دکمه تنظیمات ندارند)
    var WIDGET_FIELDS = {
        logo: [{ key: 'height', label: 'ارتفاع لوگو (px)', type: 'number' }],
        search: [{ key: 'placeholder', label: 'متن پیش‌فرض', type: 'text' }],
        megamenu: [{ key: 'label', label: 'برچسب دکمه', type: 'text' }],
        custom_html: [{ key: 'html', label: 'کد HTML', type: 'textarea' }],
        spacer: [{ key: 'width', label: 'عرض (px)', type: 'number' }],
        text: [
            { key: 'title', label: 'عنوان (اختیاری)', type: 'text' },
            { key: 'content', label: 'متن', type: 'textarea' }
        ],
        links: [
            { key: 'title', label: 'عنوان ستون (اختیاری)', type: 'text' },
            { key: 'items', label: 'آیتم‌ها — JSON مثل [{"name":"تماس","link":"/contact-us"}]', type: 'json' }
        ]
    };

    function hasSettings(type) {
        return WIDGET_FIELDS.hasOwnProperty(type);
    }

    function defaultSettings(type) {
        if (type === 'logo') return { height: 40 };
        if (type === 'search') return { placeholder: 'جستجوی محصولات...' };
        if (type === 'megamenu') return { label: 'دسته‌بندی' };
        if (type === 'spacer') return { width: 20 };
        if (type === 'custom_html') return { html: '' };
        if (type === 'text') return { title: '', content: '' };
        if (type === 'links') return { title: '', items: [] };
        return {};
    }

    // ساخت چیپ ویجت (هم‌ارز با hfb_render_widget_chip در PHP)
    function buildChip(type, settings) {
        var label = LABELS[type] || type;
        var editBtn = hasSettings(type)
            ? '<button type="button" class="button button-small hfb-edit">تنظیمات</button>'
            : '';
        var json = JSON.stringify(settings || {});
        var $chip = $(
            '<div class="hfb-widget" data-type="' + type + '">' +
            '<span class="dashicons dashicons-menu hfb-handle"></span>' +
            '<span class="hfb-widget-label">' + label + '</span>' +
            editBtn +
            '<span class="dashicons dashicons-no-alt hfb-remove"></span>' +
            '<input type="hidden" class="hfb-widget-settings">' +
            '</div>'
        );
        $chip.find('.hfb-widget-settings').val(json);
        return $chip;
    }

    function readChip($chip) {
        var settings = {};
        try {
            settings = JSON.parse($chip.find('.hfb-widget-settings').val() || '{}');
        } catch (e) { settings = {}; }
        return { id: 'w' + Math.random().toString(36).slice(2, 9), type: $chip.data('type'), settings: settings };
    }

    function refreshEmpty($zone) {
        if ($zone.find('.hfb-widget').length === 0) {
            if (!$zone.find('.hfb-zone-empty').length) {
                $zone.append('<p class="hfb-zone-empty">ویجت‌ها را اینجا رها کنید</p>');
            }
        } else {
            $zone.find('.hfb-zone-empty').remove();
        }
    }

    // مقداردهی drag & drop برای یک محدوده (هدر یا فوتر)
    function initZone($zone) {
        if ($zone.data('hfb-init')) return;
        $zone.data('hfb-init', true);
        $zone.sortable({
            connectWith: '.hfb-zone',
            items: '> .hfb-widget',
            placeholder: 'hfb-ph',
            tolerance: 'pointer',
            receive: function (event, ui) {
                var $z = $(this);
                // هر آیتمِ پالت که داخل ناحیه افتاده را به چیپ واقعی (.hfb-widget) تبدیل کن.
                // به ui.item تکیه نمی‌کنیم چون با connectToSortable + helper:clone
                // در برخی نسخه‌های jQuery UI به آیتم اصلی پالت اشاره می‌کند نه کلونِ درج‌شده،
                // و در نتیجه چیپ ساخته نمی‌شد و آیتم هنگام ذخیره از قلم می‌افتاد.
                $z.children('.hfb-palette-item').each(function () {
                    var type = $(this).data('type');
                    var $chip = buildChip(type, defaultSettings(type));
                    $(this).replaceWith($chip);
                });
                refreshEmpty($z);
            },
            update: function () {
                refreshEmpty($(this));
            }
        });
    }

    function initPalette($scope) {
        $scope.find('.hfb-palette-item').draggable({
            helper: 'clone',
            connectToSortable: '.hfb-zone',
            revert: 'invalid',
            cursor: 'move',
            zIndex: 1000
        });
    }

    function initAll() {
        $('.hfb-zone').each(function () { initZone($(this)); });
        initPalette($('#header-builder-tab'));
        initPalette($('#footer-builder-tab'));
        $('.hfb-zone').each(function () { refreshEmpty($(this)); });
    }
    initAll();

    // حذف ویجت
    $(document).on('click', '.hfb-remove', function () {
        var $zone = $(this).closest('.hfb-zone');
        $(this).closest('.hfb-widget').remove();
        refreshEmpty($zone);
    });

    /* ---------- مودال تنظیمات ویجت ---------- */
    var $editing = null;

    $(document).on('click', '.hfb-edit', function () {
        $editing = $(this).closest('.hfb-widget');
        var type = $editing.data('type');
        var fields = WIDGET_FIELDS[type] || [];
        var settings = {};
        try { settings = JSON.parse($editing.find('.hfb-widget-settings').val() || '{}'); } catch (e) {}

        $('#hfb-modal-title').text('تنظیمات: ' + (LABELS[type] || type));
        var $body = $('#hfb-modal-body').empty();
        fields.forEach(function (f) {
            var val = settings[f.key];
            if (f.type === 'json') val = val ? JSON.stringify(val, null, 2) : '';
            else if (val === undefined || val === null) val = '';
            var $row = $('<div class="hfb-field"></div>');
            $row.append('<label>' + f.label + '</label>');
            if (f.type === 'textarea' || f.type === 'json') {
                $row.append('<textarea data-key="' + f.key + '" rows="6" dir="' + (f.type === 'json' ? 'ltr' : 'rtl') + '"></textarea>');
                $row.find('textarea').val(val);
            } else {
                $row.append('<input type="' + (f.type === 'number' ? 'number' : 'text') + '" data-key="' + f.key + '">');
                $row.find('input').val(val);
            }
            $body.append($row);
        });
        $('#hfb-settings-modal').addClass('active');
    });

    $(document).on('click', '.hfb-modal-close, #hfb-settings-modal', function (e) {
        if (e.target === this) {
            $('#hfb-settings-modal').removeClass('active');
            $editing = null;
        }
    });

    $(document).on('click', '.hfb-modal-save', function () {
        if (!$editing) return;
        var type = $editing.data('type');
        var fields = WIDGET_FIELDS[type] || [];
        var settings = {};
        $('#hfb-modal-body').find('[data-key]').each(function () {
            var key = $(this).data('key');
            var f = fields.filter(function (x) { return x.key === key; })[0];
            var raw = $(this).val();
            if (f && f.type === 'json') {
                try { settings[key] = raw ? JSON.parse(raw) : []; }
                catch (e) { alert('JSON نامعتبر در فیلد «' + f.label + '»'); settings[key] = []; }
            } else if (f && f.type === 'number') {
                settings[key] = raw === '' ? '' : Number(raw);
            } else {
                settings[key] = raw;
            }
        });
        $editing.find('.hfb-widget-settings').val(JSON.stringify(settings));
        $('#hfb-settings-modal').removeClass('active');
        $editing = null;
    });

    /* ---------- ستون‌های فوتر ---------- */
    $(document).on('click', '#hfb-add-footer-col', function () {
        var $col = $(
            '<div class="hfb-footer-col">' +
            '<div class="hfb-footer-col-head">' +
            '<input type="text" class="hfb-col-title" placeholder="عنوان ستون">' +
            '<button type="button" class="button hfb-remove-col">×</button>' +
            '</div>' +
            '<div class="hfb-zone" data-zone="column"><p class="hfb-zone-empty">ویجت‌ها را اینجا رها کنید</p></div>' +
            '</div>'
        );
        $('#hfb-footer-columns').append($col);
        initZone($col.find('.hfb-zone'));
    });

    $(document).on('click', '.hfb-remove-col', function () {
        $(this).closest('.hfb-footer-col').remove();
    });

    /* ---------- اعمال قالب آماده ---------- */
    $(document).on('click', '#hfb-header-apply-template', function () {
        var key = $('#hfb-header-template').val();
        if (!key || !hfbData.headerTemplates[key]) return;
        if (!confirm('چیدمان فعلی هدر با قالب انتخاب‌شده جایگزین شود؟')) return;
        var zones = hfbData.headerTemplates[key].zones;
        $('#header-builder-tab .hfb-zone').each(function () {
            var z = $(this).data('zone');
            var $zone = $(this).empty();
            (zones[z] || []).forEach(function (w) {
                $zone.append(buildChip(w.type, w.settings || {}));
            });
            refreshEmpty($zone);
        });
        $('#hfb-header-enabled').prop('checked', true);
    });

    $(document).on('click', '#hfb-footer-apply-template', function () {
        var tpl = hfbData.footerTemplates.classic;
        if (!tpl) return;
        if (!confirm('چیدمان فعلی فوتر با قالب کلاسیک جایگزین شود؟')) return;
        var $cols = $('#hfb-footer-columns').empty();
        (tpl.columns || []).forEach(function (col) {
            var $col = $(
                '<div class="hfb-footer-col">' +
                '<div class="hfb-footer-col-head">' +
                '<input type="text" class="hfb-col-title">' +
                '<button type="button" class="button hfb-remove-col">×</button>' +
                '</div>' +
                '<div class="hfb-zone" data-zone="column"></div>' +
                '</div>'
            );
            $col.find('.hfb-col-title').val(col.title || '');
            var $zone = $col.find('.hfb-zone');
            (col.widgets || []).forEach(function (w) { $zone.append(buildChip(w.type, w.settings || {})); });
            $cols.append($col);
            initZone($zone);
            refreshEmpty($zone);
        });
        // نوار پایین
        var $bottom = $('#footer-builder-tab .hfb-zone[data-zone="bottom_bar"]').empty();
        ((tpl.bottom_bar && tpl.bottom_bar.widgets) || []).forEach(function (w) {
            $bottom.append(buildChip(w.type, w.settings || {}));
        });
        refreshEmpty($bottom);
        $('#hfb-footer-enabled').prop('checked', true);
    });

    /* ---------- serialize هنگام ارسال فرم ---------- */
    function zoneWidgets($zone) {
        var arr = [];
        $zone.find('> .hfb-widget').each(function () { arr.push(readChip($(this))); });
        return arr;
    }

    function serializeHeader() {
        var cfg = {
            enabled: $('#hfb-header-enabled').is(':checked'),
            template: $('#hfb-header-template').val() || 'custom',
            settings: {
                sticky: $('#hfb-header-sticky').is(':checked'),
                bg: $('#hfb-header-bg').val() || '#ffffff'
            },
            zones: {}
        };
        $('#header-builder-tab .hfb-zone').each(function () {
            cfg.zones[$(this).data('zone')] = zoneWidgets($(this));
        });
        $('#header_builder_data').val(JSON.stringify(cfg));
    }

    function serializeFooter() {
        var cfg = {
            enabled: $('#hfb-footer-enabled').is(':checked'),
            template: 'custom',
            settings: {
                bg: $('#hfb-footer-bg').val() || '#0b1220',
                text: $('#hfb-footer-text').val() || '#e5e7eb'
            },
            columns: [],
            bottom_bar: { widgets: [] }
        };
        $('#hfb-footer-columns .hfb-footer-col').each(function () {
            cfg.columns.push({
                title: $(this).find('.hfb-col-title').val() || '',
                widgets: zoneWidgets($(this).find('.hfb-zone'))
            });
        });
        var $bottom = $('#footer-builder-tab .hfb-zone[data-zone="bottom_bar"]');
        if ($bottom.length) cfg.bottom_bar.widgets = zoneWidgets($bottom);
        $('#footer_builder_data').val(JSON.stringify(cfg));
    }

    $('form').on('submit', function () {
        serializeHeader();
        serializeFooter();
        return true;
    });
});
