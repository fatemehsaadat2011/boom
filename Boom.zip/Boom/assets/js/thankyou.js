document.addEventListener('DOMContentLoaded', function () {
    if (window.boomThankyouConfig && window.boomThankyouConfig.hasMap) {
        var lat = window.boomThankyouConfig.lat;
        var lng = window.boomThankyouConfig.lng;
        var provider = window.boomThankyouConfig.mapProvider || 'leaflet';
        var apiKey = window.boomThankyouConfig.mapApiKey || '';
        var mapEl = document.getElementById('thankyou-map');

        if (mapEl && typeof L !== 'undefined') {
            if (provider === 'neshan') {
                var map = new L.Map('thankyou-map', {
                    key: apiKey,
                    maptype: 'neshan',
                    poi: true,
                    traffic: false,
                    center: [lat, lng],
                    zoom: 15,
                    zoomControl: false,
                    dragging: false,
                    scrollWheelZoom: false
                });
                L.marker([lat, lng]).addTo(map);
            } else {
                var map = L.map('thankyou-map').setView([lat, lng], 15);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '\u00a9 OpenStreetMap'
                }).addTo(map);
                L.marker([lat, lng]).addTo(map);
            }
        }
    }
});
