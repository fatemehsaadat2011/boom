/**
 * دکمه «افزودن جدول» برای ویرایشگر کلاسیک وردپرس (TinyMCE)
 * یک جدول استاندارد (با کلاس boom-table) در محل کرسر درج می‌کند تا در فرانت ری‌اکت
 * به‌صورت مدرن و واکنش‌گرا نمایش داده شود.
 */
(function () {
    if (typeof tinymce === 'undefined') return;

    tinymce.PluginManager.add('boom_table_button', function (editor) {
        editor.addButton('boom_table_button', {
            text: 'افزودن جدول',
            icon: false,
            tooltip: 'افزودن جدول به توضیحات',
            onclick: function () {
                editor.windowManager.open({
                    title: 'افزودن جدول',
                    width: 320,
                    height: 180,
                    body: [
                        {
                            type: 'textbox',
                            name: 'rows',
                            label: 'تعداد ردیف‌ها (بدون سرستون)',
                            value: '3'
                        },
                        {
                            type: 'textbox',
                            name: 'cols',
                            label: 'تعداد ستون‌ها',
                            value: '2'
                        },
                        {
                            type: 'checkbox',
                            name: 'header',
                            label: 'ردیف سرستون داشته باشد',
                            checked: true
                        }
                    ],
                    onsubmit: function (e) {
                        var rows = parseInt(e.data.rows, 10);
                        var cols = parseInt(e.data.cols, 10);
                        if (isNaN(rows)) rows = 3;
                        if (isNaN(cols)) cols = 2;
                        rows = Math.max(1, Math.min(50, rows));
                        cols = Math.max(1, Math.min(12, cols));
                        var hasHeader = !!e.data.header;

                        var html = '<table class="boom-table">';
                        if (hasHeader) {
                            html += '<thead><tr>';
                            for (var c = 0; c < cols; c++) {
                                html += '<th>عنوان ' + (c + 1) + '</th>';
                            }
                            html += '</tr></thead>';
                        }
                        html += '<tbody>';
                        for (var r = 0; r < rows; r++) {
                            html += '<tr>';
                            for (var c2 = 0; c2 < cols; c2++) {
                                html += '<td>—</td>';
                            }
                            html += '</tr>';
                        }
                        html += '</tbody></table><p>&nbsp;</p>';

                        editor.insertContent(html);
                    }
                });
            }
        });
    });
})();
