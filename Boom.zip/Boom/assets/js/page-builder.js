jQuery(document).ready(function ($) {
    'use strict';

    // مدیریت تب‌ها
    $(document).on('click', '.nav-tab', function (e) {
        e.preventDefault();

        var $this = $(this);

        // استفاده از data-tab یا href
        var tabName = $this.data('tab');
        var tabId = tabName ? '#' + tabName + '-tab' : $this.attr('href');

        if (!tabId || !$(tabId).length) return;

        // حذف کلاس active از همه تب‌ها
        $('.nav-tab').removeClass('nav-tab-active');
        $('.tab-content').removeClass('active');

        // اضافه کردن active به تب کلیک شده
        $this.addClass('nav-tab-active');

        // نمایش محتوای تب
        $(tabId).addClass('active');
    });

    // تنظیمات Drag & Drop برای المنت‌های سمت راست
    if (typeof $.fn.draggable === 'undefined') {
        console.warn('jQuery UI Draggable not loaded!');
    } else
    $('.element-item').draggable({
        helper: 'clone',
        connectToSortable: '.layout-area',
        revert: 'invalid',
        cursor: 'move',
        zIndex: 1000,
        start: function (e, ui) {
            ui.helper.css({
                'width': $(this).width() + 'px',
                'opacity': '0.8'
            });
        }
    });

    // تنظیمات Sortable برای منطقه چیدمان
    if (typeof $.fn.sortable !== 'undefined')
    $('.layout-area').sortable({
        placeholder: 'ui-sortable-placeholder',
        cursor: 'move',
        tolerance: 'pointer',
        receive: function (event, ui) {
            // حذف پیام خالی بودن
            $(this).find('.empty-message').remove();

            // بررسی اینکه آیا از panel می‌آید
            if (ui.item.hasClass('element-item')) {
                // تبدیل المنت به فرمت چیدمان
                var elementType = ui.item.data('type');
                var layoutId = $(this).attr('id');

                // بررسی اینکه آیا این المنت قبلاً اضافه شده (فقط برای غیر از custom-html)
                if (elementType !== 'custom-html') {
                    var existingElement = $(this).find('.layout-element[data-type="' + elementType + '"]');
                    if (existingElement.length > 0) {
                        // المنت قبلاً وجود دارد، حذف کپی جدید
                        ui.item.remove();
                        alert('این المنت قبلاً اضافه شده است!');
                        return;
                    }
                }

                // حذف المنت کپی شده از panel
                ui.item.remove();

                // افزودن المنت جدید با ساختار صحیح
                var index = $(this).find('.layout-element').length;
                addLayoutElement(layoutId, elementType, index);
            }
        },
        update: function (event, ui) {
            // به‌روزرسانی داده‌ها بعد از جابجایی
            updateLayoutData($(this).attr('id'));
        }
    });

    // افزودن المنت جدید به چیدمان
    function addLayoutElement(layoutId, elementType, index, content = '') {
        var labels = {
            'product-display': 'بخش نمایش محصول',
            'product-description': 'بخش توضیحات',
            'related-products': 'بخش محصولات مرتبط',
            'product-faq': 'سوالات متداول محصول',
            'blog-description': 'توضیحات بلاگ',
            'related-posts': 'پست‌های مشابه',
            'custom-html': 'HTML سفارشی'
        };

        var label = labels[elementType] || elementType;
        var htmlContent = '';

        if (elementType === 'custom-html') {
            htmlContent = `
                <button type="button" class="button button-small edit-html" data-index="${index}">ویرایش</button>
                <div class="custom-html-preview">${content ? content.substring(0, 50) + '...' : 'خالی'}</div>
                <input type="hidden" class="custom-html-data" value="${content}">
            `;
        }

        var element = `
            <div class="layout-element" data-type="${elementType}" data-index="${index}">
                <span class="dashicons dashicons-menu element-handle"></span>
                <span class="element-label">${label}</span>
                ${htmlContent}
                <span class="dashicons dashicons-no-alt remove-element"></span>
            </div>
        `;

        $('#' + layoutId).append(element);
        updateLayoutData(layoutId);
    }

    // حذف المنت از چیدمان
    $(document).on('click', '.remove-element', function () {
        var layoutArea = $(this).closest('.layout-area');
        $(this).closest('.layout-element').fadeOut(300, function () {
            $(this).remove();

            // اگر خالی شد، پیام نمایش بده
            if (layoutArea.find('.layout-element').length === 0) {
                layoutArea.html('<p class="empty-message">هیچ المنتی اضافه نشده است. المنت‌ها را از سمت چپ به اینجا بکشید.</p>');
            }

            updateLayoutData(layoutArea.attr('id'));
        });
    });

    // مدیریت مودال HTML سفارشی
    var currentEditingElement = null;

    $(document).on('click', '.edit-html', function () {
        currentEditingElement = $(this).closest('.layout-element');
        var currentContent = currentEditingElement.find('.custom-html-data').val();

        $('#custom-html-content').val(currentContent);
        $('#custom-html-modal').addClass('active').fadeIn(200);
    });

    $('.close-modal').on('click', function () {
        $('#custom-html-modal').removeClass('active').fadeOut(200);
        currentEditingElement = null;
    });

    $('.save-custom-html').on('click', function () {
        if (currentEditingElement) {
            var htmlContent = $('#custom-html-content').val();
            currentEditingElement.find('.custom-html-data').val(htmlContent);

            // به‌روزرسانی پیش‌نمایش
            var preview = htmlContent ? htmlContent.substring(0, 50) + '...' : 'خالی';
            currentEditingElement.find('.custom-html-preview').text(preview);

            // به‌روزرسانی داده‌ها
            var layoutId = currentEditingElement.closest('.layout-area').attr('id');
            updateLayoutData(layoutId);
        }

        $('#custom-html-modal').removeClass('active').fadeOut(200);
        currentEditingElement = null;
    });

    // بستن مودال با کلیک خارج از آن
    $('#custom-html-modal').on('click', function (e) {
        if (e.target === this) {
            $(this).removeClass('active').fadeOut(200);
            currentEditingElement = null;
        }
    });

    // به‌روزرسانی داده‌های چیدمان
    function updateLayoutData(layoutId) {
        var layoutArea = $('#' + layoutId);
        var elements = [];

        layoutArea.find('.layout-element').each(function (index) {
            var type = $(this).data('type');
            var content = '';

            if (type === 'custom-html') {
                content = $(this).find('.custom-html-data').val();
            }

            elements.push({
                type: type,
                content: content,
                order: index
            });

            // به‌روزرسانی index
            $(this).attr('data-index', index);
            $(this).find('.edit-html').attr('data-index', index);
        });

        // ذخیره در input مخفی - تبدیل ID با جایگزینی - به _
        var inputId = layoutId.replace('-', '_') + '_data';
        var inputElement = $('#' + inputId);

        if (inputElement.length) {
            inputElement.val(JSON.stringify(elements));
            console.log('Updated ' + inputId + ':', elements);
        } else {
            console.error('Input not found: ' + inputId);
        }
    }

    // به‌روزرسانی داده‌ها قبل از ارسال فرم
    $('form').on('submit', function (e) {
        console.log('Form submitting...');
        updateLayoutData('product-layout');
        updateLayoutData('blog-layout');

        // سریالایز داده‌های منو موبایل
        $('#mobile_menu_data').val(serializeMobileMenuData());

        // نمایش مقادیر برای دیباگ
        console.log('Product layout value:', $('#product_layout_data').val());
        console.log('Blog layout value:', $('#blog_layout_data').val());
        console.log('Mobile menu value:', $('#mobile_menu_data').val());

        return true;
    });

    // بارگذاری اولیه داده‌ها
    updateLayoutData('product-layout');
    updateLayoutData('blog-layout');

    // Drag over effect
    $('.layout-area').on('dragover', function (e) {
        $(this).addClass('drag-over');
    });

    $('.layout-area').on('dragleave drop', function (e) {
        $(this).removeClass('drag-over');
    });

    // مدیریت نمایش/مخفی کردن فیلد متن دلخواه در مشخصات محصول
    $(document).on('change', '.spec-value-type', function () {
        var customTextField = $(this).closest('.spec-field-content').find('.custom-text-field');

        if ($(this).val() === 'custom_text') {
            customTextField.slideDown(200);
        } else {
            customTextField.slideUp(200);
        }
    });

    // ======= مدیریت منو موبایل =======

    var mobileMenuIndex = $('#mobile-menu-list .mobile-menu-item').length;
    var actionLabels = {
        'cart': 'دکمه سبد خرید',
        'login': 'دکمه لاگین'
    };

    // Sortable برای منو موبایل
    if (typeof $.fn.sortable !== 'undefined') {
        $('#mobile-menu-list').sortable({
            handle: '.mobile-menu-handle',
            placeholder: 'mobile-menu-placeholder',
            update: function () {
                updateMobileMenuIndices();
            }
        });
    }

    // افزودن آیتم جدید
    $('#add-mobile-menu-item').on('click', function () {
        var currentCount = $('#mobile-menu-list .mobile-menu-item').length;
        if (currentCount >= 5) {
            alert('حداکثر ۵ آیتم مجاز است!');
            return;
        }

        var newItem = `
            <div class="mobile-menu-item" data-index="${mobileMenuIndex}">
                <div class="mobile-menu-item-header">
                    <span class="dashicons dashicons-menu mobile-menu-handle"></span>
                    <strong>آیتم جدید</strong>
                    <button type="button" class="button mobile-menu-item-remove">×</button>
                </div>
                <div class="mobile-menu-item-content">
                    <div class="field-row">
                        <label>اکشن:</label>
                        <select class="mobile-menu-action">
                            <option value="">بدون اکشن (عادی)</option>
                            <option value="cart">دکمه سبد خرید</option>
                            <option value="login">دکمه لاگین</option>
                        </select>
                    </div>
                    <div class="field-row mobile-menu-field">
                        <label>عنوان:</label>
                        <input type="text" class="mobile-menu-title" value="" placeholder="عنوان آیتم">
                    </div>
                    <div class="field-row mobile-menu-field">
                        <label>لینک:</label>
                        <input type="text" class="mobile-menu-link" value="" placeholder="مثال: /cats" dir="ltr">
                    </div>
                    <div class="field-row mobile-menu-field">
                        <label>آیکون SVG:</label>
                        <textarea class="mobile-menu-icon" rows="3" placeholder="کد SVG را وارد کنید..." dir="ltr"></textarea>
                    </div>
                </div>
            </div>
        `;
        $('#mobile-menu-list').append(newItem);
        mobileMenuIndex++;
    });

    // حذف آیتم
    $(document).on('click', '.mobile-menu-item-remove', function () {
        $(this).closest('.mobile-menu-item').slideUp(200, function () {
            $(this).remove();
            updateMobileMenuIndices();
        });
    });

    // تغییر اکشن
    $(document).on('change', '.mobile-menu-action', function () {
        var $item = $(this).closest('.mobile-menu-item');
        var action = $(this).val();
        var $fields = $item.find('.mobile-menu-field input, .mobile-menu-field textarea');

        if (action) {
            $fields.prop('disabled', true).val('');
            $item.find('.mobile-menu-item-header strong').text(actionLabels[action] || action);
        } else {
            $fields.prop('disabled', false);
            var title = $item.find('.mobile-menu-title').val() || 'آیتم جدید';
            $item.find('.mobile-menu-item-header strong').text(title);
        }
    });

    // بروزرسانی عنوان در هدر
    $(document).on('input', '.mobile-menu-title', function () {
        var $item = $(this).closest('.mobile-menu-item');
        var action = $item.find('.mobile-menu-action').val();
        if (!action) {
            var title = $(this).val() || 'آیتم جدید';
            $item.find('.mobile-menu-item-header strong').text(title);
        }
    });

    // بازگردانی به پیش‌فرض
    $('#reset-mobile-menu').on('click', function () {
        if (!confirm('آیا از بازگردانی منو موبایل به حالت پیش‌فرض مطمئن هستید؟')) {
            return;
        }

        var defaults = pageBuilderAjax.mobileMenuDefaults;
        $('#mobile-menu-list').empty();
        mobileMenuIndex = 0;

        defaults.forEach(function (item) {
            var hasAction = item.action !== '';
            var headerTitle = hasAction ? (actionLabels[item.action] || item.action) : (item.title || 'آیتم جدید');
            var disabled = hasAction ? 'disabled' : '';

            var newItem = `
                <div class="mobile-menu-item" data-index="${mobileMenuIndex}">
                    <div class="mobile-menu-item-header">
                        <span class="dashicons dashicons-menu mobile-menu-handle"></span>
                        <strong>${headerTitle}</strong>
                        <button type="button" class="button mobile-menu-item-remove">×</button>
                    </div>
                    <div class="mobile-menu-item-content">
                        <div class="field-row">
                            <label>اکشن:</label>
                            <select class="mobile-menu-action">
                                <option value="" ${item.action === '' ? 'selected' : ''}>بدون اکشن (عادی)</option>
                                <option value="cart" ${item.action === 'cart' ? 'selected' : ''}>دکمه سبد خرید</option>
                                <option value="login" ${item.action === 'login' ? 'selected' : ''}>دکمه لاگین</option>
                            </select>
                        </div>
                        <div class="field-row mobile-menu-field">
                            <label>عنوان:</label>
                            <input type="text" class="mobile-menu-title" value="${item.title || ''}" placeholder="عنوان آیتم" ${disabled}>
                        </div>
                        <div class="field-row mobile-menu-field">
                            <label>لینک:</label>
                            <input type="text" class="mobile-menu-link" value="${item.link || ''}" placeholder="مثال: /cats" dir="ltr" ${disabled}>
                        </div>
                        <div class="field-row mobile-menu-field">
                            <label>آیکون SVG:</label>
                            <textarea class="mobile-menu-icon" rows="3" placeholder="کد SVG را وارد کنید..." dir="ltr" ${disabled}>${item.icon || ''}</textarea>
                        </div>
                    </div>
                </div>
            `;
            $('#mobile-menu-list').append(newItem);
            mobileMenuIndex++;
        });
    });

    // بروزرسانی ایندکس‌ها
    function updateMobileMenuIndices() {
        $('#mobile-menu-list .mobile-menu-item').each(function (index) {
            $(this).attr('data-index', index);
        });
    }

    // سریالایز داده‌های منو موبایل
    function serializeMobileMenuData() {
        var items = [];
        $('#mobile-menu-list .mobile-menu-item').each(function (index) {
            var $item = $(this);
            var action = $item.find('.mobile-menu-action').val() || '';

            items.push({
                title: action ? '' : ($item.find('.mobile-menu-title').val() || ''),
                link: action ? '' : ($item.find('.mobile-menu-link').val() || ''),
                icon: action ? '' : ($item.find('.mobile-menu-icon').val() || ''),
                action: action,
                order: index
            });
        });
        return JSON.stringify(items);
    }
});
