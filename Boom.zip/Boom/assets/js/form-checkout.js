jQuery(document).ready(function ($) {
    var mapEnabled = window.boomCheckoutConfig.mapEnabled;
    var mapProvider = window.boomCheckoutConfig.mapProvider || 'leaflet';
    var mapApiKey = window.boomCheckoutConfig.mapApiKey || '';
    var defaultLat = window.boomCheckoutConfig.defaultLat;
    var defaultLng = window.boomCheckoutConfig.defaultLng;
    var defaultZoom = window.boomCheckoutConfig.defaultZoom;
    var noAddressMsg = window.boomCheckoutConfig.noAddressMsg;
    var isLoggedIn = window.boomCheckoutConfig.isLoggedIn;
    var customFieldLabels = window.boomCheckoutConfig.customFieldLabels;
    var restUrl = (window.boomCheckoutConfig.restUrl || '/wp-json/boom/v1/').replace(/\/$/, '');

    var boomMap = null;
    var boomMarker = null;
    var selectedLat = null;
    var selectedLng = null;
    var selectedAddress = null;

    // تابع نمایش/مخفی کردن loading برای فیلدها
    function showFieldsLoading(show) {
        var $billingFields = $('.woocommerce-billing-fields__field-wrapper');

        if (show) {
            // اضافه کردن overlay با loading
            if (!$('#boom-fields-loading').length) {
                $billingFields.css('position', 'relative');
                $billingFields.append('<div id="boom-fields-loading" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,0.9); display: flex; align-items: center; justify-content: center; z-index: 999; border-radius: 12px;"><div style="text-align: center;"><div style="width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #000; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 12px;"></div><p style="color: #666; font-size: 14px;">در حال بارگذاری آدرس...</p></div></div>');
                // اضافه کردن CSS animation و استایل label
                if (!$('#boom-loading-style').length) {
                    $('head').append('<style id="boom-loading-style">@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } .woocommerce-billing-fields .form-row.woocommerce-validated label .required { color: inherit !important; }</style>');
                }
            }
        } else {
            $('#boom-fields-loading').remove();
        }
    }

    // Fill empty required fields before checkout validation
    $('form.checkout').on('checkout_place_order', function () {
        if (window.boomSelectedAddress) {
            var addr = window.boomSelectedAddress;
            var $address = $('#billing_address_1');
            var $phone = $('#billing_phone');
            var $city = $('#billing_city');
            var $state = $('#billing_state');

            // Force fill address if empty
            if ($address.length && !$address.val() && addr.address) {
                $address.val(addr.address).trigger('change').trigger('input');
            }
            // Force fill phone if empty
            if ($phone.length && !$phone.val() && addr.phone) {
                var phone = addr.phone.toString().replace(/[^\d]/g, '');
                if (phone.length === 10 && phone.charAt(0) === '9') {
                    phone = '0' + phone;
                }
                $phone.val(phone).trigger('change').trigger('input');
            }
            // Force fill city if empty
            if ($city.length && !$city.val() && addr.city) {
                if ($city.is('select')) {
                    var cityFound = false;
                    $city.find('option').each(function () {
                        var optText = $(this).text().trim();
                        if (optText.indexOf(addr.city) !== -1 || addr.city.indexOf(optText) !== -1) {
                            $city.val($(this).val()).trigger('change');
                            cityFound = true;
                            return false;
                        }
                    });
                    // اگر شهر پیدا نشد، گزینه جدید اضافه کن
                    if (!cityFound) {
                        $city.append('<option value="' + addr.city + '" selected>' + addr.city + '</option>');
                        $city.trigger('change');
                    }
                } else {
                    $city.val(addr.city).trigger('change').trigger('input');
                }
            }
            // Force fill state if empty
            if ($state.length && !$state.val() && addr.state) {
                if ($state.is('select')) {
                    var stateFound = false;
                    $state.find('option').each(function () {
                        var optText = $(this).text().trim();
                        if (optText.indexOf(addr.state) !== -1 || addr.state.indexOf(optText) !== -1) {
                            $state.val($(this).val()).trigger('change');
                            stateFound = true;
                            return false;
                        }
                    });
                    // اگر استان پیدا نشد، گزینه جدید اضافه کن
                    if (!stateFound) {
                        $state.append('<option value="' + addr.state + '" selected>' + addr.state + '</option>');
                        $state.trigger('change');
                    }
                } else {
                    $state.val(addr.state).trigger('change').trigger('input');
                }
            }

            // حذف کلاس‌های خطای validation افزونه ووکامرس فارسی
            $address.removeClass('woocommerce-invalid woocommerce-invalid-required-field');
            $address.closest('.form-row').removeClass('woocommerce-invalid woocommerce-invalid-required-field');

            // حذف پیام‌های خطای مربوط به آدرس
            $('.woocommerce-error li, .woocommerce-NoticeGroup-checkout .woocommerce-error li').each(function () {
                var errorText = $(this).text();
                if (errorText.indexOf('آدرس') !== -1 || errorText.indexOf('address') !== -1) {
                    $(this).remove();
                }
            });
        }
        return true;
    });

    // بعد از updated_checkout، دوباره استان/شهر رو set کن
    $(document.body).on('updated_checkout', function () {
        if (window.boomSelectedAddress && window.boomSelectedAddress.state) {
            var addr = window.boomSelectedAddress;

            setTimeout(function () {
                var $billingState = $('#billing_state');
                var $billingCity = $('#billing_city');

                var currentStateVal = $billingState.val();
                var currentCityVal = $billingCity.val();


                // اگر استان خالی هست، دوباره set کن
                if (!currentStateVal) {

                    // پیدا کردن state value
                    var stateValue = null;
                    $billingState.find('option').each(function () {
                        if ($(this).text().trim() === addr.state) {
                            stateValue = $(this).val();
                            return false;
                        }
                    });

                    if (stateValue) {
                        $billingState.val(stateValue);

                        // بارگذاری مجدد شهرها
                        $.ajax({
                            url: '/wp-admin/admin-ajax.php',
                            type: 'POST',
                            data: {
                                action: 'mahdiy_load_cities',
                                state_id: stateValue,
                                type: 'billing'
                            },
                            success: function (response) {
                                $billingCity.empty().append(response);

                                // Set کردن شهر
                                setTimeout(function () {
                                    var cityValue = null;
                                    $billingCity.find('option').each(function () {
                                        if ($(this).text().trim() === addr.city) {
                                            cityValue = $(this).val();
                                            return false;
                                        }
                                    });

                                    if (cityValue) {
                                        $billingCity.val(cityValue);
                                    }
                                }, 100);
                            }
                        });
                    }
                } else if (!currentCityVal && addr.city) {
                    // اگر استان هست ولی شهر خالیه

                    $.ajax({
                        url: '/wp-admin/admin-ajax.php',
                        type: 'POST',
                        data: {
                            action: 'mahdiy_load_cities',
                            state_id: currentStateVal,
                            type: 'billing'
                        },
                        success: function (response) {
                            $billingCity.empty().append(response);

                            setTimeout(function () {
                                var cityValue = null;
                                $billingCity.find('option').each(function () {
                                    if ($(this).text().trim() === addr.city) {
                                        cityValue = $(this).val();
                                        return false;
                                    }
                                });

                                if (cityValue) {
                                    $billingCity.val(cityValue);
                                }
                            }, 100);
                        }
                    });
                } else {
                }
            }, 150);
        }
    });

    $('#boom-select-address-btn, #boom-change-address-btn').click(function () {
        $('#boom-address-popup').removeClass('hidden').addClass('flex');
        loadUserAddresses();
    });

    $('#boom-close-address-popup').click(function () {
        $('#boom-address-popup').removeClass('flex').addClass('hidden');
    });

    $('#boom-address-popup').click(function (e) {
        if (e.target === this) {
            $(this).removeClass('flex').addClass('hidden');
        }
    });

    function loadUserAddresses() {
        $.ajax({
            url: restUrl + '/addresses',
            method: 'GET',
            credentials: 'include',
            xhrFields: { withCredentials: true },
            success: function (response) {
                if (response.success && response.addresses.length > 0) {
                    renderAddressList(response.addresses);
                } else {
                    $('#boom-address-list').html('<div class="text-center py-8 text-gray-500"><svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg><p>' + noAddressMsg + '</p></div>');
                }
            },
            error: function () {
                $('#boom-address-list').html('<div class="text-center py-8 text-red-500"><p>خطا در بارگذاری آدرس‌ها</p></div>');
            }
        });
    }

    function renderAddressList(addresses) {
        var html = '';
        addresses.forEach(function (addr) {
            html += '<div class="boom-address-item p-4 border-2 rounded-2xl mb-3 cursor-pointer transition-all duration-200 ' + (addr.is_default ? 'border-gray-900 bg-gray-50/50' : 'border-gray-100 hover:border-gray-300 hover:bg-gray-50/50') + '" style="' + (addr.is_default ? 'box-shadow: 0 2px 12px rgba(0,0,0,0.06);' : '') + '" data-address=\'' + JSON.stringify(addr) + '\'>';
            html += '<div class="flex items-start justify-between"><div class="flex-1"><div class="flex items-center gap-2 mb-2"><span class="font-bold text-gray-900">' + addr.title + '</span>';
            if (addr.is_default) html += '<span class="text-[10px] font-semibold bg-gray-900 text-white px-2.5 py-1 rounded-full uppercase tracking-wider">\u067e\u06cc\u0634\u200c\u0641\u0631\u0636</span>';
            html += '</div><p class="text-sm text-gray-500">' + addr.state + ' \u2022 ' + addr.city + '</p><p class="text-sm text-gray-400 mt-1 leading-relaxed">' + addr.address + '</p>';
            if (addr.phone) html += '<p class="text-xs text-gray-400 mt-2 flex items-center gap-1"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>' + addr.phone + '</p>';
            html += '</div><button type="button" class="boom-delete-address text-gray-300 hover:text-red-500 p-2 rounded-xl hover:bg-red-50 transition-all duration-200" data-id="' + addr.id + '"><svg class="w-4.5 h-4.5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button></div></div>';
        });
        $('#boom-address-list').html(html);
    }

    $(document).on('click', '.boom-address-item', function (e) {
        if ($(e.target).closest('.boom-delete-address').length) {
            return;
        }
        var addr = $(this).data('address');
        selectedAddress = addr;
        fillAddressFields(addr);
        if (isLoggedIn) {
            showAddressPreview(addr);
        }
        $('#boom-address-popup').removeClass('flex').addClass('hidden');
    });

    function showAddressPreview(addr) {
        $('#boom-preview-title').text(addr.title);
        var details = '';
        if (addr.first_name || addr.last_name) {
            details += '<p><strong>نام:</strong> ' + (addr.first_name || '') + ' ' + (addr.last_name || '') + '</p>';
        }
        if (addr.email) {
            details += '<p><strong>ایمیل:</strong> ' + addr.email + '</p>';
        }
        if (addr.company) {
            details += '<p><strong>شرکت:</strong> ' + addr.company + '</p>';
        }
        details += '<p><strong>آدرس:</strong> ' + addr.state + '، ' + addr.city + '، ' + addr.address + '</p>';
        if (addr.postcode) {
            details += '<p><strong>کد پستی:</strong> ' + addr.postcode + '</p>';
        }
        if (addr.phone) {
            details += '<p><strong>تلفن:</strong> ' + addr.phone + '</p>';
        }
        if (addr.custom_fields && typeof addr.custom_fields === 'object') {
            $.each(addr.custom_fields, function (fieldName, fieldValue) {
                if (fieldValue && fieldValue !== '0') {
                    var label = customFieldLabels[fieldName] || fieldName;
                    var displayValue = fieldValue === '1' ? 'بله' : fieldValue;
                    details += '<p><strong>' + label + ':</strong> ' + displayValue + '</p>';
                }
            });
        }
        $('#boom-preview-details').html(details);
        $('#boom-address-preview').removeClass('hidden');
        $('#boom-select-address-container').addClass('hidden');
    }

    function fillCustomFields(customFields) {
        $.each(customFields, function (fieldName, fieldValue) {
            var fieldSelector = 'boom_custom_' + fieldName;
            var field = document.getElementById(fieldSelector);
            var $radioFields = $('input[name="' + fieldSelector + '"][type="radio"]');
            if (!field && $radioFields.length === 0) {
                return;
            }
            if ($radioFields.length > 0) {
                $radioFields.filter('[value="' + fieldValue + '"]').prop('checked', true);
            } else if (field.type === 'checkbox') {
                field.checked = (fieldValue === '1' || fieldValue === true);
            } else if (field.tagName === 'SELECT') {
                field.value = fieldValue;
            } else if (field.tagName === 'TEXTAREA') {
                field.value = fieldValue;
            } else {
                field.value = fieldValue;
            }
        });
    }

    function fillAddressFields(addr) {
        // نمایش loading
        showFieldsLoading(true);

        // Set country first (default to IR)
        var $billingCountry = $('#billing_country');
        if ($billingCountry.length) {
            var countryVal = addr.country || 'IR';
            $billingCountry.val(countryVal).trigger('change');
        }

        // Fill basic fields
        if (addr.first_name) $('#billing_first_name').val(addr.first_name).trigger('change');
        if (addr.last_name) $('#billing_last_name').val(addr.last_name).trigger('change');
        if (addr.email) $('#billing_email').val(addr.email).trigger('change');
        if (addr.company) $('#billing_company').val(addr.company).trigger('change');

        // Set state and wait for WooCommerce to load cities
        setTimeout(function () {
            var $billingState = $('#billing_state');
            if (addr.state && $billingState.length) {

                if ($billingState.is('select')) {
                    // Find state in dropdown - جستجوی دقیق‌تر
                    var stateFound = false;
                    var stateValue = null;

                    $billingState.find('option').each(function () {
                        var optText = $(this).text().trim();
                        var optVal = $(this).val();

                        // مقایسه با text و value
                        if (optText === addr.state || optVal === addr.state) {
                            stateValue = optVal;
                            stateFound = true;
                            return false;
                        }
                    });

                    if (stateFound && stateValue) {

                        // تنظیم value
                        $billingState.val(stateValue);

                        // Update select2 display for state
                        if ($billingState.hasClass('select2-hidden-accessible')) {
                            var selectedStateText = $billingState.find('option:selected').text();
                            var $stateSelect2Container = $billingState.next('.select2-container');
                            if ($stateSelect2Container.length) {
                                $stateSelect2Container.find('.select2-selection__rendered').text(selectedStateText);
                            }
                        }


                        // بارگذاری شهرها مستقیماً از persian-woocommerce
                        loadPersianWooCommerceCities(stateValue, addr.city);
                    } else {
                        $billingState.append('<option value="' + addr.state + '" selected>' + addr.state + '</option>');
                        $billingState.trigger('change');

                        // برای manual state هم شهر رو set کن
                        waitForCitiesAndSet(addr.city);
                    }
                } else {
                    $billingState.val(addr.state).trigger('change');
                    waitForCitiesAndSet(addr.city);
                }
            }

            // تابع برای بارگذاری مستقیم شهرها از persian-woocommerce
            function loadPersianWooCommerceCities(stateId, cityName) {
                var $billingCity = $('#billing_city');
                if (!$billingCity.length) return;


                // پاک کردن option های قبلی
                $billingCity.empty().append('<option value="0">در حال بارگذاری...</option>');

                // ارسال AJAX مثل persian-woocommerce
                $.ajax({
                    url: '/wp-admin/admin-ajax.php',
                    type: 'POST',
                    data: {
                        action: 'mahdiy_load_cities',
                        state_id: stateId,
                        type: 'billing'
                    },
                    success: function (response) {

                        // پاک کردن و اضافه کردن option های جدید
                        $billingCity.empty();
                        $billingCity.append(response);

                        var citiesCount = $billingCity.find('option[value!=""][value!="0"]').length;

                        // حالا شهر رو پیدا کن و set کن
                        if (cityName) {
                            setTimeout(function () {
                                setCityValue(cityName, $billingCity);
                            }, 200);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('❌ Error loading cities:', error);
                        $billingCity.empty().append('<option value="0">خطا در بارگذاری شهرها</option>');
                    }
                });
            }

            // تابع برای صبر کردن تا شهرها لود بشن
            function waitForCitiesAndSet(cityName) {
                if (!cityName) return;

                var $billingCity = $('#billing_city');
                if (!$billingCity.length) return;


                var attempts = 0;
                var maxAttempts = 20; // 20 بار تلاش = 4 ثانیه

                var checkInterval = setInterval(function () {
                    attempts++;

                    var optionsCount = $billingCity.find('option').length;
                    var optionsCountWithoutEmpty = $billingCity.find('option[value!=""][value!="0"]').length;


                    // اگر بیشتر از 1 شهر واقعی داره (نه فقط "لطفا انتخاب کنید")
                    if (optionsCountWithoutEmpty > 0) {
                        clearInterval(checkInterval);

                        setCityValue(cityName, $billingCity);
                    } else if (attempts >= maxAttempts) {
                        clearInterval(checkInterval);
                        setCityValue(cityName, $billingCity);
                    }
                }, 300); // هر 300ms چک کن (بیشتر از قبل)
            }

            // تابع برای set کردن شهر
            function setCityValue(cityName, $citySelect) {
                if ($citySelect.is('select')) {
                    var cityFound = false;
                    var cityValue = null;
                    var matchedCityText = null;

                    // جستجوی دقیق
                    $citySelect.find('option').each(function () {
                        var optText = $(this).text().trim();
                        var optVal = $(this).val();

                        if (optText === cityName || optVal === cityName) {
                            cityValue = optVal;
                            matchedCityText = optText;
                            cityFound = true;
                            return false;
                        }
                    });

                    // اگر دقیق پیدا نشد، جستجوی شباهت
                    if (!cityFound) {
                        var normalizedCityName = cityName.replace(/\s+/g, '').toLowerCase();
                        var bestMatch = null;
                        var bestMatchScore = 0;

                        $citySelect.find('option').each(function () {
                            var optText = $(this).text().trim();
                            var optVal = $(this).val();

                            if (!optVal || optVal === '0') return;

                            var normalizedOptText = optText.replace(/\s+/g, '').toLowerCase();

                            // چک کردن شامل شدن
                            if (normalizedOptText.includes(normalizedCityName) || normalizedCityName.includes(normalizedOptText)) {
                                var score = Math.max(normalizedCityName.length, normalizedOptText.length) - Math.abs(normalizedCityName.length - normalizedOptText.length);

                                if (score > bestMatchScore) {
                                    bestMatchScore = score;
                                    bestMatch = {
                                        value: optVal,
                                        text: optText
                                    };
                                }
                            }
                        });

                        if (bestMatch && bestMatchScore > cityName.length * 0.5) {
                            cityValue = bestMatch.value;
                            matchedCityText = bestMatch.text;
                            cityFound = true;
                        }
                    }

                    if (cityFound && cityValue) {
                        // Set value
                        $citySelect.val(cityValue);

                        // Trigger events
                        $citySelect.trigger('change');

                        // برای select2
                        if ($citySelect.hasClass('select2-hidden-accessible')) {
                            $citySelect.trigger('change.select2');

                            // Update display manually
                            var $select2Container = $citySelect.next('.select2-container');
                            if ($select2Container.length) {
                                $select2Container.find('.select2-selection__rendered').text(matchedCityText);
                            }
                        }

                    } else {
                        // شهر پیدا نشد - نمایش هشدار
                        showCityNotification('⚠️ شهر "' + cityName + '" در لیست شهرهای این استان یافت نشد. لطفاً شهر صحیح را انتخاب کنید.', 'error');

                        // خالی گذاشتن شهر
                        $citySelect.val('0').trigger('change');
                    }
                } else {
                    $citySelect.val(cityName).trigger('change');
                }
            }

            // تابع نمایش notification
            function showCityNotification(message, type) {
                type = type || 'info';
                var bgColor = type === 'error' ? '#fee2e2' : '#dbeafe';
                var textColor = type === 'error' ? '#991b1b' : '#1e40af';
                var borderColor = type === 'error' ? '#fca5a5' : '#93c5fd';

                var $notification = $('<div class="boom-city-notification" style="position: fixed; top: 20px; right: 20px; background: ' + bgColor + '; color: ' + textColor + '; padding: 16px 20px; border-radius: 12px; border: 1px solid ' + borderColor + '; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 10000; max-width: 400px; font-size: 14px; line-height: 1.5;">' + message + '</div>');

                $('body').append($notification);

                setTimeout(function () {
                    $notification.fadeOut(300, function () {
                        $(this).remove();
                    });
                }, 5000);
            }
        }, 300);

        // Set remaining fields
        if (addr.address) $('#billing_address_1').val(addr.address);
        if (addr.postcode) $('#billing_postcode').val(addr.postcode);
        if (addr.phone) {
            var phone = addr.phone.toString().replace(/[^\d]/g, '');
            if (phone.length === 10 && phone.charAt(0) === '9') phone = '0' + phone;
            if (phone.length === 12 && phone.substring(0, 2) === '98') phone = '0' + phone.substring(2);
            $('#billing_phone').val(phone);
        }

        // Store address data BEFORE triggering update
        window.boomSelectedAddress = addr;

        // فقط یک بار trigger کن و بعد از تمام شدن set کردن فیلدها
        setTimeout(function () {
            $(document.body).trigger('update_checkout');

            // خاموش کردن loading بعد از اتمام
            setTimeout(function () {
                showFieldsLoading(false);
            }, 1000);
        }, 800);

        if (addr.custom_fields && typeof addr.custom_fields === 'object') {
            window.boomPendingCustomFields = addr.custom_fields;
            fillCustomFields(addr.custom_fields);
            setTimeout(function () {
                if (window.boomPendingCustomFields) {
                    fillCustomFields(window.boomPendingCustomFields);
                }
            }, 500);
            setTimeout(function () {
                if (window.boomPendingCustomFields) {
                    fillCustomFields(window.boomPendingCustomFields);
                }
            }, 1000);
            setTimeout(function () {
                if (window.boomPendingCustomFields) {
                    fillCustomFields(window.boomPendingCustomFields);
                }
            }, 2000);
        }

        if (addr.latitude && addr.longitude && mapEnabled) {
            $('#boom_location_lat').val(addr.latitude);
            $('#boom_location_lng').val(addr.longitude);
            selectedLat = addr.latitude;
            selectedLng = addr.longitude;
            $('#boom-map-select-container').addClass('hidden');
            $('#boom-map-preview-container').removeClass('hidden');
            setTimeout(function () {
                if (typeof L !== 'undefined') {
                    var miniMapEl = document.getElementById('boom-mini-map');
                    if (miniMapEl && miniMapEl._leaflet_id) {
                        var existingMap = L.map._instances ? L.map._instances[miniMapEl._leaflet_id] : null;
                    }
                    if (!miniMapEl._leaflet_id) {
                        var miniMap = L.map('boom-mini-map', {
                            zoomControl: false,
                            dragging: false,
                            scrollWheelZoom: false
                        }).setView([addr.latitude, addr.longitude], 15);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: ''
                        }).addTo(miniMap);
                        L.marker([addr.latitude, addr.longitude]).addTo(miniMap);
                    }
                }
            }, 200);
        }
    }

    $(document).on('click', '.boom-delete-address', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var id = $(this).data('id');
        if (confirm('آیا از حذف این آدرس مطمئن هستید؟')) {
            $.ajax({
                url: restUrl + '/addresses/' + id,
                method: 'DELETE',
                xhrFields: { withCredentials: true },
                success: function (response) {
                    loadUserAddresses();
                },
                error: function (xhr, status, error) {
                    alert('خطا در حذف آدرس');
                }
            });
        }
    });

    $('#boom-add-new-address').click(function () {
        $('#boom-address-popup').removeClass('flex').addClass('hidden');
        $('#boom-new-address-popup').removeClass('hidden').addClass('flex');
    });

    $('#boom-close-new-address-popup').click(function () {
        $('#boom-new-address-popup').removeClass('flex').addClass('hidden');
    });

    $('#boom-new-address-popup').click(function (e) {
        if (e.target === this) {
            $(this).removeClass('flex').addClass('hidden');
        }
    });

    $('#boom-save-new-address').click(function () {
        var newAddress = {
            title: $('#new-address-title').val(),
            first_name: $('#new-address-fname').val(),
            last_name: $('#new-address-lname').val(),
            state: $('#new-address-state').val(),
            city: $('#new-address-city').val(),
            address: $('#new-address-address').val(),
            postcode: $('#new-address-postcode').val(),
            phone: $('#new-address-phone').val(),
            email: $('#new-address-email').val(),
            company: $('#new-address-company').val(),
            custom_fields: {}
        };
        $('.boom-custom-field-input').each(function () {
            var fieldName = $(this).data('field-name');
            var fieldValue;
            if ($(this).is(':checkbox')) {
                fieldValue = $(this).is(':checked') ? '1' : '0';
            } else if ($(this).is(':radio')) {
                if ($(this).is(':checked')) {
                    fieldValue = $(this).val();
                    newAddress.custom_fields[fieldName] = fieldValue;
                }
                return;
            } else {
                fieldValue = $(this).val();
            }
            if (fieldName) {
                newAddress.custom_fields[fieldName] = fieldValue;
            }
        });
        if (!newAddress.title) {
            alert('لطفا عنوان آدرس را وارد کنید');
            return;
        }
        $.ajax({
            url: restUrl + '/addresses',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(newAddress),
            credentials: 'include',
            xhrFields: { withCredentials: true },
            success: function (response) {
                if (response.success) {
                    $('#boom-new-address-popup input, #boom-new-address-popup textarea, #boom-new-address-popup select').val('');
                    $('#boom-new-address-popup input[type="checkbox"]').prop('checked', false);
                    $('#boom-new-address-popup').removeClass('flex').addClass('hidden');
                    selectedAddress = response.address;
                    fillAddressFields(response.address);
                    if (isLoggedIn) {
                        showAddressPreview(response.address);
                    }
                }
            },
            error: function () {
                alert('خطا در ذخیره آدرس');
            }
        });
    });

    if (mapEnabled) {
        var miniMap = null;
        var miniMarker = null;

        $('#boom-open-map-btn, #boom-edit-location-btn').click(function () {
            $('#boom-map-popup').removeClass('hidden').addClass('flex');
            setTimeout(function () {
                initMap();
            }, 100);
        });

        $('#boom-close-map-popup').click(function () {
            $('#boom-map-popup').removeClass('flex').addClass('hidden');
        });

        $('#boom-map-popup').click(function (e) {
            if (e.target === this) {
                $(this).removeClass('flex').addClass('hidden');
            }
        });

        $('#boom-confirm-location').click(function () {
            if (selectedLat && selectedLng) {
                $('#boom_location_lat').val(selectedLat);
                $('#boom_location_lng').val(selectedLng);
                showMiniMap(selectedLat, selectedLng);
                $('#boom-map-popup').removeClass('flex').addClass('hidden');
            } else {
                alert('لطفا یک موقعیت روی نقشه انتخاب کنید');
            }
        });

        function initMap() {
            if (boomMap) {
                boomMap.invalidateSize();
                return;
            }

            if (mapProvider === 'neshan') {
                boomMap = new L.Map('boom-map-container', {
                    key: mapApiKey,
                    maptype: 'neshan',
                    poi: true,
                    traffic: false,
                    center: [defaultLat, defaultLng],
                    zoom: defaultZoom
                });
            } else {
                boomMap = L.map('boom-map-container').setView([defaultLat, defaultLng], defaultZoom);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap'
                }).addTo(boomMap);
            }

            boomMap.on('click', function (e) {
                selectedLat = e.latlng.lat;
                selectedLng = e.latlng.lng;
                if (boomMarker) {
                    boomMarker.setLatLng(e.latlng);
                } else {
                    boomMarker = L.marker(e.latlng).addTo(boomMap);
                }
                $('#boom-map-selected-address').text('موقعیت: ' + selectedLat.toFixed(6) + ', ' + selectedLng.toFixed(6));
            });
        }

        function showMiniMap(lat, lng) {
            $('#boom-map-select-container').addClass('hidden');
            $('#boom-map-preview-container').removeClass('hidden');

            if (mapProvider === 'neshan') {
                setTimeout(function () {
                    if (miniMap) {
                        miniMap.setView([lat, lng], 15);
                        if (miniMarker) {
                            miniMarker.setLatLng([lat, lng]);
                        } else {
                            miniMarker = L.marker([lat, lng]).addTo(miniMap);
                        }
                    } else {
                        miniMap = new L.Map('boom-mini-map', {
                            key: mapApiKey,
                            maptype: 'neshan',
                            poi: false,
                            traffic: false,
                            center: [lat, lng],
                            zoom: 15,
                            zoomControl: false,
                            dragging: false,
                            scrollWheelZoom: false
                        });
                        miniMarker = L.marker([lat, lng]).addTo(miniMap);
                    }
                }, 100);
            } else {
                setTimeout(function () {
                    if (miniMap) {
                        miniMap.setView([lat, lng], 15);
                        if (miniMarker) {
                            miniMarker.setLatLng([lat, lng]);
                        } else {
                            miniMarker = L.marker([lat, lng]).addTo(miniMap);
                        }
                    } else {
                        miniMap = L.map('boom-mini-map', {
                            zoomControl: false,
                            dragging: false,
                            scrollWheelZoom: false
                        }).setView([lat, lng], 15);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: ''
                        }).addTo(miniMap);
                        miniMarker = L.marker([lat, lng]).addTo(miniMap);
                    }
                }, 100);
            }
        }
    }

    // جلوگیری از reload بی‌نهایت
    var reloadCount = parseInt(sessionStorage.getItem('boom_reload_count') || '0');
    var lastReloadTime = parseInt(sessionStorage.getItem('boom_last_reload') || '0');
    var now = Date.now();

    // اگر بیش از 3 بار در 30 ثانیه reload شده، متوقف شو
    if (now - lastReloadTime > 30000) {
        reloadCount = 0;
    }

    var refreshTimeout;
    var ajaxCallInProgress = false;
    $(document.body).on('update_checkout', function () {
        ajaxCallInProgress = true;
        clearTimeout(refreshTimeout);
        // فقط اگر ووکامرس خودش این کار را نمی‌کند، انجام بده
        // این timeout را بسیار طولانی‌تر می‌کنیم تا با ووکامرس تداخل نداشته باشد
        refreshTimeout = setTimeout(function () {
            ajaxCallInProgress = false;
        }, 15000);
    });
    $(document.body).on('updated_checkout', function () {
        ajaxCallInProgress = false;
        clearTimeout(refreshTimeout);
    });
    $(document.body).on('checkout_error', function (event, error_message) {
        // فقط در صورت خطای nonce و اگر تعداد reload کم است
        if (error_message && (error_message.includes('403') || error_message.includes('nonce'))) {
            if (reloadCount < 2) {
                reloadCount++;
                sessionStorage.setItem('boom_reload_count', reloadCount.toString());
                sessionStorage.setItem('boom_last_reload', Date.now().toString());
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
        }
    });
    // reload هر 30 دقیقه برای refresh session
    setTimeout(function () {
        location.reload();
    }, 1800000);

    function initPersianDatepickers() {
        if (typeof $.fn.persianDatepicker !== 'undefined') {
            $('.boom-persian-date').each(function () {
                if (!$(this).data('persianDatepicker')) {
                    $(this).persianDatepicker({
                        format: 'YYYY/MM/DD',
                        initialValue: false,
                        autoClose: true,
                        calendarType: 'persian',
                        toolbox: {
                            calendarSwitch: {
                                enabled: false
                            }
                        },
                        navigator: {
                            scroll: {
                                enabled: true
                            }
                        },
                        timePicker: {
                            enabled: false
                        },
                        dayPicker: {
                            enabled: true
                        },
                        monthPicker: {
                            enabled: true
                        },
                        yearPicker: {
                            enabled: true
                        },
                        onSelect: function (unix) {
                            $(this).trigger('change');
                        }
                    });
                }
            });
        }
    }
    initPersianDatepickers();
    $('#boom-new-address-popup').on('show', function () {
        setTimeout(initPersianDatepickers, 100);
    });

    // Refill fields after WooCommerce updates checkout (it may clear some values)
    $(document.body).on('updated_checkout', function () {
        if (window.boomSelectedAddress) {
            var addr = window.boomSelectedAddress;
            setTimeout(function () {
                // Refill phone if empty
                var $phone = $('#billing_phone');
                if ($phone.length && !$phone.val()) {
                    var phone = addr.phone ? addr.phone.toString().replace(/[^\d]/g, '') : '';
                    if (phone.length === 10 && phone.charAt(0) === '9') {
                        phone = '0' + phone;
                    }
                    if (phone) {
                        $phone.val(phone).trigger('change').trigger('input');
                    }
                }
                // Refill address if empty
                var $address = $('#billing_address_1');
                if ($address.length && !$address.val() && addr.address) {
                    $address.val(addr.address).trigger('change').trigger('input').trigger('keyup');
                }
                // Refill state if empty
                var $state = $('#billing_state');
                if ($state.length && !$state.val() && addr.state) {
                    if ($state.is('select')) {
                        var stateFound = false;
                        $state.find('option').each(function () {
                            var optText = $(this).text().trim();
                            var optVal = $(this).val();
                            if (optText === addr.state || optVal === addr.state ||
                                optText.indexOf(addr.state) !== -1 || addr.state.indexOf(optText) !== -1) {
                                $state.val(optVal);
                                stateFound = true;
                                return false;
                            }
                        });
                        if (!stateFound) {
                            $state.append('<option value="' + addr.state + '" selected>' + addr.state + '</option>');
                        }
                        if ($state.hasClass('select2-hidden-accessible')) {
                            $state.trigger('change.select2');
                        }
                        $state.trigger('change');
                    } else {
                        $state.val(addr.state).trigger('change').trigger('input');
                    }
                }
                // Refill city if empty (با چک کامل)
                var $city = $('#billing_city');
                if ($city.length && !$city.val() && addr.city) {
                    if ($city.is('select')) {
                        var cityFound = false;
                        $city.find('option').each(function () {
                            var optText = $(this).text().trim();
                            var optVal = $(this).val();
                            if (optText === addr.city || optVal === addr.city ||
                                optText.indexOf(addr.city) !== -1 || addr.city.indexOf(optText) !== -1) {
                                $city.val(optVal);
                                cityFound = true;
                                return false;
                            }
                        });
                        if (!cityFound) {
                            $city.append('<option value="' + addr.city + '" selected>' + addr.city + '</option>');
                        }
                        if ($city.hasClass('select2-hidden-accessible')) {
                            $city.trigger('change.select2');
                        }
                        $city.trigger('change');
                    } else {
                        $city.val(addr.city).trigger('change').trigger('input');
                    }
                }
            }, 300);

            // Second check with longer delay
            setTimeout(function () {
                var $address = $('#billing_address_1');
                if ($address.length && !$address.val() && addr.address) {
                    $address.val(addr.address).trigger('change').trigger('input').trigger('keyup');
                }
            }, 800);
        }
    });

    // Also handle click on place order button (before form submission)
    $(document).on('click', '#place_order', function (e) {
        // پر کردن فیلدهای مخفی با مقادیر پیش‌فرض
        var $country = $('#billing_country');
        var $state = $('#billing_state');
        var $city = $('#billing_city');
        var $postcode = $('#billing_postcode');
        var $address = $('#billing_address_1');

        // اگر کشور خالی است، پیش‌فرض IR
        if ($country.length && !$country.val()) {
            $country.val('IR').trigger('change');
        }

        // پر کردن فیلدهای مخفی (غیرفعال شده) با مقدار پیش‌فرض
        if ($state.length && $state.closest('.boom-hidden-field').length && !$state.val()) {
            $state.val('-').trigger('change');
        }
        if ($city.length && $city.closest('.boom-hidden-field').length && !$city.val()) {
            $city.val('-').trigger('change');
        }
        if ($postcode.length && $postcode.closest('.boom-hidden-field').length && !$postcode.val()) {
            $postcode.val('0000000000').trigger('change');
        }
        if ($address.length && $address.closest('.boom-hidden-field').length && !$address.val()) {
            $address.val('-').trigger('change');
        }

        if (window.boomSelectedAddress) {
            var addr = window.boomSelectedAddress;
            var $phone = $('#billing_phone');

            // Force fill all required fields
            if ($address.length && !$address.val() && addr.address) {
                $address.val(addr.address).trigger('change').trigger('input').trigger('keyup');
            }
            if ($phone.length && !$phone.val() && addr.phone) {
                var phone = addr.phone.toString().replace(/[^\d]/g, '');
                if (phone.length === 10 && phone.charAt(0) === '9') {
                    phone = '0' + phone;
                }
                $phone.val(phone).trigger('change').trigger('input').trigger('keyup');
            }
            if ($city.length && !$city.val() && addr.city) {
                if ($city.is('select')) {
                    var cityFound = false;
                    $city.find('option').each(function () {
                        var optText = $(this).text().trim();
                        var optVal = $(this).val();
                        if (optText === addr.city || optVal === addr.city ||
                            optText.indexOf(addr.city) !== -1 || addr.city.indexOf(optText) !== -1) {
                            $city.val(optVal).trigger('change');
                            cityFound = true;
                            return false;
                        }
                    });
                    // اگر شهر پیدا نشد، گزینه جدید اضافه کن
                    if (!cityFound) {
                        $city.append('<option value="' + addr.city + '" selected>' + addr.city + '</option>');
                        $city.trigger('change');
                    }
                } else {
                    $city.val(addr.city).trigger('change').trigger('input');
                }
            }
            if ($state.length && !$state.val() && addr.state) {
                if ($state.is('select')) {
                    var stateFound = false;
                    $state.find('option').each(function () {
                        var optText = $(this).text().trim();
                        var optVal = $(this).val();
                        if (optText === addr.state || optVal === addr.state ||
                            optText.indexOf(addr.state) !== -1 || addr.state.indexOf(optText) !== -1) {
                            $state.val(optVal).trigger('change');
                            stateFound = true;
                            return false;
                        }
                    });
                    // اگر استان پیدا نشد، گزینه جدید اضافه کن
                    if (!stateFound) {
                        $state.append('<option value="' + addr.state + '" selected>' + addr.state + '</option>');
                        $state.trigger('change');
                    }
                } else {
                    $state.val(addr.state).trigger('change').trigger('input');
                }
            }
            if ($postcode.length && !$postcode.val() && addr.postcode) {
                $postcode.val(addr.postcode).trigger('change').trigger('input');
            }

            // حذف کلاس‌های خطا و پیام‌های validation
            $address.removeClass('woocommerce-invalid woocommerce-invalid-required-field parsley-error');
            $address.closest('.form-row').removeClass('woocommerce-invalid woocommerce-invalid-required-field');
            $('.woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message').remove();
        }
    });
});

jQuery(window).on('load', function () {
    setTimeout(function () {
        if (typeof jQuery.fn.persianDatepicker !== 'undefined') {
            jQuery('.boom-persian-date').each(function () {
                if (!jQuery(this).data('persianDatepicker')) {
                    jQuery(this).persianDatepicker({
                        format: 'YYYY/MM/DD',
                        initialValue: false,
                        autoClose: true,
                        calendarType: 'persian',
                        toolbox: {
                            calendarSwitch: { enabled: false }
                        }
                    });
                }
            });
        }
    }, 500);
});
