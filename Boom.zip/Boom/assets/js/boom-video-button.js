/**
 * دکمه «افزودن ویدیو / آیفریم» برای ویرایشگر کلاسیک وردپرس (TinyMCE)
 *
 * کاربر کد امبد (مثلاً امبد آپارات یا یوتیوب) را می‌چسباند؛ این افزونه فقط
 * خودِ تگ <iframe> را استخراج می‌کند و آن را در یک قاب واکنش‌گرا با کلاس
 * boom-embed درج می‌کند. به این ترتیب نیازی به تگ <style> نیست و در فرانت
 * React به‌صورت واکنش‌گرا رندر می‌شود. فیلتر kses قالب هم اجازه‌ی حفظ <iframe>
 * را می‌دهد تا وردپرس آن را هنگام ذخیره حذف نکند.
 */
(function () {
    if (typeof tinymce === 'undefined') return;

    tinymce.PluginManager.add('boom_video_button', function (editor) {
        editor.addButton('boom_video_button', {
            text: 'افزودن ویدیو / آیفریم',
            icon: false,
            tooltip: 'افزودن ویدیو با کد iframe (آپارات، یوتیوب و ...)',
            onclick: function () {
                editor.windowManager.open({
                    title: 'افزودن ویدیو / آیفریم',
                    width: 560,
                    height: 260,
                    body: [
                        {
                            type: 'textbox',
                            name: 'code',
                            label: 'کد امبد یا iframe',
                            multiline: true,
                            minWidth: 520,
                            minHeight: 150,
                            value: ''
                        }
                    ],
                    onsubmit: function (e) {
                        var input = (e.data.code || '').trim();
                        if (!input) {
                            return;
                        }

                        // استخراج نخستین تگ iframe از ورودی
                        var match = input.match(/<iframe[\s\S]*?<\/iframe>/i);
                        var iframe = match ? match[0] : null;

                        // اگر iframe نبود ولی ورودی یک URL بود، خودمان iframe می‌سازیم
                        if (!iframe) {
                            var urlMatch = input.match(/https?:\/\/[^\s"'<>]+/i);
                            if (urlMatch) {
                                iframe = '<iframe src="' + urlMatch[0] + '" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>';
                            }
                        }

                        if (!iframe) {
                            editor.windowManager.alert('کد iframe معتبری یافت نشد. کل کد امبد را وارد کنید.');
                            return;
                        }

                        // پاکسازی: حذف width/height ثابت تا قاب واکنش‌گرا اندازه را کنترل کند
                        iframe = iframe
                            .replace(/\swidth="[^"]*"/i, '')
                            .replace(/\sheight="[^"]*"/i, '');

                        var html = '<div class="boom-embed">' + iframe + '</div><p>&nbsp;</p>';
                        editor.insertContent(html);
                    }
                });
            }
        });
    });
})();
