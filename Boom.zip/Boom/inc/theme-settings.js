(function ($) {
  $(document).ready(function () {

    const customCss = `
      /* ──── Design System: Brand #098f81 ──── */
      :root {
        --brand: #098f81;
        --brand-light: #0ba798;
        --brand-dark: #077a6d;
        --brand-bg: #edf8f6;
        --brand-bg-subtle: #f5fbfa;
        --brand-accent: rgba(9,143,129,0.08);
        --surface: #ffffff;
        --bg: #f8fafb;
        --border: #e5e9ed;
        --border-light: #f0f2f4;
        --text-primary: #1a2332;
        --text-secondary: #5a6578;
        --text-muted: #8c95a4;
        --danger: #ef4444;
        --danger-hover: #dc2626;
        --radius-sm: 6px;
        --radius-md: 10px;
        --radius-lg: 14px;
        --radius-xl: 18px;
        --shadow-xs: 0 1px 2px rgba(0,0,0,0.04);
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
        --shadow-md: 0 4px 12px rgba(0,0,0,0.07);
        --shadow-lg: 0 8px 24px rgba(0,0,0,0.08);
        --transition: 0.2s cubic-bezier(0.4,0,0.2,1);
      }

      /* ──── Wrapper / Page ──── */
      .wrap { max-width: 1200px; }
      .wrap h1 { font-size: 22px !important; font-weight: 700 !important; color: var(--text-primary) !important; letter-spacing: -0.3px; margin-bottom: 24px !important; }

      /* ──── Tabs Layout ──── */
      .custom-tabs-container {
        display: flex;
        flex-direction: row-reverse;
        align-items: flex-start;
        gap: 0;
        background: var(--surface);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border);
        overflow: hidden;
        min-height: 520px;
      }

      .custom-tabs-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        margin: 0;
        min-width: 200px;
        width: 200px;
        flex-shrink: 0;
        padding: 12px 8px;
        background: var(--bg);
        border-left: 1px solid var(--border);
        order: 2;
        align-self: stretch;
        overflow: hidden;
      }

      .custom-tab-btn {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 11px 14px;
        width: 100%;
        text-align: right;
        border-radius: var(--radius-sm);
        transition: all var(--transition);
        background: transparent;
        border: none !important;
        font-size: 13.5px;
        font-weight: 500;
        color: var(--text-secondary);
        cursor: pointer;
        outline: none !important;
        line-height: 1.4;
        position: relative;
      }

      .custom-tab-btn:hover {
        background: var(--brand-accent);
        color: var(--brand);
      }

      .custom-tab-btn.active,
      .custom-tab-btn:focus {
        background: var(--brand-bg) !important;
        color: var(--brand) !important;
        font-weight: 600;
      }

      .custom-tab-btn.active::before {
        content: '';
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 3px;
        height: 60%;
        background: var(--brand);
        border-radius: 0 3px 3px 0;
      }

      .custom-tab-content {
        flex: 1;
        order: 1;
        padding: 28px 32px;
        min-height: 480px;
        min-width: 0;
        overflow: hidden;
      }

      @media (max-width: 900px) {
        .custom-tabs-container { flex-direction: column; border-radius: var(--radius-lg); }
        .custom-tabs-list {
          flex-direction: row;
          width: 100%;
          min-width: unset;
          border-left: none;
          border-bottom: 1px solid var(--border);
          padding: 8px;
          overflow-x: auto;
          gap: 4px;
        }
        .custom-tab-btn {
          white-space: nowrap;
          padding: 10px 16px;
          width: auto;
          font-size: 13px;
        }
        .custom-tab-btn.active::before { display: none; }
        .custom-tab-content { padding: 20px 16px; }
      }

      /* ──── Form Elements ──── */
      .form-table th { font-size: 13px; font-weight: 600; color: var(--text-primary); padding: 16px 10px 16px 0; vertical-align: top; }
      .form-table td { padding: 12px 0; }
      .form-table input[type="text"],
      .form-table input[type="url"],
      .form-table input[type="number"],
      .form-table input[type="email"],
      .form-table textarea,
      .form-table select {
        border: 1.5px solid var(--border) !important;
        border-radius: var(--radius-sm) !important;
        padding: 9px 12px !important;
        font-size: 13.5px !important;
        color: var(--text-primary) !important;
        background: var(--surface) !important;
        transition: border-color var(--transition), box-shadow var(--transition) !important;
        outline: none !important;
      }
      .form-table input[type="text"]:focus,
      .form-table input[type="url"]:focus,
      .form-table input[type="number"]:focus,
      .form-table input[type="email"]:focus,
      .form-table textarea:focus,
      .form-table select:focus {
        border-color: var(--brand) !important;
        box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important;
      }

      /* ──── Save Button ──── */
      .custom-tab-content .submit {
        margin-top: 32px !important;
        padding-top: 24px !important;
        border-top: 1px solid var(--border-light) !important;
        text-align: right !important;
        position: relative !important;
        bottom: 0 !important;
      }
      .custom-tab-content .submit .button-primary,
      .wrap .submit .button-primary {
        background: var(--brand) !important;
        border-color: var(--brand) !important;
        color: #fff !important;
        border-radius: var(--radius-sm) !important;
        padding: 10px 28px !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        box-shadow: 0 1px 3px rgba(9,143,129,0.2) !important;
        transition: all var(--transition) !important;
        cursor: pointer;
        letter-spacing: 0;
      }
      .custom-tab-content .submit .button-primary:hover,
      .wrap .submit .button-primary:hover {
        background: var(--brand-dark) !important;
        border-color: var(--brand-dark) !important;
        box-shadow: 0 4px 12px rgba(9,143,129,0.25) !important;
        transform: translateY(-1px);
      }

      /* ──── List Wrapper ──── */
      .custom-list-wrap {
        background: var(--bg) !important;
        border-radius: var(--radius-md) !important;
        box-shadow: none !important;
        border: 1px solid var(--border) !important;
        padding: 12px !important;
      }
      .custom-list-items { margin-bottom: 8px; }

      /* ──── List Items ──── */
      .custom-list-item {
        background: var(--surface) !important;
        border: 1.5px solid var(--border) !important;
        box-shadow: var(--shadow-xs) !important;
        margin-bottom: 8px;
        border-radius: var(--radius-md) !important;
        padding: 14px 16px !important;
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
        transition: border-color var(--transition), box-shadow var(--transition);
      }
      .custom-list-item:hover {
        border-color: rgba(9,143,129,0.25) !important;
        box-shadow: var(--shadow-sm) !important;
      }
      .custom-list-item input,
      .custom-list-item textarea {
        border-radius: var(--radius-sm) !important;
        border: 1.5px solid var(--border) !important;
        padding: 8px 10px !important;
        font-size: 13px !important;
        color: var(--text-primary) !important;
        transition: border-color var(--transition), box-shadow var(--transition) !important;
        background: var(--surface) !important;
      }
      .custom-list-item input:focus,
      .custom-list-item textarea:focus,
      .custom-list-item select:focus {
        border-color: var(--brand) !important;
        box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important;
        outline: none !important;
      }
      .custom-list-item select {
        border-radius: var(--radius-sm) !important;
        border: 1.5px solid var(--border) !important;
        padding: 8px 10px !important;
        font-size: 13px !important;
        background: var(--surface) !important;
        transition: border-color var(--transition) !important;
      }
      .custom-list-item input[type="text"] { min-width: 100px; }
      .custom-list-item .field-date { width: 120px; }
      .custom-list-item .field-time { width: 90px; }
      .custom-list-item .field-title, .custom-list-item .field-discount-title { flex: 1; min-width: 120px; }
      .custom-list-item .field-small-text { flex: 1; min-width: 100px; }
      .custom-list-item .field-link { flex: 2; min-width: 180px; }
      .custom-list-item .field-html { width: 100%; height: 60px; }
      .custom-list-item label { font-size: 12px; color: var(--text-muted); margin-left: 4px; font-weight: 500; }
      .custom-list-item .field-image-preview {
        max-width: 56px;
        max-height: 56px;
        border-radius: var(--radius-sm);
        border: 1.5px solid var(--border);
        margin-left: 8px;
        object-fit: cover;
      }

      /* ──── Buttons ──── */
      .custom-list-item .button {
        background: var(--danger) !important;
        color: #fff !important;
        border: none !important;
        border-radius: var(--radius-sm) !important;
        padding: 7px 16px !important;
        cursor: pointer;
        font-size: 12.5px !important;
        font-weight: 500 !important;
        transition: all var(--transition) !important;
      }
      .custom-list-item .button:hover {
        background: var(--danger-hover) !important;
        box-shadow: 0 2px 8px rgba(239,68,68,0.2) !important;
      }
      .custom-list-item .button.button-upload {
        background: var(--brand) !important;
        margin-right: 6px;
      }
      .custom-list-item .button.button-upload:hover {
        background: var(--brand-dark) !important;
        box-shadow: 0 2px 8px rgba(9,143,129,0.2) !important;
      }
      .custom-list-wrap .button-primary {
        background: var(--brand) !important;
        border-color: var(--brand) !important;
        color: #fff !important;
        border-radius: var(--radius-sm) !important;
        padding: 9px 20px !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        transition: all var(--transition) !important;
      }
      .custom-list-wrap .button-primary:hover {
        background: var(--brand-dark) !important;
        border-color: var(--brand-dark) !important;
        box-shadow: 0 4px 12px rgba(9,143,129,0.2) !important;
      }

      /* ──── Drag Handle ──── */
      .drag-handle { cursor: grab; color: var(--text-muted); font-size: 16px; opacity: 0.5; transition: opacity var(--transition); }
      .drag-handle:hover { opacity: 1; }
      .drag-handle-submenu { user-select: none; cursor: grab; color: var(--text-muted); }

      /* ──── Job Positions ──── */
      .job-position-item { background: var(--surface); padding: 16px; margin-bottom: 10px; border-radius: var(--radius-md); border: 1.5px solid var(--border); }
      .job-position-title { font-size: 15px; font-weight: 600; margin-bottom: 10px; color: var(--text-primary); }
      .job-position-description { margin-bottom: 10px; color: var(--text-secondary); font-size: 13.5px; }
      .job-position-type { display: inline-block; padding: 4px 10px; background: var(--brand-bg); color: var(--brand); border-radius: 20px; margin-right: 10px; font-size: 12px; font-weight: 600; }
      .job-position-skills { margin-top: 10px; }
      .job-skill-tag { display: inline-block; padding: 3px 8px; background: var(--bg); border: 1px solid var(--border); border-radius: 20px; margin: 2px; font-size: 12px; color: var(--text-secondary); }

      /* ──── Mega Menu ──── */
      .megamenu-item { position: relative; }
      .megamenu-item .submenu-item:hover { box-shadow: var(--shadow-sm); transform: translateY(-1px); }
      .megamenu-item .field-child-name:focus,
      .megamenu-item .field-child-link:focus { border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .megamenu-item .remove-submenu-btn:hover { background: var(--danger-hover) !important; }
      .megamenu-item .add-submenu-btn:hover { box-shadow: 0 2px 8px rgba(9,143,129,0.2); }

      /* ──── Logos ──── */
      .logos-container { width: 100%; margin-top: 10px; }
      .logo-item {
        background: var(--surface) !important;
        border: 1.5px solid var(--border) !important;
        border-radius: var(--radius-md) !important;
        padding: 14px !important;
        margin: 8px 0 !important;
        transition: border-color var(--transition) !important;
      }
      .logo-item:hover { border-color: rgba(9,143,129,0.25) !important; }
      .logo-item h4 { color: var(--text-primary) !important; margin: 0 0 10px 0 !important; font-size: 13.5px !important; font-weight: 600 !important; }
      .logo-item input[type="text"] { border: 1.5px solid var(--border) !important; border-radius: var(--radius-sm) !important; padding: 8px 10px !important; background: var(--surface) !important; }
      .logo-item .button { font-size: 12px !important; padding: 6px 12px !important; }

      /* ──── Stories ──── */
      .story-card { position: relative; }
      .story-card .field-story-title { transition: border-color var(--transition); }
      .story-card .field-story-title:focus { border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .story-images-container { margin-top: 16px; }
      .story-image-item { position: relative; transition: all 0.25s ease; }
      .story-image-item:hover { transform: translateY(-1px); box-shadow: var(--shadow-md) !important; }
      .story-image-item input:focus, .story-image-item select:focus { outline: none !important; border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .story-image-item .button-upload-story-image:hover { background: var(--brand-dark) !important; }
      .story-image-item .remove-story-image-btn:hover { background: var(--danger-hover) !important; }
      .add-story-image-btn:hover { background: var(--brand-light) !important; box-shadow: 0 4px 12px rgba(9,143,129,0.2) !important; }
      .button-upload-story-thumbnail:hover { background: var(--brand-dark) !important; }
    `;
    if (!document.getElementById('custom-theme-settings-css')) {
      $('<style id="custom-theme-settings-css">' + customCss + '</style>').appendTo('head');
    }


    const $form = $('.wrap form');
    if ($form.length) {

      const $allContent = $('<div class="custom-tab-content" id="tab-content-general"></div>');
      $form.children().not('.custom-tabs-container, .about-page-field').appendTo($allContent);

      const $mainPageContent = $('<div class="custom-tab-content" id="tab-content-main" style="display:none;"><p>در این بخش تنظیمات صفحه اصلی قرار می‌گیرد.</p></div>');

      const $styleContent = $('<div class="custom-tab-content" id="tab-content-style" style="display:none;"><p>در این بخش تنظیمات استایل‌های مختلف قالب قرار می‌گیرد.</p></div>');

      const $jobsContent = $('<div class="custom-tab-content" id="tab-content-jobs" style="display:none;"></div>');

      const $aboutContent = $('<div class="custom-tab-content" id="tab-content-about" style="display:none;"><p>تنظیمات صفحه درباره ما</p></div>');

      const $contactContent = $('<div class="custom-tab-content" id="tab-content-contact" style="display:none;"><p>تنظیمات صفحه تماس با ما</p></div>');

      const $faqContent = $('<div class="custom-tab-content" id="tab-content-faq" style="display:none;"></div>');

      const $storiesContent = $('<div class="custom-tab-content" id="tab-content-stories" style="display:none;"></div>');

      const $notificationContent = $('<div class="custom-tab-content" id="tab-content-notification" style="display:none;"><p>تنظیمات اطلاعیه سایت</p></div>');

      const $securityContent = $('<div class="custom-tab-content" id="tab-content-security" style="display:none;"><p>تنظیمات امنیتی سایت</p></div>');

      const $fontContent = $('<div class="custom-tab-content" id="tab-content-font" style="display:none;"><p>تنظیمات فونت سایت</p></div>');

      const $customizationContent = $('<div class="custom-tab-content" id="tab-content-customization" style="display:none;"><p>سفارشی‌سازی با CSS و JavaScript</p></div>');

      const $translationsContent = $('<div class="custom-tab-content" id="tab-content-translations" style="display:none;"><p>تنظیمات ترجمه متن‌های سایت</p></div>');


      const $aboutFields = $('.about-page-field');
      if ($aboutFields.length) {
        const $table = $('<table class="form-table" role="presentation"></table>');
        $aboutFields.appendTo($table);
        $aboutContent.empty().append($table);
      }
      const $tabsList = $('<div class="custom-tabs-list"></div>');
      $tabsList.append('<button type="button" class="custom-tab-btn active" data-tab="general">تنظیمات عمومی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="main">صفحه اصلی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="style">تنظیمات استایل</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="jobs">موقعیت‌های شغلی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="about">صفحه درباره ما</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="contact">صفحه تماس با ما</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="faq">سوالات متداول</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="stories">استوری‌ها</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="notification">اطلاعیه</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="security">تنظیمات امنیتی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="font">تنظیمات فونت</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="customization">سفارشی‌سازی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="translations">ترجمه متن‌ها</button>');

      // دکمه‌های ذخیره بعداً در انتها اضافه خواهند شد

      const $tabsContainer = $('<div class="custom-tabs-container"></div>');
      $tabsContainer.append($tabsList).append($allContent).append($mainPageContent).append($styleContent).append($jobsContent).append($aboutContent).append($contactContent).append($faqContent).append($storiesContent).append($notificationContent).append($securityContent).append($fontContent).append($customizationContent).append($translationsContent);
      $form.prepend($tabsContainer);

      $tabsList.on('click', '.custom-tab-btn', function () {
        $tabsList.find('.custom-tab-btn').removeClass('active');
        $(this).addClass('active');
        const tabName = $(this).data('tab');
        $('.custom-tab-content').hide();
        $('#tab-content-' + tabName).show();

        // رفع مشکل TinyMCE در تب‌های درباره ما و تماس با ما
        if (tabName === 'about' || tabName === 'contact') {
          setTimeout(function () {
            if (typeof tinyMCE !== 'undefined') {
              tinyMCE.editors.forEach(function (editor) {
                if (editor && editor.id && $('#tab-content-' + tabName).find('#' + editor.id).length > 0) {
                  tinyMCE.execCommand('mceRemoveEditor', true, editor.id);
                  tinyMCE.execCommand('mceAddEditor', true, editor.id);
                }
              });
            }
          }, 100);
        }
      });
    }

    $('.custom-list-wrap').each(function () {
      const $wrapper = $(this);
      const name = $wrapper.data('name');
      const $textarea = $wrapper.next('textarea.custom-list-json');
      let items = [];

      try {
        items = JSON.parse($textarea.val()) || [];
      } catch (e) {
        items = [];
      }

      // Migration: تبدیل داده‌های قدیمی site_menu (بدون children) به ساختار جدید
      if (name === 'site_menu') {
        items = items.map(item => {
          // اگر children وجود نداشته باشد، یک آرایه خالی اضافه کنیم
          if (!item.children) {
            item.children = [];
          }
          return item;
        });
      }


      function assignUUIDs() {
        items.forEach(item => {
          if (!item._uuid) {
            item._uuid = Math.random().toString(36).substring(2, 10);
          }
          // اختصاص UUID به children در site_menu
          if (name === 'site_menu' && item.children && Array.isArray(item.children)) {
            item.children.forEach(child => {
              if (!child._uuid) {
                child._uuid = 'child-' + Math.random().toString(36).substring(2, 10);
              }
            });
          }
        });
      }

      function render() {
        assignUUIDs();
        $wrapper.empty();
        const $list = $('<div class="custom-list-items"></div>');


        let isHomeSections = (name === 'home_sections');
        let isSiteMenu = (name === 'site_menu');

        let isAboutBoxes = (name === 'about_boxes');
        if (isHomeSections || isSiteMenu) {
          $list.sortable({
            handle: '.drag-handle',
            axis: 'y',
            update: function () {
              let newItems = [];
              $list.find('.custom-list-item').each(function () {
                const uuid = $(this).data('id');
                const found = items.find(i => i._uuid === uuid);
                if (found) newItems.push(found);
              });
              items = newItems;
              save();
              render();
            }
          });
        }

        items.forEach((item, idx) => {
          const $item = $(`<div class="custom-list-item" data-id="${item._uuid}"></div>`);

          if (isHomeSections) {
            $item.append('<span class="drag-handle" style="cursor:grab;font-size:20px;margin-left:8px;">☰</span>');
          }

          if (name === 'slider') {
            $item.append(`<input type="text" placeholder="عنوان تخفیف" class="field-discount-title" value="${item.discount_title || ''}">`);
            $item.append(`<input type="text" placeholder="عنوان" class="field-title" value="${item.title || ''}">`);
            $item.append(`<input type="text" placeholder="نوشته کوچک" class="field-small-text" value="${item.small_text || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);

            $item.append(`<input type="text" placeholder="تاریخ (مثال: 1403/04/18)" class="field-date" value="${item.date_fa || ''}">`);
            $item.append(`<input type="time" placeholder="ساعت" class="field-time" value="${item.time || ''}">`);

            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
          } else if (name === 'user_panel_slider') {
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'product_categories') {
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-icon" value="${item.icon || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.icon) $item.append(`<img src="${item.icon}" class="field-image-preview">`);
            $item.append(`<input type="text" placeholder="نام" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'socials') {
            $item.append(`<textarea type="text" placeholder="آیکون" class="field-icon">${item.icon || ''}</textarea>`);
            $item.append(`<input type="text" placeholder="نام" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'site_menu') {
            // هندل درگ برای آیتم‌های سطح ۱
            $item.prepend('<span class="drag-handle" style="cursor:grab;font-size:20px;margin-left:8px;color:var(--text-muted);opacity:0.5;transition:opacity 0.2s;">☰</span>');

            // طراحی UI برای مگا منو دو سطحی
            const $menuSection = $('<div class="megamenu-item" style="background:linear-gradient(135deg, #f0f4ff 0%, #e8f0ff 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #4285f4;box-shadow:0 4px 12px rgba(66,133,244,0.15);width:100%;"></div>');

            // هدر آیتم منو اصلی
            $menuSection.append(`
              <div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(66,133,244,0.3);">
                <span style="font-size:22px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M10 6a4 4 0 1 0-8 0a4 4 0 0 0 8 0Zm0 12a4 4 0 1 0-8 0a4 4 0 0 0 8 0ZM22 6a4 4 0 1 0-8 0a4 4 0 0 0 8 0Zm0 12a4 4 0 1 0-8 0a4 4 0 0 0 8 0Z" /></svg></span>
                <h4 style="margin:0;color:#1a73e8;font-size:15px;font-weight:600;">آیتم منوی اصلی (سطح 1)</h4>
              </div>
            `);

            // ردیف اول: نام، لینک و آیکون
            $menuSection.append(`
              <div style="display:grid;grid-template-columns:1fr 1fr 120px;gap:12px;margin-bottom:16px;">
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">🏷️</span>
                    نام منو:
                  </label>
                  <input type="text" placeholder="مثال: لپ‌تاپ" class="field-name" value="${item.name || ''}" style="width:100%;padding:10px 12px;border:1px solid #4285f4;border-radius:6px;font-size:14px;background:#fff;">
                </div>
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">🔗</span>
                    لینک:
                  </label>
                  <input type="text" placeholder="/category/laptop" class="field-link" value="${item.link || ''}" style="width:100%;padding:10px 12px;border:1px solid #4285f4;border-radius:6px;font-size:14px;background:#fff;">
                </div>
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">✨</span>
                    آیکون:
                  </label>
                  <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #4285f4;border-radius:6px;font-size:11px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                </div>
              </div>
            `);

            // بخش زیرمنوها (children)
            const children = item.children || [];
            const $childrenSection = $('<div class="megamenu-children" style="background:rgba(255,255,255,0.6);padding:14px;border-radius:8px;margin-top:10px;"></div>');

            $childrenSection.append(`
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <div style="display:flex;align-items:center;">
                  <span style="font-size:18px;margin-left:6px;">📂</span>
                  <h5 style="margin:0;color:#5f6368;font-size:14px;font-weight:600;">زیرمنوها (سطح 2)</h5>
                  <span style="margin-right:8px;background:#e8f0fe;color:#1967d2;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">${children.length} مورد</span>
                </div>
                <button type="button" class="button button-primary add-submenu-btn" data-parent-id="${item._uuid}" style="padding:6px 14px;font-size:12px;">
                  ➕ افزودن زیرمنو
                </button>
              </div>
            `);

            const $childrenList = $('<div class="children-list" style="display:flex;flex-direction:column;gap:8px;"></div>');

            children.forEach((child, childIdx) => {
              const $childItem = $(`
                <div class="submenu-item" data-child-id="${child._uuid || 'child-' + childIdx}" style="background:#fff;padding:12px;border-radius:6px;border:1px solid #dadce0;display:grid;grid-template-columns:30px 1fr 1fr 40px;gap:10px;align-items:center;transition:all 0.2s;">
                  <span style="color:#5f6368;font-size:18px;cursor:move;" class="drag-handle-submenu">⋮⋮</span>
                  <input type="text" placeholder="نام زیرمنو" class="field-child-name" value="${child.name || ''}" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                  <input type="text" placeholder="لینک زیرمنو" class="field-child-link" value="${child.link || ''}" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                  <button type="button" class="button remove-submenu-btn" style="padding:4px 8px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:18px;line-height:1;">×</button>
                </div>
              `);

              $childItem.find('.remove-submenu-btn').on('click', function () {
                $childItem.fadeOut(200, function () {
                  $childItem.remove();
                  save();
                });
              });

              $childrenList.append($childItem);
            });

            $childrenList.sortable({
              handle: '.drag-handle-submenu',
              axis: 'y',
              update: function () {
                save();
              }
            });

            $childrenSection.append($childrenList);
            $menuSection.append($childrenSection);
            $item.append($menuSection);

            // رویداد افزودن زیرمنو
            $item.find('.add-submenu-btn').on('click', function () {
              const parentId = $(this).data('parent-id');
              const $list = $item.find('.children-list');
              const newChildId = 'child-' + Date.now();

              const $newChild = $(`
                <div class="submenu-item" data-child-id="${newChildId}" style="background:#fff;padding:12px;border-radius:6px;border:1px solid #dadce0;display:grid;grid-template-columns:30px 1fr 1fr 40px;gap:10px;align-items:center;transition:all 0.2s;">
                  <span style="color:#5f6368;font-size:18px;cursor:move;" class="drag-handle-submenu">⋮⋮</span>
                  <input type="text" placeholder="نام زیرمنو" class="field-child-name" value="" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                  <input type="text" placeholder="لینک زیرمنو" class="field-child-link" value="" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                  <button type="button" class="button remove-submenu-btn" style="padding:4px 8px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:18px;line-height:1;">×</button>
                </div>
              `);

              $newChild.find('.remove-submenu-btn').on('click', function () {
                $newChild.fadeOut(200, function () {
                  $newChild.remove();
                  save();
                });
              });

              $list.append($newChild);

              // به‌روزرسانی شمارنده
              const count = $list.find('.submenu-item').length;
              $item.find('.megamenu-children h5 span').text(count + ' مورد');

              save();
            });

          } else if (name === 'navbar_menu') {
            $item.append(`<input type="text" placeholder="نام" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'job_positions_list') {
            $item.append(`<input type="text" class="field-title" placeholder="عنوان موقعیت شغلی" value="${item.title || ''}" style="width:100%;margin-bottom:10px;">`);
            $item.append(`<textarea class="field-description" placeholder="توضیحات موقعیت شغلی" style="width:100%;margin-bottom:10px;min-height:100px;">${item.description || ''}</textarea>`);
            const jobType = item.job_type || 'تمام وقت';
            $item.append(`
              <select class="field-job-type" style="margin-bottom:10px;width:200px;">
                <option value="تمام وقت"${jobType === 'تمام وقت' ? ' selected' : ''}>تمام وقت</option>
                <option value="پاره وقت"${jobType === 'پاره وقت' ? ' selected' : ''}>پاره وقت</option>
                <option value="دورکاری"${jobType === 'دورکاری' ? ' selected' : ''}>دورکاری</option>
                <option value="کارآموزی"${jobType === 'کارآموزی' ? ' selected' : ''}>کارآموزی</option>
              </select>
            `);
            $item.append(`<input type="text" class="field-skills" placeholder="مهارت‌ها (با کاما جدا کنید)" value="${item.skills || ''}" style="width:100%;">`);
          } else if (name === 'faq_list') {
            $item.append(`<input type="text" class="field-question" placeholder="سوال" value="${item.question || ''}" style="width:100%;margin-bottom:10px;">`);
            $item.append(`<textarea class="field-answer" placeholder="پاسخ" style="width:100%;margin-bottom:10px;min-height:100px;">${item.answer || ''}</textarea>`);
          } else if (name === 'site_badges') {
            $item.append(`<textarea placeholder="کد HTML" class="field-html">${item.html || ''}</textarea>`);
          } else if (name === 'footer_menu_1' || name === 'footer_menu_2') {
            $item.append(`<input type="text" placeholder="عنوان" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'home_sections') {
            $item.append(`<label>نوع سکشن:</label>`);
            const typeOptions = [
              { value: 'product_categories', text: 'دسته‌بندی محصولات' },
              { value: 'products', text: 'سکشن محصولات' },
              { value: 'special_products', text: 'محصولات فروش ویژه' },
              { value: 'site_badges', text: 'نمادها' },
              { value: 'blog_posts', text: 'سکشن پست‌های بلاگ' },
              { value: 'custom_html', text: 'HTML سفارشی' },
              { value: 'site_description_box', text: 'باکس توضیحات سایت' },
              { value: 'banners', text: 'سکشن بنر' },
              { value: 'slider', text: 'سکشن اسلایدر' },
              { value: 'logo_slider', text: 'اسلایدر لوگوها' },
              { value: 'spacer', text: 'فاصله' }
            ];
            const typeSelect = $('<select class="field-section-type"></select>');
            typeOptions.forEach(opt => {
              typeSelect.append(`<option value="${opt.value}"${item.type === opt.value ? ' selected' : ''}>${opt.text}</option>`);
            });
            $item.append(typeSelect);

            if (item.type === 'products') {
              // ساختار بهبود یافته برای سکشن محصولات
              const $productsSection = $('<div style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(156,39,176,0.15);"></div>');

              $productsSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 22c-.818 0-1.6-.33-3.163-.99C4.946 19.366 3 18.543 3 17.16V7m9 15c.818 0 1.6-.33 3.163-.99C19.054 19.366 21 18.543 21 17.16V7m-9 15V11.355M8.326 9.691L5.405 8.278C3.802 7.502 3 7.114 3 6.5s.802-1.002 2.405-1.778l2.92-1.413C10.13 2.436 11.03 2 12 2s1.871.436 3.674 1.309l2.921 1.413C20.198 5.498 21 5.886 21 6.5s-.802 1.002-2.405 1.778l-2.92 1.413C13.87 10.564 12.97 11 12 11s-1.871-.436-3.674-1.309M6 12l2 1m9-9L7 9" /></svg></span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات سکشن محصولات</h4>
              </div>`);

              // ردیف اول: آیکون و نام و لینک
              $productsSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5" d="M3 12c4.5 0 9-4.5 9-9c0 4.5 4.5 9 9 9c-4.5 0-9 4.5-9 9c0-4.5-4.5-9-9-9Zm-1 7.5c.833 0 2.5-1.667 2.5-2.5c0 .833 1.667 2.5 2.5 2.5c-.833 0-2.5 1.667-2.5 2.5c0-.833-1.667-2.5-2.5-2.5ZM16 5c1 0 3-2 3-3c0 1 2 3 3 3c-1 0-3 2-3 3c0-1-2-3-3-3Z" /></svg></span>
                      آیکون:
                    </label>
                    <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #e0fae2;border-radius:6px;font-size:12px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                      نام سکشن:
                    </label>
                    <input type="text" placeholder="مثال: محصولات پرفروش" class="field-name" value="${item.name || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-link" value="${item.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف دوم: جستجوی دسته‌بندی
              const selectedCats = item.product_cats || [];
              const $catList = $('<div class="field-product-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              selectedCats.forEach(cat => {
                $catList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });

              $productsSection.append(`
                <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;position:relative;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                    دسته‌بندی محصولات:
                  </label>
                  <input type="text" class="field-product-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #e0fae2;border-radius:8px;font-size:13px;background:#fff;transition:all 0.3s;">
                  <div class="product-cat-search-results" style="position:relative;z-index:1000;"></div>
                </div>
              `);
              $productsSection.find('.field-product-cat-search').after($catList);

              // ردیف سوم: تعداد و ترتیب نمایش
              $productsSection.append(`
                <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                  <div>
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M3 6h10M3 12h10M3 18h10" /><path stroke-linejoin="round" d="M18 15h1.5c.279 0 .418 0 .534.023a1.2 1.2 0 0 1 .943.943c.023.116.023.255.023.534s0 .418-.023.534a1.2 1.2 0 0 1-.943.943C19.918 18 19.78 18 19.5 18s-.418 0-.534.023a1.2 1.2 0 0 0-.943.943C18 19.082 18 19.22 18 19.5v.9c0 .283 0 .424.088.512s.23.088.512.088H21M18 3h1.2a.3.3 0 0 1 .3.3V9m0 0H18m1.5 0H21" /></g></svg></span>
                      تعداد محصول:
                    </label>
                    <input type="number" min="1" max="30" class="field-product-count" placeholder="تعداد" value="${item.product_count || 4}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div>
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="round" stroke-width="1.5" d="M3.5 9.5v9c0 .466 0 .699.076.883a1 1 0 0 0 .541.54C4.301 20 4.534 20 5 20s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-9c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C5.699 8 5.466 8 5 8s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7-4v13c0 .465 0 .698.076.882a1 1 0 0 0 .541.541c.184.077.417.077.883.077s.699 0 .883-.077a1 1 0 0 0 .54-.54c.077-.185.077-.418.077-.883v-13c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C12.699 4 12.466 4 12 4s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7 7v6c0 .466 0 .699.076.883a1 1 0 0 0 .541.54c.184.077.417.077.883.077s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-6c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C19.699 11 19.466 11 19 11s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Z" /></svg></span>
                      ترتیب نمایش:
                    </label>
                    <select class="field-product-sort" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;cursor:pointer;">
                      <option value="popularity"${item.product_sort === 'popularity' ? ' selected' : ''}>محبوب‌ترین</option>
                      <option value="sales"${item.product_sort === 'sales' ? ' selected' : ''}>پرفروش‌ترین</option>
                      <option value="latest"${item.product_sort === 'latest' ? ' selected' : ''}>جدیدترین</option>
                    </select>
                  </div>
                </div>
              `);

              // افزودن checkbox مخفی کردن محصولات ناموجود
              const hideOutOfStockChecked = item.hide_out_of_stock === 'yes' ? ' checked' : '';
              $productsSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;margin-top:12px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-hide-out-of-stock"${hideOutOfStockChecked} style="width:20px;height:20px;cursor:pointer;accent-color:#4CAF50;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        مخفی کردن محصولات ناموجود
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، فقط محصولات موجود نمایش داده می‌شوند</div>
                    </div>
                  </label>
                </div>
              `);

              $item.append($productsSection);
            } else if (item.type === 'special_products') {
              // ساختار بهبود یافته برای محصولات فروش ویژه
              const $specialSection = $('<div style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(255,193,7,0.2);"></div>');

              $specialSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m5.226 11.33l6.998-8.983c.547-.703 1.573-.266 1.573.67V9.97c0 .56.402 1.015.899 1.015H18.1c.773 0 1.185 1.03.674 1.686l-6.998 8.983c-.547.702-1.573.265-1.573-.671V14.03c0-.56-.403-1.015-.899-1.015H5.9c-.773 0-1.185-1.03-.674-1.686" /></svg></span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات محصولات فروش ویژه</h4>
              </div>`);

              // ردیف اول: آیکون، نام و تعداد
              $specialSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr 200px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5" d="M3 12c4.5 0 9-4.5 9-9c0 4.5 4.5 9 9 9c-4.5 0-9 4.5-9 9c0-4.5-4.5-9-9-9Zm-1 7.5c.833 0 2.5-1.667 2.5-2.5c0 .833 1.667 2.5 2.5 2.5c-.833 0-2.5 1.667-2.5 2.5c0-.833-1.667-2.5-2.5-2.5ZM16 5c1 0 3-2 3-3c0 1 2 3 3 3c-1 0-3 2-3 3c0-1-2-3-3-3Z" /></svg></span>
                      آیکون:
                    </label>
                    <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #e0fae2;border-radius:6px;font-size:12px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                  </div>
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M12 17c-1.674 0-3.13 1.265-3.882 3.131c-.36.892.156 1.869.84 1.869h6.083c.685 0 1.2-.977.841-1.869C15.13 18.265 13.674 17 12 17Z" /><path stroke-linejoin="round" d="M18.5 5h1.202c1.201 0 1.801 0 2.115.377c.313.378.183.944-.078 2.077l-.39 1.7C20.76 11.708 18.61 13.608 16 14M5.5 5H4.298c-1.201 0-1.802 0-2.115.377c-.313.378-.183.944.078 2.077l.39 1.7C3.24 11.708 5.39 13.608 8 14" /><path d="M12 17c3.02 0 5.565-4.662 6.33-11.01c.211-1.754.317-2.632-.243-3.311S16.622 2 14.813 2H9.187c-1.81 0-2.714 0-3.274.679S5.46 4.236 5.67 5.991C6.435 12.338 8.98 17 12 17Z" /></g></svg></span>
                      نام سکشن:
                    </label>
                    <input type="text" placeholder="مثال: پیشنهادهای شگفت‌انگیز" class="field-name" value="${item.name || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M3 6h10M3 12h10M3 18h10" /><path stroke-linejoin="round" d="M18 15h1.5c.279 0 .418 0 .534.023a1.2 1.2 0 0 1 .943.943c.023.116.023.255.023.534s0 .418-.023.534a1.2 1.2 0 0 1-.943.943C19.918 18 19.78 18 19.5 18s-.418 0-.534.023a1.2 1.2 0 0 0-.943.943C18 19.082 18 19.22 18 19.5v.9c0 .283 0 .424.088.512s.23.088.512.088H21M18 3h1.2a.3.3 0 0 1 .3.3V9m0 0H18m1.5 0H21" /></g></svg></span>
                      تعداد محصول:
                    </label>
                    <input type="number" min="1" max="30" class="field-product-count" placeholder="تعداد" value="${item.product_count || 4}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // راهنما
              $specialSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:10px 12px;border-radius:8px;display:flex;align-items:center;gap:8px;margin-bottom:12px;">
                  <span style="font-size:18px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M12 7a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Zm-3 6a3 3 0 1 0 6 0" /><path stroke-linecap="round" d="M5 13h14m-7-6V2m0 18v2m3-3l2 1.5M9 19l-2 1.5" /></g></svg></span>
                  <p style="margin:0;font-size:12px;color:#000000;opacity:0.9;">محصولاتی که تخفیف دارند نمایش داده می‌شوند</p>
                </div>
              `);

              // افزودن checkbox مخفی کردن محصولات ناموجود
              const hideOutOfStockCheckedSpecial = item.hide_out_of_stock === 'yes' ? ' checked' : '';
              $specialSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-hide-out-of-stock"${hideOutOfStockCheckedSpecial} style="width:20px;height:20px;cursor:pointer;accent-color:#4CAF50;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        مخفی کردن محصولات ناموجود
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، فقط محصولات موجود نمایش داده می‌شوند</div>
                    </div>
                  </label>
                </div>
              `);

              $item.append($specialSection);
            } else if (item.type === 'blog_posts') {
              // ساختار بهبود یافته برای پست‌های بلاگ
              const $blogSection = $('<div style="background:linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #81c784;box-shadow:0 2px 8px rgba(76,175,80,0.15);"></div>');

              $blogSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M2.5 12c0-4.478 0-6.718 1.391-8.109S7.521 2.5 12 2.5c4.478 0 6.718 0 8.109 1.391S21.5 7.521 21.5 12c0 4.478 0 6.718-1.391 8.109S16.479 21.5 12 21.5c-4.478 0-6.718 0-8.109-1.391S2.5 16.479 2.5 12Z" /><path stroke-linecap="round" d="M10 10h1m-1 5h4" /><path d="M14.958 11.462v-.953c0-1.873 0-2.81-.476-3.466c-.9-1.243-2.649-1.029-4.003-1.029S7.376 5.8 6.475 7.044C6 7.7 6 8.635 6 10.508v2.497c0 2.354 0 3.531.729 4.263S8.63 18 10.977 18h3.71c2.598 0 3.637-1.828 3.226-4.431c-.245-1.55-1.582-2.107-2.955-2.107Z" /></g></svg></span>
                <h4 style="margin:0;color:#2e7d32;font-size:15px;font-weight:600;">تنظیمات سکشن بلاگ</h4>
              </div>`);

              // جستجوی دسته‌بندی بلاگ
              const selectedBlogCats = item.blog_cats || [];
              const $blogCatList = $('<div class="field-blog-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              selectedBlogCats.forEach(cat => {
                $blogCatList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });

              $blogSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;position:relative;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#2e7d32;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                    دسته‌بندی بلاگ:
                  </label>
                  <input type="text" class="field-blog-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #81c784;border-radius:8px;font-size:13px;background:#fff;transition:all 0.3s;">
                  <div class="blog-cat-search-results" style="position:relative;z-index:1000;"></div>
                  <p style="margin:8px 0 0 0;font-size:12px;color:#2e7d32;opacity:0.8;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M12 7a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Zm-3 6a3 3 0 1 0 6 0" /><path stroke-linecap="round" d="M5 13h14m-7-6V2m0 18v2m3-3l2 1.5M9 19l-2 1.5" /></g></svg> می‌توانید چند دسته‌بندی انتخاب کنید</p>
                </div>
              `);
              $blogSection.find('.field-blog-cat-search').after($blogCatList);

              $item.append($blogSection);
            } else if (item.type === 'banners') {
              $item.append(`<input type="number" min="1" max="10" class="field-banner-count" placeholder="تعداد بنر" value="${item.banner_count || 1}" style="width:70px;">`);


              const currentStyle = item.banner_style || 'style1';
              $item.append(`
                <div style="margin:10px 0;">
                  <label style="display:inline-block;width:80px;font-size:12px;">استایل:</label>
                  <select class="field-banner-style" style="width:150px;">
                    <option value="style1"${currentStyle === 'style1' ? ' selected' : ''}>استایل 1</option>
                    <option value="style2"${currentStyle === 'style2' ? ' selected' : ''}>استایل 2</option>
                  </select>
                </div>
              `);


              let banners = item.banners || [];
              const bannerCount = parseInt(item.banner_count) || 1;


              while (banners.length < bannerCount) {
                banners.push({ desktop_image: '', mobile_image: '', link: '' });
              }
              while (banners.length > bannerCount) {
                banners.pop();
              }

              const $bannersContainer = $('<div class="banners-container" style="width:100%;"></div>');
              banners.forEach((banner, bannerIdx) => {
                const $bannerItem = $('<div class="banner-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e1e8ed;box-shadow:0 2px 8px rgba(0,0,0,0.08);transition:all 0.3s ease;"></div>');

                // Header بنر با آیکون
                $bannerItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.6);">
                  <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                  <h4 style="margin:0;color:#2c3e50;font-size:15px;font-weight:600;">بنر شماره ${bannerIdx + 1}</h4>
                </div>`);

                // بخش تصویر دسکتاپ
                const desktopPreview = banner.desktop_image
                  ? `<div style="margin-top:8px;"><img src="${banner.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                  : '';
                $bannerItem.append(`
                  <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                      تصویر دسکتاپ:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-banner-desktop-image" value="${banner.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-banner" data-type="desktop" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب تصویر
                      </button>
                    </div>
                    ${desktopPreview}
                  </div>
                `);

                // بخش تصویر موبایل
                const mobilePreview = banner.mobile_image
                  ? `<div style="margin-top:8px;"><img src="${banner.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                  : '';
                $bannerItem.append(`
                  <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                      تصویر موبایل:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر موبایل" class="field-banner-mobile-image" value="${banner.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-banner" data-type="mobile" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب تصویر
                      </button>
                    </div>
                    ${mobilePreview}
                  </div>
                `);

                // بخش لینک
                $bannerItem.append(`
                  <div style="background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک بنر:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-banner-link" value="${banner.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                $bannersContainer.append($bannerItem);
              });
              $item.append($bannersContainer);
            } else if (item.type === 'slider') {

              $item.append(`<label>استایل اسلایدر:</label>`);
              const styleOptions = [
                { value: 'style1', text: 'استایل یک' },
                { value: 'style2', text: 'استایل دو' },
                { value: 'style3', text: 'استایل سه' },
                { value: 'style4', text: 'استایل چهار' },
              ];
              const styleSelect = $('<select class="field-slider-style"></select>');
              styleOptions.forEach(opt => {
                styleSelect.append(`<option value="${opt.value}"${item.slider_style === opt.value ? ' selected' : ''}>${opt.text}</option>`);
              });
              $item.append(styleSelect);


              $item.append(`<input type="number" min="1" max="10" class="field-slider-count" placeholder="تعداد اسلاید" value="${item.slider_count || 1}" style="width:70px;">`);


              let slides = item.slides || [];
              const slideCount = parseInt(item.slider_count) || 1;
              const currentStyle = item.slider_style || 'style1';


              while (slides.length < slideCount) {
                if (currentStyle === 'style1') {
                  slides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
                } else if (currentStyle === 'style2') {
                  slides.push({ small_text: '', title: '', image: '', link: '' });
                } else if (currentStyle === 'style3') {
                  slides.push({ desktop_image: '', mobile_image: '', link: '' });
                } else if (currentStyle === 'style4') {
                  slides.push({ desktop_image: '', mobile_image: '', link: '' });
                }
              }
              while (slides.length > slideCount) {
                slides.pop();
              }

              const $slidesContainer = $('<div class="slides-container" style="width:100%;"></div>');
              slides.forEach((slide, slideIdx) => {
                const $slideItem = $('<div class="slide-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(0,188,212,0.15);transition:all 0.3s ease;"></div>');

                // Header اسلاید با آیکون
                $slideItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                  <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="m17.024 3.034l-.955-.255c-2.7-.72-4.05-1.079-5.113-.468c-1.064.61-1.426 1.953-2.15 4.637l-1.022 3.797c-.724 2.685-1.086 4.027-.471 5.085c.614 1.057 1.964 1.417 4.664 2.136l.954.255c2.7.72 4.05 1.079 5.114.468c1.063-.61 1.425-1.953 2.148-4.637l1.023-3.797c.724-2.685 1.085-4.027.471-5.085s-1.963-1.417-4.664-2.136Z" /><path d="M16.854 7.433c0 .814-.664 1.474-1.483 1.474c-.818 0-1.482-.66-1.482-1.474s.664-1.474 1.482-1.474c.82 0 1.483.66 1.483 1.474Z" /><path stroke-linecap="round" d="m12 20.946l-.952.26c-2.694.733-4.04 1.1-5.102.477c-1.06-.622-1.422-1.99-2.143-4.728l-1.021-3.872c-.722-2.737-1.083-4.106-.47-5.184C2.842 6.966 4 7 5.5 7" /></g></svg></span>
                  <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">اسلاید شماره ${slideIdx + 1}</h4>
                </div>`);

                if (currentStyle === 'style1') {
                  // استایل 1: فرم کامل با تخفیف و تایمر

                  const imagePreview = slide.image
                    ? `<div style="margin-top:8px;"><img src="${slide.image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                        عنوان تخفیف:
                      </label>
                      <input type="text" placeholder="مثال: تخفیف ویژه" class="field-slide-discount-title" value="${slide.discount_title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                    
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">⏰</span>
                        زمان شروع تخفیف:
                      </label>
                      <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="تاریخ (1403/04/18)" class="field-slide-date" value="${slide.date_fa || ''}" style="flex:1;min-width:150px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <input type="time" class="field-slide-time" value="${slide.time || ''}" style="width:120px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                      </div>
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                        عنوان اصلی:
                      </label>
                      <input type="text" placeholder="عنوان اسلاید" class="field-slide-title" value="${slide.title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                        تصویر اسلاید:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر" class="field-slide-image" value="${slide.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="image" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${imagePreview}
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">💬</span>
                        توضیح کوتاه:
                      </label>
                      <input type="text" placeholder="توضیحات کوتاه اسلاید" class="field-slide-small-text" value="${slide.small_text || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);

                } else if (currentStyle === 'style2') {
                  // استایل 2: فرم ساده

                  const imagePreview = slide.image
                    ? `<div style="margin-top:8px;"><img src="${slide.image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">💬</span>
                        توضیح کوتاه:
                      </label>
                      <input type="text" placeholder="توضیحات کوتاه" class="field-slide-small-text" value="${slide.small_text || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                        عنوان:
                      </label>
                      <input type="text" placeholder="عنوان اسلاید" class="field-slide-title" value="${slide.title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                        تصویر:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر" class="field-slide-image" value="${slide.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="image" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${imagePreview}
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);

                } else if (currentStyle === 'style3' || currentStyle === 'style4') {
                  // استایل 3 و 4: تصویر دسکتاپ و موبایل

                  const desktopPreview = slide.desktop_image
                    ? `<div style="margin-top:8px;"><img src="${slide.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';
                  const mobilePreview = slide.mobile_image
                    ? `<div style="margin-top:8px;"><img src="${slide.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                        تصویر دسکتاپ:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-slide-desktop-image" value="${slide.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="desktop" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${desktopPreview}
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                        تصویر موبایل:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر موبایل" class="field-slide-mobile-image" value="${slide.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="mobile" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${mobilePreview}
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);
                }

                $slidesContainer.append($slideItem);
              });
              $item.append($slidesContainer);
            } else if (item.type === 'logo_slider') {
              $item.append(`<input type="text" placeholder="عنوان سکشن" class="field-name" value="${item.name || ''}" style="width:200px;margin-bottom:10px;">`);
              $item.append(`<input type="number" min="1" max="20" class="field-logo-count" placeholder="تعداد لوگو" value="${item.logo_count || 1}" style="width:70px;margin-bottom:10px;">`);


              let logos = item.logos || [];
              const logoCount = parseInt(item.logo_count) || 1;


              while (logos.length < logoCount) {
                logos.push({ image: '', link: '', alt: '' });
              }
              while (logos.length > logoCount) {
                logos.pop();
              }

              const $logosContainer = $('<div class="logos-container" style="width:100%;"></div>');
              logos.forEach((logo, logoIdx) => {
                const $logoItem = $('<div class="logo-item" style="background:linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #ffcc80;box-shadow:0 2px 8px rgba(255,152,0,0.15);transition:all 0.3s ease;"></div>');

                // Header لوگو با آیکون
                $logoItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                  <span style="font-size:20px;margin-left:8px;">🏢</span>
                  <h4 style="margin:0;color:#e65100;font-size:15px;font-weight:600;">لوگو شماره ${logoIdx + 1}</h4>
                </div>`);

                // بخش تصویر لوگو
                const logoPreview = logo.image
                  ? `<div style="margin-top:8px;"><img src="${logo.image}" class="field-image-preview" style="max-width:100px;max-height:60px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);background:#fff;padding:4px;"></div>`
                  : '';
                $logoItem.append(`
                  <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                      تصویر لوگو:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر لوگو" class="field-logo-image" value="${logo.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-logo" data-logo="${logoIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب
                      </button>
                    </div>
                    ${logoPreview}
                  </div>
                `);

                // بخش لینک
                $logoItem.append(`
                  <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-logo-link" value="${logo.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                // بخش Alt Text
                $logoItem.append(`
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                      متن جایگزین (Alt):
                    </label>
                    <input type="text" placeholder="توضیح کوتاه درباره لوگو" class="field-logo-alt" value="${logo.alt || ''}" style="width:100%;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                $logosContainer.append($logoItem);
              });
              $item.append($logosContainer);
            }

            else if (item.type === 'spacer') {
              const $spacerSection = $('<div style="background:linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #ce93d8;box-shadow:0 2px 8px rgba(156,39,176,0.15);"></div>');

              $spacerSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 2v20M5 5l2 2m10-2l-2 2M5 19l2-2m10 2l-2-2"/></svg></span>
                <h4 style="margin:0;color:#7b1fa2;font-size:15px;font-weight:600;">تنظیمات فاصله</h4>
              </div>`);

              $spacerSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#7b1fa2;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12h18M12 3v18"/></svg></span>
                    ارتفاع فاصله (پیکسل):
                  </label>
                  <div style="display:flex;align-items:center;gap:10px;">
                    <input type="number" min="1" max="500" class="field-spacer-height" placeholder="مثال: 40" value="${item.height || 40}" style="width:120px;padding:8px 12px;border:1px solid #ce93d8;border-radius:6px;font-size:14px;background:#fff;">
                    <span style="font-size:13px;color:#7b1fa2;font-weight:500;">px</span>
                  </div>
                  <p style="margin:8px 0 0 0;font-size:12px;color:#7b1fa2;opacity:0.8;">مقدار فاصله خالی بین سکشن‌ها بر حسب پیکسل (۱ تا ۵۰۰)</p>
                </div>
              `);

              $item.append($spacerSection);
            }

            else if (item.type === 'custom_html') {
              $item.append(`<textarea class="field-html" placeholder="کد HTML">${item.html || ''}</textarea>`);
            }
          } else if (name === 'about_boxes') {
            $item.append(`<input type="text" placeholder="عنوان" class="field-title" value="${item.title || ''}">`);
            $item.append(`<input type="text" placeholder="توضیح کوتاه" class="field-small-text" value="${item.short_desc || ''}">`);
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
          } else if (name === 'stories_list') {
            // UI استوری‌ها
            const $storyCard = $('<div class="story-card" style="background:linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);padding:20px;border-radius:16px;border:2px solid #cbd5e0;box-shadow:0 4px 12px rgba(0,0,0,0.1);"></div>');

            // عنوان استوری
            $storyCard.append(`
              <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  عنوان استوری:
                </label>
                <input type="text" placeholder="مثال: محصولات جدید" class="field-story-title" value="${item.title || ''}" style="width:100%;padding:10px 12px;border:1px solid#cbd5e0;border-radius:8px;font-size:14px;background:#fff;">
              </div>
            `);

            // تصویر شاخص
            const thumbnailPreview = item.thumbnail
              ? `<div style="margin-top:10px;"><img src="${item.thumbnail}" class="field-image-preview" style="width:100px;height:100px;object-fit:cover;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.15);"></div>`
              : '';
            $storyCard.append(`
              <div style="margin-bottom:16px;background:rgba(255,255,255,0.7);padding:14px;border-radius:10px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  تصویر شاخص (Thumbnail):
                </label>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر شاخص" class="field-story-thumbnail" value="${item.thumbnail || ''}" style="flex:1;min-width:200px;padding:10px 12px;border:1px solid #cbd5e0;border-radius:8px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-story-thumbnail" style="padding:10px 18px;font-size:13px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.1);">
                    انتخاب تصویر
                  </button>
                </div>
                ${thumbnailPreview}
              </div>
            `);

            // تعداد محتوا
            $storyCard.append(`
              <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  تعداد محتوا (تصاویر/ویدیوها):
                </label>
                <input type="number" min="1" max="10" class="field-story-images-count" data-story-id="${item._uuid}" value="${(item.images && item.images.length) || 1}" style="width:100px;padding:10px 12px;border:1px solid #cbd5e0;border-radius:8px;font-size:14px;background:#fff;">
              </div>
            `);

            // لیست محتوا
            const $imagesContainer = $('<div class="story-images-container" style="margin-top:16px;"></div>');
            let images = item.images || [{ url: '', caption: '', type: 'image' }];

            images.forEach((img, imgIdx) => {
              const $imageItem = $('<div class="story-image-item" style="background:rgba(255,255,255,0.9);padding:16px;margin:12px 0;border-radius:12px;border:2px solid #e2e8f0;box-shadow:0 2px 6px rgba(0,0,0,0.08);"></div>');

              $imageItem.append(`
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:10px;border-bottom:2px solid #e2e8f0;">
                  <h4 style="margin:0;color:#4a5568;font-size:14px;font-weight:600;">محتوا ${imgIdx + 1}</h4>
                  <button type="button" class="button button-small remove-story-image-btn" data-img-idx="${imgIdx}" style="background:#e53935;color:#fff;padding:4px 12px;border-radius:6px;font-size:12px;">حذف</button>
                </div>
              `);

              // نوع محتوا
              $imageItem.append(`
                <div style="margin-bottom:12px;">
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    نوع محتوا:
                  </label>
                  <select class="field-story-image-type" data-img-idx="${imgIdx}" style="width:100%;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                    <option value="image" ${img.type === 'image' ? 'selected' : ''}>تصویر</option>
                    <option value="video" ${img.type === 'video' ? 'selected' : ''}>ویدیو</option>
                  </select>
                </div>
              `);

              // URL محتوا
              const mediaPreview = img.url
                ? (img.type === 'video'
                  ? `<div style="margin-top:10px;"><video src="${img.url}" controls style="max-width:200px;max-height:150px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></video></div>`
                  : `<div style="margin-top:10px;"><img src="${img.url}" class="field-image-preview" style="max-width:200px;max-height:150px;object-fit:cover;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`)
                : '';

              $imageItem.append(`
                <div style="margin-bottom:12px;">
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    آدرس ${img.type === 'video' ? 'ویدیو' : 'تصویر'}:
                  </label>
                  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <input type="text" placeholder="آدرس محتوا" class="field-story-image-url" data-img-idx="${imgIdx}" value="${img.url || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                    <button type="button" class="button button-primary button-upload-story-image" data-img-idx="${imgIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                      انتخاب
                    </button>
                  </div>
                  ${mediaPreview}
                </div>
              `);

              // کپشن
              $imageItem.append(`
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    توضیحات (Caption):
                  </label>
                  <input type="text" placeholder="توضیح کوتاه برای این محتوا" class="field-story-image-caption" data-img-idx="${imgIdx}" value="${img.caption || ''}" style="width:100%;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                </div>
              `);

              $imagesContainer.append($imageItem);
            });

            // دکمه افزودن محتوا
            if (images.length < 10) {
              $imagesContainer.append(`
                <button type="button" class="button button-secondary add-story-image-btn" style="margin-top:10px;width:100%;padding:10px;border-radius:8px;background:#48bb78;color:#fff;font-size:14px;font-weight:600;">
                  + افزودن محتوا
                </button>
              `);
            }

            $storyCard.append($imagesContainer);
            $item.append($storyCard);
          }

          const $removeBtn = $('<button type="button" class="button">حذف</button>');
          $removeBtn.on('click', function () {
            const id = $(this).closest('.custom-list-item').data('id');
            items = items.filter(i => i._uuid !== id);
            save();
            render();
          });

          $item.append($removeBtn);
          $list.append($item);
        });


        let canAdd = true;
        if (isAboutBoxes && items.length >= 4) canAdd = false;
        if (canAdd) {
          const $addBtn = $('<button type="button" class="button button-primary" style="margin-top:5px;">افزودن آیتم جدید</button>');
          $addBtn.on('click', function () {
            let newItem;
            if (name === 'about_boxes') {
              newItem = { title: '', short_desc: '', image: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'slider') {
              newItem = { discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'user_panel_slider') {
              newItem = { image: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'product_categories') {
              newItem = { icon: '', name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'socials') {
              newItem = { icon: '', name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'site_menu') {
              newItem = { name: '', link: '', icon: '', children: [], _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'navbar_menu') {
              newItem = { name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'job_positions_list') {
              newItem = { title: '', description: '', job_type: 'تمام وقت', skills: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'faq_list') {
              newItem = { question: '', answer: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'stories_list') {
              newItem = {
                title: '',
                thumbnail: '',
                images: [{ url: '', caption: '', type: 'image' }],
                _uuid: Math.random().toString(36).substring(2, 10)
              };
            } else if (name === 'site_badges') {
              newItem = { html: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'footer_menu_1' || name === 'footer_menu_2') {
              newItem = { name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'home_sections') {
              let defaultType = 'products';

              newItem = {
                type: defaultType,
                icon: '',
                name: '',
                link: '',
                product_cats: [],
                product_count: 4,
                product_sort: 'popularity',
                hide_out_of_stock: 'no',
                blog_cats: [],
                html: '',
                banner_count: 1,
                banner_style: 'style1',
                banners: [{ desktop_image: '', mobile_image: '', link: '' }],
                slider_style: 'style1',
                slider_count: 1,
                slides: [{ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' }],
                logo_count: 1,
                logos: [{ image: '', link: '', alt: '' }],
                _uuid: Math.random().toString(36).substring(2, 10)
              };
            }
            items.push(newItem);
            save();
            render();
          });
          $wrapper.append($list).append($addBtn);
        } else {
          $wrapper.append($list);
        }
      }

      function save() {
        $wrapper.find('.custom-list-item').each(function () {
          const $item = $(this);
          const id = $item.data('id');
          const index = items.findIndex(i => i._uuid === id);
          if (index !== -1) {
            if (name === 'about_boxes') {
              items[index].title = $item.find('.field-title').val();
              items[index].short_desc = $item.find('.field-small-text').val();
              items[index].image = $item.find('.field-image').val();
            } else if (name === 'slider') {
              items[index].discount_title = $item.find('.field-discount-title').val();
              items[index].date_fa = $item.find('.field-date').val();
              items[index].time = $item.find('.field-time').val();
              items[index].title = $item.find('.field-title').val();
              items[index].image = $item.find('.field-image').val();
              items[index].small_text = $item.find('.field-small-text').val();
              items[index].link = $item.find('.field-link').val();

              var dateFa = items[index].date_fa;
              var time = items[index].time;
              if (dateFa && time && window.persianDate) {
                try {
                  var pd = new persianDate().parse(dateFa + ' ' + time);
                  var g = pd.toGregorian();
                  var gDate = new Date(g.year, g.month - 1, g.day, ...time.split(':'));
                  items[index].date_gregorian = gDate.toISOString();
                } catch (e) {
                  items[index].date_gregorian = '';
                }
              } else {
                items[index].date_gregorian = '';
              }
            } else if (items[index].type === 'logo_slider') {
              items[index].name = $item.find('.field-name').val();
              items[index].logo_count = $item.find('.field-logo-count').val();
              items[index].logos = [];
              $item.find('.logo-item').each(function () {
                const $logoItem = $(this);
                items[index].logos.push({
                  image: $logoItem.find('.field-logo-image').val(),
                  link: $logoItem.find('.field-logo-link').val(),
                  alt: $logoItem.find('.field-logo-alt').val()
                });
              });
            }

            else if (name === 'user_panel_slider') {
              items[index].image = $item.find('.field-image').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'product_categories') {
              items[index].icon = $item.find('.field-icon').val();
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'socials') {
              items[index].icon = $item.find('.field-icon').val();
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'site_menu') {
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
              items[index].icon = $item.find('.field-icon').val();

              // ذخیره زیرمنوها
              items[index].children = [];
              $item.find('.submenu-item').each(function () {
                const $subItem = $(this);
                const childName = $subItem.find('.field-child-name').val();
                const childLink = $subItem.find('.field-child-link').val();
                const childId = $subItem.data('child-id');

                if (childName || childLink) {
                  items[index].children.push({
                    _uuid: childId,
                    name: childName,
                    link: childLink
                  });
                }
              });
            } else if (name === 'navbar_menu') {
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'job_positions_list') {
              items[index].title = $item.find('.field-title').val();
              items[index].description = $item.find('.field-description').val();
              items[index].job_type = $item.find('.field-job-type').val();
              items[index].skills = $item.find('.field-skills').val();
            } else if (name === 'faq_list') {
              items[index].question = $item.find('.field-question').val();
              items[index].answer = $item.find('.field-answer').val();
            } else if (name === 'stories_list') {
              items[index].title = $item.find('.field-story-title').val();
              items[index].thumbnail = $item.find('.field-story-thumbnail').val();
              items[index].images = [];
              $item.find('.story-image-item').each(function () {
                const $imgItem = $(this);
                const imgIdx = $imgItem.find('.field-story-image-type').data('img-idx');
                items[index].images.push({
                  url: $imgItem.find('.field-story-image-url').val(),
                  caption: $imgItem.find('.field-story-image-caption').val(),
                  type: $imgItem.find('.field-story-image-type').val()
                });
              });
            } else if (name === 'site_badges') {
              items[index].html = $item.find('.field-html').val();
            } else if (name === 'footer_menu_1' || name === 'footer_menu_2') {
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'home_sections') {
              items[index].type = $item.find('.field-section-type').val();
              if (items[index].type === 'products') {
                items[index].icon = $item.find('.field-icon').val();
                items[index].name = $item.find('.field-name').val();
                items[index].link = $item.find('.field-link').val();

                items[index].product_cats = [];
                $item.find('.field-product-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].product_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].product_sort = $item.find('.field-product-sort').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
              } else if (items[index].type === 'special_products') {
                items[index].icon = $item.find('.field-icon').val();
                items[index].name = $item.find('.field-name').val();
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
              } else if (items[index].type === 'blog_posts') {
                items[index].blog_cats = [];
                $item.find('.field-blog-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].blog_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
              } else if (items[index].type === 'custom_html') {
                items[index].html = $item.find('.field-html').val();
              } else if (items[index].type === 'banners') {
                items[index].banner_count = $item.find('.field-banner-count').val();
                items[index].banner_style = $item.find('.field-banner-style').val();
                items[index].banners = [];
                $item.find('.banner-item').each(function () {
                  const $bannerItem = $(this);
                  items[index].banners.push({
                    desktop_image: $bannerItem.find('.field-banner-desktop-image').val(),
                    mobile_image: $bannerItem.find('.field-banner-mobile-image').val(),
                    link: $bannerItem.find('.field-banner-link').val()
                  });
                });
              } else if (items[index].type === 'slider') {
                items[index].slider_style = $item.find('.field-slider-style').val();
                items[index].slider_count = $item.find('.field-slider-count').val();
                items[index].slides = [];
                $item.find('.slide-item').each(function () {
                  const $slideItem = $(this);
                  const style = items[index].slider_style;

                  if (style === 'style1') {
                    items[index].slides.push({
                      discount_title: $slideItem.find('.field-slide-discount-title').val(),
                      date_fa: $slideItem.find('.field-slide-date').val(),
                      time: $slideItem.find('.field-slide-time').val(),
                      title: $slideItem.find('.field-slide-title').val(),
                      image: $slideItem.find('.field-slide-image').val(),
                      small_text: $slideItem.find('.field-slide-small-text').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style2') {
                    items[index].slides.push({
                      small_text: $slideItem.find('.field-slide-small-text').val(),
                      title: $slideItem.find('.field-slide-title').val(),
                      image: $slideItem.find('.field-slide-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style3') {
                    items[index].slides.push({
                      desktop_image: $slideItem.find('.field-slide-desktop-image').val(),
                      mobile_image: $slideItem.find('.field-slide-mobile-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style4') {
                    items[index].slides.push({
                      desktop_image: $slideItem.find('.field-slide-desktop-image').val(),
                      mobile_image: $slideItem.find('.field-slide-mobile-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  }
                });
              } else if (items[index].type === 'spacer') {
                items[index].height = $item.find('.field-spacer-height').val();
              } else if (items[index].type === 'site_description_box') {

                items[index] = { type: 'site_description_box', _uuid: items[index]._uuid };
              }
            }
          }
        });
        $textarea.val(JSON.stringify(items));
      }


      $wrapper.on('click', '.button-upload', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        let $input;
        if (name === 'product_categories') {
          $input = $item.find('.field-icon');
        } else {
          $input = $item.find('.field-image');
        }
        let frame = wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $item.find('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-slide', function (e) {
        e.preventDefault();
        const $button = $(this);
        const type = $button.data('type');
        const slideIdx = $button.data('slide');
        const $slideItem = $button.closest('.slide-item');
        let $input;

        if (type === 'image') {
          $input = $slideItem.find('.field-slide-image');
        } else if (type === 'desktop') {
          $input = $slideItem.find('.field-slide-desktop-image');
        } else if (type === 'mobile') {
          $input = $slideItem.find('.field-slide-mobile-image');
        }

        let title = 'انتخاب تصویر';
        if (type === 'desktop') title = 'انتخاب تصویر دسکتاپ';
        else if (type === 'mobile') title = 'انتخاب تصویر موبایل';

        let frame = wp.media({ title: title, multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:40px;max-height:40px;margin-left:5px;vertical-align:middle;">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-banner', function (e) {
        e.preventDefault();
        const $button = $(this);
        const type = $button.data('type');
        const bannerIdx = $button.data('banner');
        const $bannerItem = $button.closest('.banner-item');
        let $input = $bannerItem.find(`.field-banner-${type}-image`);

        let frame = wp.media({ title: `انتخاب تصویر ${type === 'desktop' ? 'دسکتاپ' : 'موبایل'}`, multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:50px;max-height:50px;margin:2px;">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-logo', function (e) {
        e.preventDefault();
        const $button = $(this);
        const logoIdx = $button.data('logo');
        const $logoItem = $button.closest('.logo-item');
        let $input = $logoItem.find('.field-logo-image');

        let frame = wp.media({ title: 'انتخاب لوگو', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:40px;max-height:40px;margin-left:5px;vertical-align:middle;">`);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود تصویر شاخص استوری
      $wrapper.on('click', '.button-upload-story-thumbnail', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const $input = $item.find('.field-story-thumbnail');
        let frame = wp.media({ title: 'انتخاب تصویر شاخص استوری', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $item.find('.field-image-preview').remove();
          $input.closest('div').find('.field-image-preview').remove();
          $input.closest('div').append(`<div style="margin-top:10px;"><img src="${attachment.url}" class="field-image-preview" style="width:100px;height:100px;object-fit:cover;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.15);"></div>`);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود محتوای استوری (تصویر/ویدیو)
      $wrapper.on('click', '.button-upload-story-image', function (e) {
        e.preventDefault();
        const $button = $(this);
        const imgIdx = $button.data('img-idx');
        const $imageItem = $button.closest('.story-image-item');
        const $input = $imageItem.find('.field-story-image-url');
        const $typeSelect = $imageItem.find('.field-story-image-type');
        const mediaType = $typeSelect.val();

        let frameOptions = {
          title: mediaType === 'video' ? 'انتخاب ویدیو' : 'انتخاب تصویر',
          multiple: false
        };

        if (mediaType === 'video') {
          frameOptions.library = { type: 'video' };
        } else {
          frameOptions.library = { type: 'image' };
        }

        let frame = wp.media(frameOptions);
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.nextAll('.field-image-preview').remove();
          $input.parent().find('.field-image-preview').remove();

          if (mediaType === 'video') {
            $input.parent().append(`<div style="margin-top:10px;"><video src="${attachment.url}" controls style="max-width:200px;max-height:150px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></video></div>`);
          } else {
            $input.parent().append(`<div style="margin-top:10px;"><img src="${attachment.url}" class="field-image-preview" style="max-width:200px;max-height:150px;object-fit:cover;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`);
          }
          $input.trigger('input');
        });
        frame.open();
      });

      // تغییر نوع محتوای استوری
      $wrapper.on('change', '.field-story-image-type', function () {
        save();
        render();
      });

      // افزودن محتوای جدید به استوری
      $wrapper.on('click', '.add-story-image-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          if (!items[index].images) items[index].images = [];
          if (items[index].images.length < 10) {
            items[index].images.push({ url: '', caption: '', type: 'image' });
            $textarea.val(JSON.stringify(items));
            render();
          }
        }
      });

      // حذف محتوای استوری
      $wrapper.on('click', '.remove-story-image-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $item = $(this).closest('.custom-list-item');
        const imgIdx = $(this).data('img-idx');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1 && items[index].images) {
          items[index].images.splice(imgIdx, 1);
          if (items[index].images.length === 0) {
            items[index].images = [{ url: '', caption: '', type: 'image' }];
          }
          $textarea.val(JSON.stringify(items));
          render();
        }
      });

      // تغییر تعداد محتوا در استوری
      $wrapper.on('input change keyup', '.field-story-images-count', function (e) {
        e.stopPropagation(); // جلوگیری از trigger شدن event های دیگر

        const $input = $(this);
        const $item = $input.closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);

        if (index !== -1) {
          const newCount = parseInt($input.val()) || 1;
          const validCount = Math.min(Math.max(newCount, 1), 10); // محدود کردن بین 1 تا 10

          if (newCount !== validCount) {
            $input.val(validCount);
          }

          if (!items[index].images) {
            items[index].images = [];
          }

          let currentImages = items[index].images;

          if (validCount > currentImages.length) {
            // اضافه کردن محتوای جدید
            for (let i = currentImages.length; i < validCount; i++) {
              currentImages.push({ url: '', caption: '', type: 'image' });
            }
            items[index].images = currentImages;
            $textarea.val(JSON.stringify(items));
            render();
          } else if (validCount < currentImages.length) {
            // کم کردن محتوا
            items[index].images = currentImages.slice(0, validCount);
            $textarea.val(JSON.stringify(items));
            render();
          }
        }
      });


      $wrapper.on('input change', 'input:not(.field-story-images-count), textarea, select', function () {
        save();
      });


      $wrapper.on('change', '.field-section-type', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newType = $(this).val();
          items[index].type = newType;


          if (newType === 'banners') {
            items[index].banner_count = 1;
            items[index].banners = [{ desktop_image: '', mobile_image: '', link: '' }];
          } else if (newType === 'slider') {
            items[index].slider_style = 'style1';
            items[index].slider_count = 1;
            items[index].slides = [{ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' }];
          }

          save();
          render();
        }
      });


      $wrapper.on('input change', '.field-banner-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          let currentBanners = items[index].banners || [];


          if (newCount > currentBanners.length) {

            for (let i = currentBanners.length; i < newCount; i++) {
              currentBanners.push({ desktop_image: '', mobile_image: '', link: '' });
            }
          } else if (newCount < currentBanners.length) {

            currentBanners = currentBanners.slice(0, newCount);
          }

          items[index].banner_count = newCount;
          items[index].banners = currentBanners;
          save();


          const $bannersContainer = $item.find('.banners-container');
          $bannersContainer.empty();

          currentBanners.forEach((banner, bannerIdx) => {
            const $bannerItem = $('<div class="banner-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e1e8ed;box-shadow:0 2px 8px rgba(0,0,0,0.08);transition:all 0.3s ease;"></div>');

            // Header بنر با آیکون
            $bannerItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.6);">
              <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
              <h4 style="margin:0;color:#2c3e50;font-size:15px;font-weight:600;">بنر شماره ${bannerIdx + 1}</h4>
            </div>`);

            // بخش تصویر دسکتاپ
            const desktopPreview = banner.desktop_image
              ? `<div style="margin-top:8px;"><img src="${banner.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
              : '';
            $bannerItem.append(`
              <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                  تصویر دسکتاپ:
                </label>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-banner-desktop-image" value="${banner.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-banner" data-type="desktop" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                    <span style="margin-left:4px;">📁</span> انتخاب تصویر
                  </button>
                </div>
                ${desktopPreview}
              </div>
            `);

            // بخش تصویر موبایل
            const mobilePreview = banner.mobile_image
              ? `<div style="margin-top:8px;"><img src="${banner.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
              : '';
            $bannerItem.append(`
              <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                  تصویر موبایل:
                </label>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر موبایل" class="field-banner-mobile-image" value="${banner.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-banner" data-type="mobile" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                    <span style="margin-left:4px;">📁</span> انتخاب تصویر
                  </button>
                </div>
                ${mobilePreview}
              </div>
            `);

            // بخش لینک
            $bannerItem.append(`
              <div style="background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                  لینک بنر:
                </label>
                <input type="text" placeholder="https://example.com" class="field-banner-link" value="${banner.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
              </div>
            `);

            $bannersContainer.append($bannerItem);
          });
        }
      });


      $wrapper.on('change', '.field-slider-style', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newStyle = $(this).val();
          const slideCount = parseInt(items[index].slider_count) || 1;
          items[index].slider_style = newStyle;


          items[index].slides = [];
          for (let i = 0; i < slideCount; i++) {
            if (newStyle === 'style1') {
              items[index].slides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
            } else if (newStyle === 'style2') {
              items[index].slides.push({ small_text: '', title: '', image: '', link: '' });
            } else if (newStyle === 'style3') {
              items[index].slides.push({ desktop_image: '', mobile_image: '', link: '' });
            } else if (newStyle === 'style4') {
              items[index].slides.push({ desktop_image: '', mobile_image: '', link: '' });
            }
          }

          save();
          render();
        }
      });


      $wrapper.on('input change', '.field-slider-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          const currentStyle = items[index].slider_style || 'style1';
          let currentSlides = items[index].slides || [];


          if (newCount > currentSlides.length) {

            for (let i = currentSlides.length; i < newCount; i++) {
              if (currentStyle === 'style1') {
                currentSlides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
              } else if (currentStyle === 'style2') {
                currentSlides.push({ small_text: '', title: '', image: '', link: '' });
              } else if (currentStyle === 'style3') {
                currentSlides.push({ desktop_image: '', mobile_image: '', link: '' });
              }
            }
          } else if (newCount < currentSlides.length) {

            currentSlides = currentSlides.slice(0, newCount);
          }

          items[index].slider_count = newCount;
          items[index].slides = currentSlides;
          save();
          render();
        }
      });

      $wrapper.on('input change', '.field-logo-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          let currentLogos = items[index].logos || [];


          if (newCount > currentLogos.length) {

            for (let i = currentLogos.length; i < newCount; i++) {
              currentLogos.push({ image: '', link: '', alt: '' });
            }
          } else if (newCount < currentLogos.length) {

            currentLogos = currentLogos.slice(0, newCount);
          }

          items[index].logo_count = newCount;
          items[index].logos = currentLogos;
          save();
          render();
        }
      });


      setTimeout(function () {
        $('.custom-list-wrap[data-name="slider"] .field-date').persianDatepicker({
          format: 'YYYY/MM/DD',
          autoClose: true,
          initialValue: false,
          calendar: { persian: { locale: 'fa' } }
        });

        $('.slide-item .field-slide-date').persianDatepicker({
          format: 'YYYY/MM/DD',
          autoClose: true,
          initialValue: false,
          calendar: { persian: { locale: 'fa' } }
        });
      }, 500);

      render();


      $wrapper.on('input', '.field-product-cat-search', function () {
        const $item = $(this).closest('.custom-list-item');
        const q = $(this).val();
        const $results = $item.find('.product-cat-search-results');
        $results.empty();
        if (q.length < 2) return;
        let siteUrl = window.location.origin;

        $results.html('<div class="cat-loading">در حال جستجو...</div>');
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $.get(siteUrl + '/wp-json/theme-settings/v1/product-categories', { search: q }, function (data) {
          $results.empty();
          if (Array.isArray(data)) {

            let selected = [];
            $item.find('.field-product-cats-list .cat-chip').each(function () {
              selected.push($(this).data('id'));
            });
            let hasResult = false;
            data.forEach(cat => {
              if (!selected.includes(cat.id)) {
                $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${cat.name}">${cat.name}</div>`);
                hasResult = true;
              }
            });
            if (!hasResult) $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
        $results.addClass('cat-dropdown');
      });
      $wrapper.on('click', '.product-cat-search-results .cat-result', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $(this).data('id');
        const name = $(this).data('name');

        const $catList = $item.find('.field-product-cats-list');
        if ($catList.find(`[data-id='${id}']`).length) return;
        $catList.append(`<span class="cat-chip" data-id="${id}">${name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
        $item.find('.product-cat-search-results').empty();
        save();
      });
      $wrapper.on('click', '.field-product-cats-list .remove-cat', function () {
        const $chip = $(this).closest('.cat-chip');
        $chip.remove();
        save();
      });

      $wrapper.on('input', '.field-blog-cat-search', function () {
        const $item = $(this).closest('.custom-list-item');
        const q = $(this).val();
        const $results = $item.find('.blog-cat-search-results');
        $results.empty();
        if (q.length < 2) return;
        $results.html('<div class="cat-loading">در حال جستجو...</div>');
        let siteUrl = window.location.origin;
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $.get(siteUrl + '/wp-json/wp/v2/categories', { search: q, per_page: 10 }, function (data) {
          $results.empty();
          if (Array.isArray(data)) {

            let selected = [];
            $item.find('.field-blog-cats-list .cat-chip').each(function () {
              selected.push($(this).data('id'));
            });
            let hasResult = false;
            data.forEach(cat => {
              if (!selected.includes(cat.id)) {
                $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${cat.name}">${cat.name}</div>`);
                hasResult = true;
              }
            });
            if (!hasResult) $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
        $results.addClass('cat-dropdown');
      });
      $wrapper.on('click', '.blog-cat-search-results .cat-result', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $(this).data('id');
        const name = $(this).data('name');
        const $catList = $item.find('.field-blog-cats-list');
        if ($catList.find(`[data-id='${id}']`).length) return;
        $catList.append(`<span class="cat-chip" data-id="${id}">${name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
        $item.find('.blog-cat-search-results').empty();
        save();
      });
      $wrapper.on('click', '.field-blog-cats-list .remove-cat', function () {
        const $chip = $(this).closest('.cat-chip');
        $chip.remove();
        save();
      });

      if (!document.getElementById('cat-chip-style')) {
        const chipCss = `
        .cat-chip { display:inline-flex;align-items:center;background:var(--brand-bg);color:var(--brand);border-radius:20px;padding:3px 10px 3px 6px;margin:2px 4px 2px 0;font-size:12.5px;font-weight:500;transition:all .2s; border:1px solid rgba(9,143,129,0.15); }
        .cat-chip b.remove-cat {margin-right:4px;font-size:15px;line-height:1;color:var(--brand);opacity:0.6;transition:opacity .2s;}
        .cat-chip b.remove-cat:hover {opacity:1;}
        .cat-chip:hover {background:rgba(9,143,129,0.12);border-color:rgba(9,143,129,0.25);}
        .cat-dropdown {position:absolute;right:0;left:0;top:100%;background:#fff;border:1.5px solid var(--border);border-radius:0 0 var(--radius-md) var(--radius-md);box-shadow:var(--shadow-lg);z-index:1001;max-height:220px;overflow:auto;margin-top:2px;}
        .cat-result {padding:9px 14px;cursor:pointer;transition:background .15s;font-size:13px;color:var(--text-primary);}
        .cat-result:hover {background:var(--brand-bg);color:var(--brand);}
        .cat-loading {padding:9px 14px;color:var(--brand);font-size:13px;}
        .cat-no-result {padding:9px 14px;color:var(--text-muted);font-size:13px;}
        .banners-container {width:100%;margin-top:10px;}
        .banner-item {transition:all 0.25s ease!important;}
        .banner-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .banner-item input[type="text"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .banner-item .button-upload-banner:hover {background:var(--brand-dark)!important;}
        .banner-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .banner-item .field-image-preview:hover {transform:scale(1.4)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .slides-container {width:100%;margin-top:10px;}
        .slide-item {transition:all 0.25s ease!important;}
        .slide-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .slide-item input[type="text"]:focus, .slide-item input[type="time"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .slide-item .button-upload-slide:hover {background:var(--brand-dark)!important;}
        .slide-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .slide-item .field-image-preview:hover {transform:scale(1.4)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .logos-container {width:100%;margin-top:10px;}
        .logo-item {transition:all 0.25s ease!important;}
        .logo-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .logo-item input[type="text"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .logo-item .button-upload-logo:hover {background:var(--brand-dark)!important;}
        .logo-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .logo-item .field-image-preview:hover {transform:scale(1.3)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .field-product-cat-search:focus, .field-blog-cat-search:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        select.field-product-sort:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        `;
        $('<style id="cat-chip-style">' + chipCss + '</style>').appendTo('head');
      }
    });


    const $mainTab = $('#tab-content-main');
    const $homeSectionsWrap = $('.custom-list-wrap[data-name="home_sections"]').parent();
    const $homeSectionsCount = $("input[name='custom_theme_options[home_sections_count]']").closest('tr, p, div');
    if ($mainTab.length) {

      $mainTab.append($homeSectionsCount);
      $mainTab.append($homeSectionsWrap);
    }

    $homeSectionsWrap.hide();
    $homeSectionsCount.hide();


    const $styleTab = $('#tab-content-style');
    const styleFields = [
      'product_carousel_style',
      'header_style',
      'footer_style',
      'category_card_style',
      'product_page_style',
      'container_style',
      'category_page_style',
      'category_page_style_mobile',
    ];

    const $styleFieldElements = [];
    styleFields.forEach(function (fieldName) {
      const $field = $("select[name='custom_theme_options[" + fieldName + "]']").closest('tr');
      if ($field.length) {
        $styleFieldElements.push($field);
      }
    });

    if ($styleTab.length && $styleFieldElements.length) {

      $styleFieldElements.forEach(function ($field) {
        $styleTab.append($field);
        $field.hide();
      });
    }


    $(document).on('click', '.custom-tab-btn', function () {
      const tabName = $(this).data('tab');


      if (tabName === 'main') {
        $homeSectionsWrap.show();
        $homeSectionsCount.show();
      } else {
        $homeSectionsWrap.hide();
        $homeSectionsCount.hide();
      }


      if (tabName === 'style') {
        $styleFieldElements.forEach(function ($field) {
          $field.show();
        });
      } else {
        $styleFieldElements.forEach(function ($field) {
          $field.hide();
        });
      }
    });

    // اضافه کردن دکمه‌های ذخیره به همه تب‌ها (به جز تب عمومی)
    setTimeout(function () {
      const tabIds = ['main', 'style', 'jobs', 'about', 'contact', 'faq', 'stories', 'notification', 'security', 'font', 'customization', 'translations'];
      const submitButtonHtml = '<p class="submit"><input type="submit" name="submit" class="button button-primary" value="ذخیرهٔ تغییرات"></p>';

      tabIds.forEach(function (tabId) {
        const $tab = $('#tab-content-' + tabId);
        if ($tab.length && !$tab.find('.submit').length) {
          $tab.append(submitButtonHtml);
        }
      });
    }, 200);

  });
})(jQuery);
