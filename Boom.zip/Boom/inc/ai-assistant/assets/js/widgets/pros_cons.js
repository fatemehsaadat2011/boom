/**
 * ویجت مزایا و معایب (pros_cons).
 * payload: { product_name, pros:[], cons:[], good_for, bad_for }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	function list( el, cls, sign, items ) {
		var ul = el( 'ul', 'aia-pc-list ' + cls );
		( items || [] ).forEach( function ( t ) {
			var li = el( 'li' );
			li.appendChild( el( 'span', 'aia-pc-sign', sign ) );
			li.appendChild( document.createTextNode( t ) );
			ul.appendChild( li );
		} );
		return ul;
	}

	window.BoomAIAWidgets.pros_cons = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '✅' ) );
		title.appendChild( el( 'span', null, p.product_name || 'بررسی محصول' ) );
		card.appendChild( title );

		var cols = el( 'div', 'aia-pc-cols' );
		var pros = el( 'div', 'aia-pc-col' );
		pros.appendChild( el( 'div', 'aia-pc-head pos', 'نقاط قوت' ) );
		pros.appendChild( list( el, 'pos', '✓', p.pros ) );
		var cons = el( 'div', 'aia-pc-col' );
		cons.appendChild( el( 'div', 'aia-pc-head neg', 'نقاط ضعف' ) );
		cons.appendChild( list( el, 'neg', '✗', p.cons ) );
		cols.appendChild( pros );
		cols.appendChild( cons );
		card.appendChild( cols );

		if ( p.good_for ) {
			var g = el( 'div', 'aia-pc-fit' );
			g.appendChild( el( 'b', null, 'مناسب برای: ' ) );
			g.appendChild( document.createTextNode( p.good_for ) );
			card.appendChild( g );
		}
		if ( p.bad_for ) {
			var bd = el( 'div', 'aia-pc-fit' );
			bd.appendChild( el( 'b', null, 'نامناسب برای: ' ) );
			bd.appendChild( document.createTextNode( p.bad_for ) );
			card.appendChild( bd );
		}

		return card;
	};
} )();
