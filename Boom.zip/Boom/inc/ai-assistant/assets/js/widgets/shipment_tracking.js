/**
 * ویجت رهگیری هوشمند (shipment_tracking).
 * payload: { order_number, carrier, tracking_code, last_status, eta }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	function row( el, label, value, mono ) {
		var r = el( 'div', 'aia-st-row' );
		r.appendChild( el( 'span', 'aia-st-label', label ) );
		r.appendChild( el( mono ? 'code' : 'span', mono ? 'aia-st-code' : 'aia-st-value', value ) );
		return r;
	}

	window.BoomAIAWidgets.shipment_tracking = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget aia-st' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '🚚' ) );
		title.appendChild( el( 'span', null, 'رهگیری سفارش #' + ( p.order_number || '' ) ) );
		card.appendChild( title );

		if ( p.carrier ) { card.appendChild( row( el, 'شرکت حمل', p.carrier ) ); }
		if ( p.tracking_code ) { card.appendChild( row( el, 'کد رهگیری', p.tracking_code, true ) ); }
		if ( p.last_status ) { card.appendChild( row( el, 'آخرین وضعیت', p.last_status ) ); }
		if ( p.eta ) { card.appendChild( row( el, 'زمان تقریبی تحویل', p.eta ) ); }

		return card;
	};
} )();
