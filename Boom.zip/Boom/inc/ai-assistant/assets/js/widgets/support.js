/**
 * ویجت پشتیبانی و ارتباط با اپراتور (support).
 * payload: { message, sentiment:'neutral'|'negative', handoff:{whatsapp,telegram,form} }
 * لینک‌های handoff از سمت سرور (تنظیمات) تزریق می‌شوند، نه از مدل.
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.support = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var negative = 'negative' === p.sentiment;
		var card = el( 'div', 'aia-widget aia-support' + ( negative ? ' negative' : '' ) );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, negative ? '🤝' : '🎧' ) );
		title.appendChild( el( 'span', null, negative ? 'ما کنار شما هستیم' : 'پشتیبانی' ) );
		card.appendChild( title );

		card.appendChild( el( 'div', 'aia-support-msg', p.message ||
			( negative ? 'متأسفیم که ناراحت شدید. اجازه بدهید سریع‌تر کمکتان کنیم.' : 'چطور می‌توانیم بیشتر کمکتان کنیم؟' ) ) );

		var actions = el( 'div', 'aia-support-actions' );
		var ho = p.handoff || {};

		var complaint = el( 'button', 'aia-support-btn', 'ثبت شکایت' );
		complaint.addEventListener( 'click', function () { h.sendMessage( 'می‌خواهم یک شکایت ثبت کنم.' ); } );
		actions.appendChild( complaint );

		var ticket = el( 'button', 'aia-support-btn', 'پیام به پشتیبان' );
		ticket.addEventListener( 'click', function () { h.sendMessage( 'می‌خواهم یک پیام برای پشتیبان واقعی ثبت کنم.' ); } );
		actions.appendChild( ticket );

		// «درخواست تماس»: اگر فرم تماس تنظیم شده باشد آن را باز می‌کند، وگرنه پیام به چت می‌فرستد.
		if ( ho.form ) {
			actions.appendChild( linkBtn( el, 'درخواست تماس', ho.form, '' ) );
		} else {
			var callback = el( 'button', 'aia-support-btn', 'درخواست تماس' );
			callback.addEventListener( 'click', function () { h.sendMessage( 'لطفاً با من تماس بگیرید و شماره من را ثبت کنید.' ); } );
			actions.appendChild( callback );
		}

		if ( ho.whatsapp ) { actions.appendChild( linkBtn( el, 'واتساپ', ho.whatsapp, 'wa' ) ); }
		if ( ho.telegram ) { actions.appendChild( linkBtn( el, 'تلگرام', ho.telegram, 'tg' ) ); }

		card.appendChild( actions );
		return card;
	};

	function linkBtn( el, text, url, cls ) {
		var a = el( 'a', 'aia-support-btn primary ' + cls, text );
		a.href = url; a.target = '_blank'; a.rel = 'noopener';
		return a;
	}
} )();
