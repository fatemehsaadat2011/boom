/**
 * ویجت معرفی یک محصول (product_info).
 * payload سمت سرور از داده واقعی پر می‌شود:
 *   { name, price, old_price, on_sale, in_stock, rating, review_count, image, url, reason, rows:[{label,value}] }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.product_info = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget aia-pinfo' );

		var top = el( 'div', 'aia-pinfo-top' );
		if ( p.image ) { var im = el( 'img' ); im.src = p.image; im.alt = ''; top.appendChild( im ); }
		var head = el( 'div', 'aia-pinfo-head' );
		head.appendChild( el( 'div', 'aia-pinfo-name', p.name || '' ) );

		var priceRow = el( 'div', 'aia-pinfo-prices' );
		if ( p.on_sale && p.old_price ) { priceRow.appendChild( el( 'del', 'aia-pinfo-old', p.old_price ) ); }
		if ( p.price ) { priceRow.appendChild( el( 'span', 'aia-pinfo-price', p.price ) ); }
		head.appendChild( priceRow );

		var badges = el( 'div', 'aia-pinfo-badges' );
		badges.appendChild( el( 'span', 'aia-pinfo-stock ' + ( p.in_stock ? 'in' : 'out' ), p.in_stock ? 'موجود' : 'ناموجود' ) );
		if ( p.rating ) {
			badges.appendChild( el( 'span', 'aia-pinfo-rate', '★ ' + p.rating + ( p.review_count ? ' (' + p.review_count + ')' : '' ) ) );
		}
		head.appendChild( badges );
		top.appendChild( head );
		card.appendChild( top );

		if ( p.reason ) {
			var reason = el( 'div', 'aia-pinfo-reason' );
			reason.appendChild( el( 'span', null, '💡 ' ) );
			reason.appendChild( document.createTextNode( p.reason ) );
			card.appendChild( reason );
		}

		// ویژگی‌های کلیدی (حداکثر ۵ ردیف برای جمع‌وجور ماندن)
		if ( Array.isArray( p.rows ) && p.rows.length ) {
			var specs = el( 'div', 'aia-pinfo-specs' );
			p.rows.slice( 0, 6 ).forEach( function ( r ) {
				if ( ! r.label || r.label === 'قیمت' ) { return; }
				var row = el( 'div', 'aia-pinfo-spec' );
				row.appendChild( el( 'span', 'aia-pinfo-spec-l', r.label ) );
				row.appendChild( el( 'span', 'aia-pinfo-spec-v', r.value || '—' ) );
				specs.appendChild( row );
			} );
			if ( specs.childNodes.length ) { card.appendChild( specs ); }
		}

		if ( p.url ) {
			var a = el( 'a', 'aia-pinfo-btn', 'مشاهده و خرید محصول' );
			a.href = p.url; a.target = '_blank'; a.rel = 'noopener';
			card.appendChild( a );
		}

		return card;
	};
} )();
