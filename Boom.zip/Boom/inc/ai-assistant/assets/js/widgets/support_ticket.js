/**
 * ویجت ثبت پیام برای پشتیبان انسانی (support_ticket).
 * فرم تعاملی که پیام کاربر را به اندپوینت ticket می‌فرستد تا در گزارش‌های سایت ثبت شود.
 * payload: { subject, prefill }  (پیشنهادی از مدل)
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.support_ticket = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var CFG = h.config || {};
		var user = CFG.user || {};

		var card = el( 'div', 'aia-widget aia-ticket' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '📨' ) );
		title.appendChild( el( 'span', null, 'پیام به پشتیبان' ) );
		card.appendChild( title );

		card.appendChild( el( 'div', 'aia-ticket-hint', 'پیام شما مستقیم برای تیم پشتیبانی ثبت می‌شود و در اولین فرصت پاسخ می‌دهیم.' ) );

		var form = el( 'div', 'aia-ticket-form' );

		// نام (اگر لاگین نباشد قابل ویرایش)
		var nameInput = el( 'input', 'aia-ticket-input' );
		nameInput.type = 'text';
		nameInput.placeholder = 'نام شما';
		nameInput.value = user.name || '';
		form.appendChild( field( el, 'نام', nameInput ) );

		// راه ارتباطی
		var contactInput = el( 'input', 'aia-ticket-input' );
		contactInput.type = 'text';
		contactInput.dir = 'ltr';
		contactInput.placeholder = 'ایمیل یا شماره تماس';
		contactInput.value = user.email || '';
		form.appendChild( field( el, 'راه ارتباطی', contactInput ) );

		// موضوع
		var subjectInput = el( 'input', 'aia-ticket-input' );
		subjectInput.type = 'text';
		subjectInput.placeholder = 'موضوع';
		subjectInput.value = p.subject || '';
		form.appendChild( field( el, 'موضوع', subjectInput ) );

		// متن پیام
		var msgInput = el( 'textarea', 'aia-ticket-input aia-ticket-msg' );
		msgInput.rows = 3;
		msgInput.placeholder = 'متن پیام خود را بنویسید…';
		msgInput.value = p.prefill || '';
		form.appendChild( field( el, 'پیام', msgInput ) );

		var error = el( 'div', 'aia-ticket-error' );
		error.style.display = 'none';
		form.appendChild( error );

		var submit = el( 'button', 'aia-ticket-submit', 'ارسال برای پشتیبان' );
		form.appendChild( submit );
		card.appendChild( form );

		submit.addEventListener( 'click', function () {
			var msg = ( msgInput.value || '' ).trim();
			var contact = ( contactInput.value || '' ).trim();
			if ( msg.length < 3 ) { return showError( 'لطفاً متن پیام را بنویسید.' ); }
			if ( ! user.loggedIn && ! contact ) { return showError( 'برای پاسخ‌گویی، ایمیل یا شماره تماس را وارد کنید.' ); }

			submit.disabled = true;
			submit.textContent = 'در حال ارسال…';
			error.style.display = 'none';

			fetch( CFG.ticketUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.nonce },
				credentials: 'same-origin',
				body: JSON.stringify( {
					name: nameInput.value || '',
					contact: contact,
					subject: subjectInput.value || '',
					message: msg,
					page_url: ( window.location && window.location.href ) || ''
				} )
			} )
				.then( function ( r ) { return r.json().then( function ( d ) { return { ok: r.ok, body: d }; } ); } )
				.then( function ( res ) {
					if ( res.ok && res.body && res.body.ok ) {
						renderSuccess( res.body );
					} else {
						submit.disabled = false;
						submit.textContent = 'ارسال برای پشتیبان';
						showError( ( res.body && res.body.message ) || 'ارسال ناموفق بود. دوباره تلاش کنید.' );
					}
				} )
				.catch( function () {
					submit.disabled = false;
					submit.textContent = 'ارسال برای پشتیبان';
					showError( 'خطای ارتباط. دوباره تلاش کنید.' );
				} );
		} );

		function showError( txt ) {
			error.textContent = txt;
			error.style.display = 'block';
		}

		function renderSuccess( body ) {
			card.textContent = '';
			var ok = el( 'div', 'aia-ticket-success' );
			ok.appendChild( el( 'div', 'aia-ticket-check', '✓' ) );
			ok.appendChild( el( 'div', 'aia-ticket-okmsg', ( body && body.message ) || 'پیام شما ثبت شد.' ) );
			if ( body && body.ticket_id ) {
				ok.appendChild( el( 'div', 'aia-ticket-id', 'شماره پیگیری: #' + body.ticket_id ) );
			}
			card.appendChild( ok );
		}

		return card;
	};

	function field( el, label, input ) {
		var wrap = el( 'div', 'aia-ticket-field' );
		wrap.appendChild( el( 'label', 'aia-ticket-label', label ) );
		wrap.appendChild( input );
		return wrap;
	}
} )();
