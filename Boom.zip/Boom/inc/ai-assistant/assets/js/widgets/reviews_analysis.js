/**
 * ویجت تحلیل نظرات (reviews_analysis).
 * payload: { product_name, satisfaction(0-100), review_count, praises:[], criticisms:[] }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	function list( el, cls, sign, items ) {
		var ul = el( 'ul', 'aia-pc-list ' + cls );
		( items || [] ).forEach( function ( t ) {
			var li = el( 'li' );
			li.appendChild( el( 'span', 'aia-pc-sign', sign ) );
			li.appendChild( document.createTextNode( t ) );
			ul.appendChild( li );
		} );
		return ul;
	}

	window.BoomAIAWidgets.reviews_analysis = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var sat = Math.max( 0, Math.min( 100, p.satisfaction || 0 ) );
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '💬' ) );
		title.appendChild( el( 'span', null, 'تحلیل نظرات' + ( p.product_name ? ': ' + p.product_name : '' ) ) );
		card.appendChild( title );

		// حلقه درصد رضایت
		var gauge = el( 'div', 'aia-ra-gauge' );
		var ring = el( 'div', 'aia-ra-ring' );
		ring.style.background = 'conic-gradient(var(--aia-primary) ' + sat + '%, #e2e8f0 0)';
		ring.appendChild( el( 'div', 'aia-ra-ring-in', sat + '%' ) );
		gauge.appendChild( ring );
		var info = el( 'div', 'aia-ra-info' );
		info.appendChild( el( 'div', 'aia-ra-label', 'رضایت کلی' ) );
		if ( p.review_count ) { info.appendChild( el( 'div', 'aia-ra-count', 'بر اساس ' + p.review_count + ' نظر' ) ); }
		gauge.appendChild( info );
		card.appendChild( gauge );

		if ( ( p.praises || [] ).length ) {
			card.appendChild( el( 'div', 'aia-pc-head pos', 'بیشترین تحسین‌ها' ) );
			card.appendChild( list( el, 'pos', '✓', p.praises ) );
		}
		if ( ( p.criticisms || [] ).length ) {
			card.appendChild( el( 'div', 'aia-pc-head neg', 'بیشترین انتقادها' ) );
			card.appendChild( list( el, 'neg', '✗', p.criticisms ) );
		}

		return card;
	};
} )();
