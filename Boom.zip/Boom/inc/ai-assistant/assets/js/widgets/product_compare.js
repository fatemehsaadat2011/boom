/**
 * ویجت مقایسه محصول (product_compare).
 * جدول ستونی: ستون هر محصول کنار هم (محصول اول سمت راست، دوم سمت چپ به‌خاطر RTL).
 * payload (پس از enrich سمت سرور): { products:[{name, image, url, rows:[{label,value}]}], conclusion }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.product_compare = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var products = ( p.products || [] ).slice( 0, 3 );
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '⚖️' ) );
		title.appendChild( el( 'span', null, 'مقایسه محصولات' ) );
		card.appendChild( title );

		if ( products.length < 2 ) {
			card.appendChild( el( 'div', 'aia-rec-empty', 'برای مقایسه حداقل دو محصول لازم است.' ) );
			return card;
		}

		// عرض ستون‌ها به‌صورت صریح تا چیدمان قابل اعتماد باشد.
		var cols = '0.85fr repeat(' + products.length + ', 1fr)';

		var box = el( 'div', 'aia-cmp-box' );

		// ردیف هدر: گوشه خالی + کارت هر محصول
		var head = el( 'div', 'aia-cmp-grid aia-cmp-headrow' );
		head.style.gridTemplateColumns = cols;
		head.appendChild( el( 'div', 'aia-cmp-corner' ) );
		products.forEach( function ( prod ) {
			var c = el( 'div', 'aia-cmp-head' );
			if ( prod.image ) { var im = el( 'img' ); im.src = prod.image; im.alt = ''; c.appendChild( im ); }
			var nm = prod.url ? el( 'a', 'aia-cmp-name' ) : el( 'div', 'aia-cmp-name' );
			nm.textContent = prod.name || '';
			if ( prod.url ) { nm.href = prod.url; nm.target = '_blank'; nm.rel = 'noopener'; }
			c.appendChild( nm );
			head.appendChild( c );
		} );
		box.appendChild( head );

		// مجموعه برچسب‌ها (اتحاد همه محصولات، با حفظ ترتیب)
		var labels = [];
		products.forEach( function ( prod ) {
			( prod.rows || [] ).forEach( function ( r ) {
				if ( r.label && labels.indexOf( r.label ) === -1 ) { labels.push( r.label ); }
			} );
		} );

		labels.forEach( function ( label, i ) {
			var row = el( 'div', 'aia-cmp-grid aia-cmp-row' + ( i % 2 ? ' alt' : '' ) );
			row.style.gridTemplateColumns = cols;
			row.appendChild( el( 'div', 'aia-cmp-label', label ) );
			products.forEach( function ( prod ) {
				var val = '';
				( prod.rows || [] ).forEach( function ( r ) { if ( r.label === label ) { val = r.value; } } );
				row.appendChild( el( 'div', 'aia-cmp-val', val || '—' ) );
			} );
			box.appendChild( row );
		} );

		card.appendChild( box );

		if ( p.conclusion ) {
			var conc = el( 'div', 'aia-cmp-conclusion' );
			conc.appendChild( el( 'b', null, '🤖 نتیجه نهایی: ' ) );
			conc.appendChild( document.createTextNode( p.conclusion ) );
			card.appendChild( conc );
		}

		return card;
	};
} )();
