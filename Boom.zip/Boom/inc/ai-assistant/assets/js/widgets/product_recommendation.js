/**
 * ویجت پیشنهاد خرید (product_recommendation).
 * کارت‌های تمام‌عرض: عکس سمت راست، نام و قیمت کنارش، دکمه خرید سمت چپ.
 * payload (پس از enrich سمت سرور): { title, products:[{name, price, image, url, reason}] }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.product_recommendation = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var products = ( p.products || [] ).filter( function ( pr ) { return pr && ( pr.name || pr.image ); } );

		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '🛍️' ) );
		title.appendChild( el( 'span', null, p.title || 'پیشنهاد برای شما' ) );
		card.appendChild( title );

		if ( ! products.length ) {
			card.appendChild( el( 'div', 'aia-rec-empty', 'فعلاً محصول مناسبی پیدا نشد.' ) );
			return card;
		}

		var list = el( 'div', 'aia-rec-list' );
		products.forEach( function ( pr ) {
			list.appendChild( recCard( el, pr ) );
		} );
		card.appendChild( list );

		return card;
	};

	function recCard( el, pr ) {
		var row = el( 'div', 'aia-rec-card' );

		// عکس (سمت راست به‌خاطر RTL)
		var img = el( 'div', 'aia-rec-img' );
		if ( pr.image ) {
			var im = el( 'img' ); im.src = pr.image; im.alt = ''; im.loading = 'lazy'; img.appendChild( im );
		}
		row.appendChild( img );

		// میانه: نام، قیمت، دلیل
		var mid = el( 'div', 'aia-rec-mid' );
		mid.appendChild( el( 'div', 'aia-rec-name', pr.name || '' ) );
		if ( pr.price ) { mid.appendChild( el( 'div', 'aia-rec-price', pr.price ) ); }
		if ( pr.reason ) { mid.appendChild( el( 'div', 'aia-rec-reason', pr.reason ) ); }
		row.appendChild( mid );

		// سمت چپ: دکمه خرید
		if ( pr.url ) {
			var buy = el( 'a', 'aia-rec-buy' );
			buy.href = pr.url; buy.target = '_blank'; buy.rel = 'noopener';
			buy.appendChild( el( 'span', null, 'خرید' ) );
			row.appendChild( buy );
		}

		return row;
	}
} )();
