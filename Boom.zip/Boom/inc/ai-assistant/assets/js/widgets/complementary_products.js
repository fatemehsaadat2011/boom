/**
 * ویجت محصولات مکمل (complementary_products).
 * کارت‌های افقی اسکرول‌شونده.
 * payload: { title, products:[{name, price, image, url, reason}] }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.complementary_products = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '➕' ) );
		title.appendChild( el( 'span', null, p.title || 'تکمیل خرید شما' ) );
		card.appendChild( title );

		var scroller = el( 'div', 'aia-hscroll' );
		( p.products || [] ).forEach( function ( prod ) {
			var c = h.productCard( prod );
			c.classList.add( 'aia-pcard-h' );
			scroller.appendChild( c );
		} );
		card.appendChild( scroller );

		return card;
	};
} )();
