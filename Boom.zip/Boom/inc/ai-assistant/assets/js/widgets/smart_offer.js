/**
 * ویجت تخفیف هوشمند (smart_offer).
 * payload: { title, message, product_name, old_price, new_price, discount_label, url }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.smart_offer = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget aia-offer' );

		var top = el( 'div', 'aia-offer-top' );
		top.appendChild( el( 'span', 'aia-offer-icon', '🔥' ) );
		top.appendChild( el( 'strong', null, p.title || 'پیشنهاد ویژه' ) );
		if ( p.discount_label ) { top.appendChild( el( 'span', 'aia-offer-badge', p.discount_label ) ); }
		card.appendChild( top );

		if ( p.message ) { card.appendChild( el( 'div', 'aia-offer-msg', p.message ) ); }
		if ( p.product_name ) { card.appendChild( el( 'div', 'aia-offer-name', p.product_name ) ); }

		if ( p.old_price || p.new_price ) {
			var prices = el( 'div', 'aia-offer-prices' );
			if ( p.old_price ) { prices.appendChild( el( 'del', 'aia-offer-old', p.old_price ) ); }
			if ( p.new_price ) { prices.appendChild( el( 'span', 'aia-offer-new', p.new_price ) ); }
			card.appendChild( prices );
		}

		if ( p.url ) {
			var a = el( 'a', 'aia-offer-btn', 'استفاده از پیشنهاد' );
			a.href = p.url; a.target = '_blank'; a.rel = 'noopener';
			card.appendChild( a );
		}

		return card;
	};
} )();
