/**
 * ویجت وضعیت سفارش (order_status).
 *
 * payload (از get_order_status می‌آید، نه از تخیل مدل):
 *   { order_number, date, status_label, total, progress(0-100),
 *     tracking_code, carrier, view_url,
 *     timeline:[{label, done, active}], items:[{name, quantity, total, image}] }
 *
 * ثبت می‌شود روی window.BoomAIAWidgets.order_status و یک HTMLElement برمی‌گرداند.
 * همه مقادیر با textContent ست می‌شوند (ضد-XSS).
 */
( function () {
	'use strict';

	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.order_status = function ( p, h ) {
		var el = h.el;
		p = p || {};

		var card = el( 'div', 'aia-widget aia-os' );

		// تیتر + برچسب وضعیت
		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '📦' ) );
		title.appendChild( el( 'span', null, 'سفارش #' + ( p.order_number || '' ) ) );
		if ( p.status_label ) {
			title.appendChild( el( 'span', 'aia-w-badge', p.status_label ) );
		}
		card.appendChild( title );

		// متادیتا
		var meta = el( 'div', 'aia-os-meta' );
		if ( p.date ) {
			var d = el( 'div' ); d.appendChild( document.createTextNode( 'تاریخ: ' ) );
			d.appendChild( el( 'b', null, p.date ) ); meta.appendChild( d );
		}
		if ( p.total ) {
			var t = el( 'div' ); t.appendChild( document.createTextNode( 'مبلغ: ' ) );
			t.appendChild( el( 'b', null, p.total ) ); meta.appendChild( t );
		}
		card.appendChild( meta );

		// نوار پیشرفت
		if ( typeof p.progress === 'number' ) {
			var bar = el( 'div', 'aia-os-progress' );
			var fill = el( 'span' );
			fill.style.width = Math.max( 0, Math.min( 100, p.progress ) ) + '%';
			bar.appendChild( fill );
			card.appendChild( bar );
		}

		// تایم‌لاین مرحله‌ای
		if ( Array.isArray( p.timeline ) && p.timeline.length ) {
			var tl = el( 'div', 'aia-os-timeline' );
			p.timeline.forEach( function ( step ) {
				var s = el( 'div', 'aia-os-step' + ( step.done ? ' done' : '' ) + ( step.active ? ' active' : '' ) );
				var dot = el( 'div', 'aia-os-dot', step.done ? '✓' : '' );
				s.appendChild( dot );
				s.appendChild( el( 'span', null, step.label || '' ) );
				tl.appendChild( s );
			} );
			card.appendChild( tl );
		}

		// رهگیری
		if ( p.tracking_code || p.carrier ) {
			var track = el( 'div', 'aia-os-track' );
			if ( p.carrier ) { track.appendChild( el( 'b', null, 'شرکت حمل: ' + p.carrier ) ); }
			if ( p.tracking_code ) {
				track.appendChild( document.createTextNode( 'کد رهگیری: ' ) );
				track.appendChild( el( 'code', null, p.tracking_code ) );
			}
			card.appendChild( track );
		}

		// اقلام
		if ( Array.isArray( p.items ) && p.items.length ) {
			var items = el( 'div', 'aia-os-items' );
			p.items.forEach( function ( it ) {
				var row = el( 'div', 'aia-os-item' );
				if ( it.image ) {
					var im = el( 'img' ); im.src = it.image; im.alt = ''; row.appendChild( im );
				}
				var name = el( 'div', 'aia-os-iname', it.name || '' );
				if ( it.quantity ) { name.appendChild( el( 'div', 'aia-os-iqty', 'تعداد: ' + it.quantity ) ); }
				row.appendChild( name );
				if ( it.total ) { row.appendChild( el( 'div', null, it.total ) ); }
				items.appendChild( row );
			} );
			card.appendChild( items );
		}

		// اقدام‌های سریع
		var actions = el( 'div', 'aia-os-actions' );

		if ( p.view_url ) {
			var view = el( 'a', null, 'مشاهده جزئیات' );
			view.href = p.view_url; view.target = '_blank'; view.rel = 'noopener';
			actions.appendChild( view );
		}

		var trackBtn = el( 'button', null, 'رهگیری مرسوله' );
		trackBtn.addEventListener( 'click', function () {
			h.sendMessage( 'وضعیت ارسال سفارش ' + ( p.order_number || '' ) + ' را می‌خواهم.' );
		} );
		actions.appendChild( trackBtn );

		var support = el( 'button', null, 'ثبت مشکل' );
		support.addEventListener( 'click', function () {
			h.sendMessage( 'برای سفارش ' + ( p.order_number || '' ) + ' مشکل دارم و نیاز به پشتیبانی دارم.' );
		} );
		actions.appendChild( support );

		card.appendChild( actions );

		// یادداشت توضیحی (مثلاً برای سفارش نمونه) — فقط در صورت وجود متن.
		if ( p.note ) {
			var note = el( 'div', 'aia-os-note' );
			note.appendChild( el( 'span', 'aia-os-note-icon', 'ℹ️' ) );
			note.appendChild( el( 'span', null, p.note ) );
			card.appendChild( note );
		}

		return card;
	};
} )();
