/**
 * ویجت خلاصه محصول (product_summary) — context-aware صفحه محصول.
 * payload: { product_name, good_for:[], bad_for:[], read_time }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	function block( el, cls, head, sign, items ) {
		var box = el( 'div', 'aia-sum-block ' + cls );
		box.appendChild( el( 'div', 'aia-sum-head', head ) );
		var ul = el( 'ul', 'aia-pc-list ' + cls );
		( items || [] ).forEach( function ( t ) {
			var li = el( 'li' );
			li.appendChild( el( 'span', 'aia-pc-sign', sign ) );
			li.appendChild( document.createTextNode( t ) );
			ul.appendChild( li );
		} );
		box.appendChild( ul );
		return box;
	}

	window.BoomAIAWidgets.product_summary = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '📝' ) );
		title.appendChild( el( 'span', null, 'خلاصه: ' + ( p.product_name || '' ) ) );
		if ( p.read_time ) { title.appendChild( el( 'span', 'aia-w-badge', '⏱ ' + p.read_time ) ); }
		card.appendChild( title );

		if ( ( p.good_for || [] ).length ) { card.appendChild( block( el, 'pos', 'مناسب برای', '✓', p.good_for ) ); }
		if ( ( p.bad_for || [] ).length ) { card.appendChild( block( el, 'neg', 'مناسب نیست برای', '✗', p.bad_for ) ); }

		return card;
	};
} )();
