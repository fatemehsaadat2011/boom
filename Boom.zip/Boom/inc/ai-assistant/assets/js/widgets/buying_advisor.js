/**
 * ویجت مشاور خرید مرحله‌ای (buying_advisor) — تعاملی با state داخلی.
 * payload: { title, steps:[{key, question, options:[]}] }
 *
 * هر گام گزینه‌های قابل کلیک نشان می‌دهد، انتخاب کاربر را جمع می‌کند،
 * در پایان «جمع‌بندی نیاز» را نشان داده و انتخاب‌ها را به چت feed می‌کند
 * تا مدل recommend_products را صدا بزند.
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.buying_advisor = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var steps = p.steps || [];
		var answers = {};
		var current = 0;

		var card = el( 'div', 'aia-widget aia-advisor' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '🧭' ) );
		title.appendChild( el( 'span', null, p.title || 'مشاور خرید' ) );
		card.appendChild( title );

		var progress = el( 'div', 'aia-adv-progress' );
		card.appendChild( progress );

		var stage = el( 'div', 'aia-adv-stage' );
		card.appendChild( stage );

		function renderProgress() {
			progress.textContent = '';
			steps.forEach( function ( s, i ) {
				var dot = el( 'span', 'aia-adv-dot' + ( i < current ? ' done' : ( i === current ? ' active' : '' ) ) );
				progress.appendChild( dot );
			} );
		}

		function renderStep() {
			stage.textContent = '';
			if ( current >= steps.length ) { renderSummary(); return; }
			var step = steps[ current ];
			stage.appendChild( el( 'div', 'aia-adv-q', step.question || '' ) );
			var opts = el( 'div', 'aia-adv-opts' );
			( step.options || [] ).forEach( function ( opt ) {
				var b = el( 'button', 'aia-adv-opt', opt );
				b.addEventListener( 'click', function () {
					answers[ step.key || ( 'step_' + current ) ] = opt;
					current++;
					renderProgress();
					renderStep();
				} );
				opts.appendChild( b );
			} );
			stage.appendChild( opts );
			renderProgress();
		}

		function renderSummary() {
			stage.appendChild( el( 'div', 'aia-adv-sum-head', '📋 جمع‌بندی نیاز شما' ) );
			var ul = el( 'ul', 'aia-adv-sum' );
			steps.forEach( function ( s ) {
				var key = s.key || '';
				if ( answers[ key ] != null ) {
					var li = el( 'li' );
					li.appendChild( el( 'b', null, ( s.question || key ) + ' ' ) );
					li.appendChild( document.createTextNode( answers[ key ] ) );
					ul.appendChild( li );
				}
			} );
			stage.appendChild( ul );

			var go = el( 'button', 'aia-adv-go', 'مشاهده پیشنهادها' );
			go.addEventListener( 'click', function () {
				go.disabled = true;
				var parts = [];
				steps.forEach( function ( s ) {
					var key = s.key || '';
					if ( answers[ key ] != null ) {
						parts.push( ( s.question || key ) + ' ' + answers[ key ] );
					}
				} );
				h.sendMessage( 'بر اساس این نیازها به من محصول پیشنهاد بده: ' + parts.join( '؛ ' ) );
			} );
			stage.appendChild( go );
		}

		renderStep();
		return card;
	};
} )();
