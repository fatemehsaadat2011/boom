/**
 * ویجت پروفایل/تاریخچه مشتری (customer_context).
 * payload: { display_name, recent_orders:[{order_number,date,status_label,total}], purchased:[{name,image,url,...}] }
 */
( function () {
	'use strict';
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	window.BoomAIAWidgets.customer_context = function ( p, h ) {
		var el = h.el;
		p = p || {};
		var card = el( 'div', 'aia-widget' );

		var title = el( 'div', 'aia-w-title' );
		title.appendChild( el( 'span', null, '👤' ) );
		title.appendChild( el( 'span', null, p.display_name ? ( 'سلام ' + p.display_name ) : 'حساب شما' ) );
		card.appendChild( title );

		if ( ( p.recent_orders || [] ).length ) {
			card.appendChild( el( 'div', 'aia-cc-head', 'سفارش‌های اخیر' ) );
			var list = el( 'div', 'aia-cc-orders' );
			p.recent_orders.forEach( function ( o ) {
				var row = el( 'div', 'aia-cc-order' );
				row.appendChild( el( 'span', 'aia-cc-onum', '#' + ( o.order_number || '' ) ) );
				row.appendChild( el( 'span', 'aia-cc-ostatus', o.status_label || '' ) );
				row.appendChild( el( 'span', 'aia-cc-ototal', o.total || '' ) );
				list.appendChild( row );
			} );
			card.appendChild( list );
		}

		if ( ( p.purchased || [] ).length ) {
			card.appendChild( el( 'div', 'aia-cc-head', 'خریدهای قبلی' ) );
			var scroller = el( 'div', 'aia-hscroll' );
			p.purchased.forEach( function ( prod ) {
				var c = h.productCard( prod );
				c.classList.add( 'aia-pcard-h' );
				scroller.appendChild( c );
			} );
			card.appendChild( scroller );
		}

		return card;
	};
} )();
