/**
 * هسته دستیار چت + رندرر ویجت‌ها (وانیلا JS).
 *
 * - API key هرگز اینجا نیست؛ فقط با REST خود وردپرس (nonce wp_rest) صحبت می‌کند.
 * - ویجت‌ها به صورت plugin ثبت می‌شوند روی window.BoomAIAWidgets[type] = function(payload, helpers){...}
 *   و باید یک HTMLElement برگردانند. افزودن ویجت جدید بدون دست‌زدن به هسته است.
 */
( function () {
	'use strict';

	var CFG = window.BoomAIA;
	if ( ! CFG || ! CFG.restUrl ) {
		return;
	}

	// رجیستری ویجت‌ها (ماژول‌های widgets/*.js خود را اینجا ثبت می‌کنند).
	window.BoomAIAWidgets = window.BoomAIAWidgets || {};

	var STORE_KEY = 'boom_aia_history_v1';

	// آیکون‌های ثابت داخلی (نه محتوای کاربر).
	var CHAT_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/><path d="M8.5 12.5s1.2 1.5 3.5 1.5 3.5-1.5 3.5-1.5"/><circle cx="9" cy="9.5" r="0.6" fill="currentColor" stroke="none"/><circle cx="15" cy="9.5" r="0.6" fill="currentColor" stroke="none"/></svg>';
	var BOT_FACE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="7" width="16" height="12" rx="4"/><path d="M12 7V4"/><circle cx="12" cy="3" r="1" fill="currentColor" stroke="none"/><circle cx="9" cy="12.5" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="12.5" r="1" fill="currentColor" stroke="none"/><path d="M9.5 15.5s1 1 2.5 1 2.5-1 2.5-1"/></svg>';

	/* ----------------------------- ابزارها ---------------------------- */

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( text != null ) { n.textContent = text; }
		return n;
	}

	function svg( markup ) {
		var wrap = document.createElement( 'span' );
		wrap.innerHTML = markup; // فقط آیکون‌های ثابت داخلی، نه محتوای کاربر.
		return wrap.firstChild;
	}

	function loadHistory() {
		try {
			var raw = localStorage.getItem( STORE_KEY );
			var arr = raw ? JSON.parse( raw ) : [];
			return Array.isArray( arr ) ? arr : [];
		} catch ( e ) { return []; }
	}

	function saveHistory( arr ) {
		try { localStorage.setItem( STORE_KEY, JSON.stringify( arr.slice( -40 ) ) ); } catch ( e ) {}
	}

	/* --------------------- رندر امن مارک‌داون (فقط پیام بات) --------------- */

	function escapeHtml( s ) {
		return String( s )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#39;' );
	}

	// تبدیل عناصر inline روی متنِ از قبل escape‌شده.
	function mdInline( s ) {
		// لینک [متن](http...) — فقط http/https تا از javascript: جلوگیری شود.
		s = s.replace( /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function ( m, text, url ) {
			return '<a href="' + url + '" target="_blank" rel="noopener nofollow">' + text + '</a>';
		} );
		s = s.replace( /\*\*([^*]+)\*\*/g, '<strong>$1</strong>' );
		s = s.replace( /__([^_]+)__/g, '<strong>$1</strong>' );
		s = s.replace( /(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>' );
		s = s.replace( /`([^`]+)`/g, '<code>$1</code>' );
		return s;
	}

	function mdToHtml( text ) {
		var esc = escapeHtml( text ).replace( /\r\n/g, '\n' );
		var lines = esc.split( '\n' );
		var html = '';
		var listType = null;
		function closeList() { if ( listType ) { html += '</' + listType + '>'; listType = null; } }

		for ( var i = 0; i < lines.length; i++ ) {
			var line = lines[ i ];
			var t = line.trim();
			var h = t.match( /^#{1,6}\s+(.*)$/ );
			var ul = t.match( /^[-*•]\s+(.*)$/ );
			var ol = t.match( /^\d+[.)]\s+(.*)$/ );

			if ( h ) {
				closeList();
				html += '<div class="aia-md-line"><strong>' + mdInline( h[ 1 ] ) + '</strong></div>';
			} else if ( ul ) {
				if ( 'ul' !== listType ) { closeList(); html += '<ul>'; listType = 'ul'; }
				html += '<li>' + mdInline( ul[ 1 ] ) + '</li>';
			} else if ( ol ) {
				if ( 'ol' !== listType ) { closeList(); html += '<ol>'; listType = 'ol'; }
				html += '<li>' + mdInline( ol[ 1 ] ) + '</li>';
			} else if ( '' === t ) {
				closeList();
			} else {
				closeList();
				html += '<div class="aia-md-line">' + mdInline( line ) + '</div>';
			}
		}
		closeList();
		return html;
	}

	/* ----------------------------- اپلیکیشن --------------------------- */

	function App( root ) {
		this.root = root;
		this.history = loadHistory(); // [{role, content}]  — ویجت‌ها ذخیره نمی‌شوند
		this.busy = false;
		this.build();
		this.replayHistory();
	}

	App.prototype.applyColors = function () {
		var c = CFG.colors || {};
		var map = {
			'--aia-primary': c.primary,
			'--aia-text': c.text,
			'--aia-bg-user': c.bgUser,
			'--aia-bg-bot': c.bgBot,
			'--aia-negative': c.negative
		};
		for ( var k in map ) {
			if ( map[ k ] ) { this.root.style.setProperty( k, map[ k ] ); }
		}
	};

	App.prototype.applyOffsets = function () {
		var o = CFG.offsets || {};
		var r = this.root.style;
		if ( o.bottomD != null ) { r.setProperty( '--aia-ob-d', o.bottomD + 'px' ); }
		if ( o.sideD != null ) { r.setProperty( '--aia-os-d', o.sideD + 'px' ); }
		if ( o.bottomM != null ) { r.setProperty( '--aia-ob-m', o.bottomM + 'px' ); }
		if ( o.sideM != null ) { r.setProperty( '--aia-os-m', o.sideM + 'px' ); }
	};

	App.prototype.build = function () {
		this.root.classList.add( 'left' === CFG.position ? 'aia-left' : 'aia-right' );
		this.applyColors();
		this.applyOffsets();

		// دکمه شناور (با تصویر سفارشی یا آیکون پیش‌فرض)
		var launcher = el( 'button', 'aia-launcher' );
		launcher.setAttribute( 'aria-label', CFG.name || 'چت' );
		if ( CFG.launcherImage ) {
			launcher.classList.add( 'has-img' );
			var lim = el( 'img', 'aia-launcher-img' ); lim.src = CFG.launcherImage; lim.alt = '';
			launcher.appendChild( lim );
		} else {
			launcher.appendChild( svg( CHAT_ICON ) );
		}
		launcher.appendChild( el( 'span', 'aia-badge' ) );
		launcher.addEventListener( 'click', this.toggle.bind( this ) );

		// پنجره
		var win = el( 'div', 'aia-window' );

		// هدر
		var header = el( 'div', 'aia-header' );
		var ava = el( 'div', 'aia-ava' );
		if ( CFG.avatar ) {
			var img = el( 'img' ); img.src = CFG.avatar; img.alt = ''; ava.appendChild( img );
		} else {
			ava.appendChild( svg( BOT_FACE ) );
		}
		var meta = el( 'div', 'aia-meta' );
		meta.appendChild( el( 'strong', null, CFG.name || 'دستیار' ) );
		meta.appendChild( el( 'span', null, 'هم‌اکنون آنلاین' ) );
		var close = el( 'button', 'aia-close', '×' );
		close.setAttribute( 'aria-label', 'بستن' );
		close.addEventListener( 'click', this.toggle.bind( this ) );
		header.appendChild( ava );
		header.appendChild( meta );
		header.appendChild( close );

		// بدنه
		this.body = el( 'div', 'aia-body' );

		// quick replies
		this.quickWrap = el( 'div', 'aia-quick' );
		( CFG.quickReplies || [] ).forEach( function ( q ) {
			if ( 'string' !== typeof q || ! q.trim() ) { return; }
			var b = el( 'button', null, q );
			b.addEventListener( 'click', function () { this.send( q ); }.bind( this ) );
			this.quickWrap.appendChild( b );
		}.bind( this ) );

		// ورودی
		var inputWrap = el( 'div', 'aia-input' );
		this.textarea = el( 'textarea' );
		this.textarea.rows = 1;
		this.textarea.placeholder = ( CFG.i18n && CFG.i18n.placeholder ) || '...';
		this.textarea.addEventListener( 'input', this.autogrow.bind( this ) );
		this.textarea.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key && ! e.shiftKey ) {
				e.preventDefault();
				this.send( this.textarea.value );
			}
		}.bind( this ) );
		this.sendBtn = el( 'button', 'aia-send' );
		this.sendBtn.appendChild( svg( '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4l17.45-7.48a1 1 0 0 0 0-1.84L3.4 3.6a.993.993 0 0 0-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z"/></svg>' ) );
		this.sendBtn.addEventListener( 'click', function () { this.send( this.textarea.value ); }.bind( this ) );
		inputWrap.appendChild( this.textarea );
		inputWrap.appendChild( this.sendBtn );

		win.appendChild( header );
		win.appendChild( this.body );
		win.appendChild( this.quickWrap );
		win.appendChild( inputWrap );

		this.root.appendChild( win );
		this.root.appendChild( launcher );
	};

	App.prototype.toggle = function () {
		var open = this.root.classList.toggle( 'aia-open' );
		if ( open ) {
			if ( ! this.history.length && CFG.welcome ) {
				this.addBubble( 'bot', CFG.welcome );
			}
			setTimeout( function () { this.textarea.focus(); }.bind( this ), 250 );
			this.scroll();
		}
	};

	App.prototype.autogrow = function () {
		this.textarea.style.height = 'auto';
		this.textarea.style.height = Math.min( 120, this.textarea.scrollHeight ) + 'px';
	};

	App.prototype.replayHistory = function () {
		this.history.forEach( function ( m ) {
			this.addBubble( 'assistant' === m.role ? 'bot' : 'user', m.content, true );
		}.bind( this ) );
	};

	/* ------------------------------ پیام‌ها --------------------------- */

	// آواتار اپراتور برای پیام‌های بات.
	App.prototype.botAvatar = function () {
		var ava = el( 'div', 'aia-msg-ava' );
		if ( CFG.avatar ) {
			var im = el( 'img' ); im.src = CFG.avatar; im.alt = ''; ava.appendChild( im );
		} else {
			ava.appendChild( svg( BOT_FACE ) );
		}
		return ava;
	};

	App.prototype.addBubble = function ( who, text, skipScroll ) {
		var row = el( 'div', 'aia-row ' + who );

		if ( 'bot' === who ) {
			var grouped = 'bot' === this._lastWho;
			var ava = this.botAvatar();
			if ( grouped ) { ava.classList.add( 'grouped' ); }
			var col = el( 'div', 'aia-msg-col' );
			if ( ! grouped ) { col.appendChild( el( 'div', 'aia-msg-name', CFG.name || 'دستیار' ) ); }
			var bubble = el( 'div', 'aia-bubble aia-md' );
			bubble.innerHTML = mdToHtml( text ); // متن از قبل escape و فقط زیرمجموعه امن مارک‌داون
			col.appendChild( bubble );
			row.appendChild( ava );
			row.appendChild( col );
		} else {
			row.appendChild( el( 'div', 'aia-bubble', text ) );
		}

		this.body.appendChild( row );
		this._lastWho = who;
		if ( ! skipScroll ) { this.scroll(); }
		return row;
	};

	App.prototype.addWidget = function ( widget ) {
		var fn = window.BoomAIAWidgets[ widget.widget_type ];
		if ( 'function' !== typeof fn ) { return; }
		var node;
		try {
			node = fn( widget.payload || {}, this.helpers() );
		} catch ( e ) { return; }
		if ( ! node ) { return; }
		var row = el( 'div', 'aia-row bot aia-row-widget' );
		row.appendChild( node );
		this.body.appendChild( row );
		this._lastWho = 'bot';
		this.scroll();
	};

	// توابع کمکی که به ویجت‌ها داده می‌شود (مثلاً ارسال پیام بعدی به چت).
	App.prototype.helpers = function () {
		var self = this;
		return {
			el: el,
			sendMessage: function ( txt ) { self.send( txt ); },
			config: CFG,
			// کارت محصول مشترک بین چند ویجت.
			productCard: function ( p ) {
				p = p || {};
				var card = el( 'div', 'aia-pcard' );
				if ( p.image ) {
					var im = el( 'img' ); im.src = p.image; im.alt = ''; card.appendChild( im );
				}
				var b = el( 'div', 'aia-pcard-body' );
				b.appendChild( el( 'div', 'aia-pcard-name', p.name || '' ) );
				if ( p.price ) { b.appendChild( el( 'div', 'aia-pcard-price', p.price ) ); }
				if ( p.reason ) { b.appendChild( el( 'div', 'aia-pcard-reason', p.reason ) ); }
				if ( p.url ) {
					var a = el( 'a', 'aia-pcard-btn', 'مشاهده محصول' );
					a.href = p.url; a.target = '_blank'; a.rel = 'noopener';
					b.appendChild( a );
				}
				card.appendChild( b );
				return card;
			}
		};
	};

	App.prototype.showTyping = function () {
		this.typingRow = el( 'div', 'aia-row bot' );
		var ava = this.botAvatar();
		if ( 'bot' === this._lastWho ) { ava.classList.add( 'grouped' ); }
		var col = el( 'div', 'aia-msg-col' );
		var t = el( 'div', 'aia-bubble aia-typing' );
		t.appendChild( el( 'span' ) ); t.appendChild( el( 'span' ) ); t.appendChild( el( 'span' ) );
		col.appendChild( t );
		this.typingRow.appendChild( ava );
		this.typingRow.appendChild( col );
		this.body.appendChild( this.typingRow );
		this.scroll();
	};

	App.prototype.hideTyping = function () {
		if ( this.typingRow && this.typingRow.parentNode ) {
			this.typingRow.parentNode.removeChild( this.typingRow );
		}
		this.typingRow = null;
	};

	App.prototype.scroll = function () {
		var b = this.body;
		setTimeout( function () { b.scrollTop = b.scrollHeight; }, 30 );
	};

	App.prototype.setBusy = function ( busy ) {
		this.busy = busy;
		this.sendBtn.disabled = busy;
	};

	/* ----------------------------- ارسال ------------------------------ */

	App.prototype.send = function ( text ) {
		text = ( text || '' ).trim();
		if ( ! text || this.busy ) { return; }

		this.addBubble( 'user', text );
		this.history.push( { role: 'user', content: text } );
		saveHistory( this.history );

		this.textarea.value = '';
		this.autogrow();
		this.setBusy( true );
		this.showTyping();

		var self = this;
		fetch( CFG.restUrl, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': CFG.nonce
			},
			credentials: 'same-origin',
			body: JSON.stringify( {
				messages: self.history,
				page_context: CFG.pageContext || {}
			} )
		} )
			.then( function ( r ) { return r.json(); } )
			.then( function ( data ) {
				self.hideTyping();
				var reply = data && data.reply ? data.reply : '';
				if ( reply ) {
					self.addBubble( 'bot', reply );
					self.history.push( { role: 'assistant', content: reply } );
					saveHistory( self.history );
				}
				if ( data && Array.isArray( data.widgets ) ) {
					data.widgets.forEach( function ( w ) { self.addWidget( w ); } );
				}
			} )
			.catch( function () {
				self.hideTyping();
				self.addBubble( 'bot', ( CFG.i18n && CFG.i18n.error ) || 'خطا رخ داد.' );
			} )
			.finally( function () { self.setBusy( false ); } );
	};

	/* ------------------------------ راه‌اندازی ------------------------ */

	function init() {
		var root = document.getElementById( 'boom-aia-root' );
		if ( root && ! root._aiaInit ) {
			root._aiaInit = true;
			new App( root );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
