(function ($) {
  $(document).ready(function () {

    // ───── Helperهای ویجت‌های طلا و جواهر ─────
    // یک کارت بنر طلا (تصویر + عنوان + زیرعنوان + لینک)
    window.__gbRenderItem = function (it, gi) {
      it = it || {};
      const esc = (v) => (v || '').toString().replace(/"/g, '&quot;');
      return `
        <div class="gb-item" data-idx="${gi}" style="background:rgba(255,255,255,0.07);padding:12px;border-radius:8px;border:1px solid #c9a227;">
          <div style="font-size:12px;font-weight:700;color:#f5e6b8;margin-bottom:10px;">کارت ${gi + 1}</div>
          <div style="display:grid;grid-template-columns:200px 1fr 1fr 1fr;gap:10px;align-items:start;">
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">تصویر:</label>
              <input type="text" class="field-gb-item-image" value="${esc(it.image)}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;margin-bottom:6px;">
              <button type="button" class="button button-upload-gb" data-idx="${gi}" style="font-size:11px;">انتخاب تصویر</button>
              ${it.image ? `<img src="${esc(it.image)}" style="max-width:100%;max-height:60px;margin-top:6px;border-radius:4px;display:block;">` : ''}
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">عنوان:</label>
              <input type="text" class="field-gb-item-title" value="${esc(it.title)}" placeholder="مثلاً کمتر از ۲۰ میلیون" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">زیرعنوان:</label>
              <input type="text" class="field-gb-item-subtitle" value="${esc(it.subtitle)}" placeholder="مثلاً محصولات مینیمال" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">لینک:</label>
              <input type="text" class="field-gb-item-link" value="${esc(it.link)}" placeholder="/product-category/..." style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
            </div>
          </div>
        </div>`;
    };

    // یک کارت دسته‌بندی طلا (تصویر + عنوان + لینک)
    window.__gcRenderItem = function (it, gi) {
      it = it || {};
      const esc = (v) => (v || '').toString().replace(/"/g, '&quot;');
      return `
        <div class="gc-item" data-idx="${gi}" style="background:rgba(255,255,255,0.07);padding:12px;border-radius:8px;border:1px solid #c9a227;">
          <div style="font-size:12px;font-weight:700;color:#f5e6b8;margin-bottom:10px;">دسته ${gi + 1}</div>
          <div style="display:grid;grid-template-columns:220px 1fr 1fr;gap:10px;align-items:start;">
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">تصویر:</label>
              <input type="text" class="field-gc-item-image" value="${esc(it.image)}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;margin-bottom:6px;">
              <button type="button" class="button button-upload-gc" data-idx="${gi}" style="font-size:11px;">انتخاب تصویر</button>
              ${it.image ? `<img src="${esc(it.image)}" style="max-width:100%;max-height:60px;margin-top:6px;border-radius:4px;display:block;">` : ''}
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">عنوان دسته:</label>
              <input type="text" class="field-gc-item-title" value="${esc(it.title)}" placeholder="مثلاً گوشواره" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:11px;color:#f5e6b8;">لینک:</label>
              <input type="text" class="field-gc-item-link" value="${esc(it.link)}" placeholder="/product-category/..." style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
            </div>
          </div>
        </div>`;
    };

    // ───── Helperهای ویجت ناوبری دسته‌بندی (category_nav) ─────
    // رندر یک زیرشاخه سطح ۲ (نام + لینک + نمایش محصولات دسته)
    window.__cnRenderChild = function (child, ci, chi) {
      child = child || {};
      const esc = (v) => (v == null ? '' : String(v)).replace(/"/g, '&quot;');
      const showProducts = child.show_products === 'yes';
      const catId = esc(child.product_cat_id);
      const catName = esc(child.product_cat_name);
      const selectedChip = catId
        ? `<span class="cat-chip" data-id="${catId}" style="display:inline-flex;align-items:center;gap:6px;">${catName || ('#' + catId)} <b style="cursor:pointer;" class="cn-child-cat-remove">&times;</b></span>`
        : '';
      return `
        <div class="cn-child-item" data-cat="${ci}" data-child="${chi}" style="background:rgba(255,255,255,0.05);padding:10px;border-radius:8px;">
          <div style="display:grid;grid-template-columns:1fr 1fr 34px;gap:8px;align-items:center;">
            <input type="text" class="field-cn-child-name" value="${esc(child.name)}" placeholder="نام زیرشاخه" style="width:100%;padding:7px 10px;border:1px solid #34d399;border-radius:6px;font-size:12px;background:#022c22;color:#ecfdf5;">
            <input type="text" class="field-cn-child-link" value="${esc(child.link)}" placeholder="/product-category/..." style="width:100%;padding:7px 10px;border:1px solid #34d399;border-radius:6px;font-size:12px;background:#022c22;color:#ecfdf5;">
            <button type="button" class="button cn-remove-child" title="حذف زیرشاخه" style="background:#ef4444;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;line-height:1;padding:0;height:32px;">✕</button>
          </div>
          <label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:12px;color:#a7f3d0;cursor:pointer;">
            <input type="checkbox" class="field-cn-child-show-products" ${showProducts ? 'checked' : ''} style="accent-color:#10b981;width:16px;height:16px;">
            هنگام کلیک، محصولات یک دسته‌بندی نمایش داده شود (به‌جای رفتن به لینک)
          </label>
          <div class="cn-child-cat-picker" style="margin-top:8px;${showProducts ? '' : 'display:none;'}">
            <input type="hidden" class="field-cn-child-cat-id" value="${catId}">
            <input type="hidden" class="field-cn-child-cat-name" value="${catName}">
            <div class="cn-child-cat-selected" style="margin-bottom:6px;">${selectedChip}</div>
            <input type="text" class="field-cn-child-cat-search" autocomplete="off" placeholder="🔍 جستجوی دسته‌بندی محصول..." style="width:100%;padding:8px 10px;border:1px solid #10b981;border-radius:6px;font-size:12px;background:#fff;color:#111;">
            <div class="cn-child-cat-results" style="position:relative;z-index:1000;"></div>
          </div>
        </div>`;
    };

    // خواندن دیتای یک زیرشاخه از DOM (استفاده مشترک در save و rebuild)
    window.__cnReadChild = function ($ch) {
      return {
        name: $ch.find('.field-cn-child-name').val(),
        link: $ch.find('.field-cn-child-link').val(),
        show_products: $ch.find('.field-cn-child-show-products').is(':checked') ? 'yes' : 'no',
        product_cat_id: $ch.find('.field-cn-child-cat-id').val() || '',
        product_cat_name: $ch.find('.field-cn-child-cat-name').val() || ''
      };
    };

    // رندر یک دسته سطح ۱ (تصویر + نام) همراه با زیرشاخه‌هایش
    window.__cnRenderCat = function (cat, ci) {
      cat = cat || {};
      const children = Array.isArray(cat.children) ? cat.children : [];
      const childrenHtml = children.map((ch, chi) => window.__cnRenderChild(ch, ci, chi)).join('');
      return `
        <div class="cn-cat-item" data-idx="${ci}" style="background:rgba(255,255,255,0.06);padding:14px;border-radius:10px;border:1px solid #10b981;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
            <div style="font-size:13px;font-weight:700;color:#6ee7b7;">📁 دسته سطح ۱ — شماره ${ci + 1}</div>
            <button type="button" class="button cn-remove-cat" style="background:#ef4444;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px;padding:5px 10px;">🗑️ حذف دسته</button>
          </div>
          <div style="display:grid;grid-template-columns:1fr 220px;gap:12px;align-items:start;">
            <div>
              <label style="display:block;margin-bottom:6px;font-size:12px;color:#a7f3d0;">نام دسته (نمایش روی تب):</label>
              <input type="text" class="field-cn-cat-name" value="${(cat.name || '').replace(/"/g, '&quot;')}" placeholder="مثلاً: لبنیات" style="width:100%;padding:8px 10px;border:1px solid #10b981;border-radius:6px;font-size:13px;background:#022c22;color:#ecfdf5;">
            </div>
            <div>
              <label style="display:block;margin-bottom:6px;font-size:12px;color:#a7f3d0;">تصویر دسته:</label>
              <input type="text" class="field-cn-cat-image" value="${(cat.image || '').replace(/"/g, '&quot;')}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #10b981;border-radius:6px;font-size:12px;background:#022c22;color:#ecfdf5;margin-bottom:6px;">
              <button type="button" class="button button-upload-cn" style="font-size:11px;">📷 انتخاب تصویر</button>
              ${cat.image ? `<img src="${cat.image}" style="max-width:100%;max-height:60px;margin-top:6px;border-radius:6px;display:block;">` : ''}
            </div>
          </div>
          <div style="margin-top:12px;padding-top:10px;border-top:1px dashed rgba(255,255,255,0.15);">
            <div style="font-size:12px;font-weight:600;color:#a7f3d0;margin-bottom:8px;">زیرشاخه‌های سطح ۲ (نام + لینک):</div>
            <div class="cn-children-container" style="display:flex;flex-direction:column;gap:8px;">${childrenHtml}</div>
            <button type="button" class="button cn-add-child" style="margin-top:8px;background:rgba(255,255,255,0.12);color:#ecfdf5;border:1px solid #34d399;border-radius:6px;cursor:pointer;font-size:12px;padding:6px 12px;">➕ افزودن زیرشاخه</button>
          </div>
        </div>`;
    };

    // رندر یک ردیف زیرمنوی navbar (نام + لینک)
    window.__navRenderChild = function (child) {
      child = child || {};
      return `
        <div class="nav-child" style="display:flex;gap:6px;align-items:center;background:#f6f7f7;padding:6px;border-radius:6px;margin-bottom:6px;">
          <span style="color:#9aa3ad;font-size:14px;">↳</span>
          <input type="text" class="nav-child-name" placeholder="نام زیرمنو" value="${(child.name || '').replace(/"/g, '&quot;')}" style="flex:1;padding:6px 8px;border:1px solid #ccd0d4;border-radius:4px;font-size:13px;">
          <input type="text" class="nav-child-link" placeholder="لینک" value="${(child.link || '').replace(/"/g, '&quot;')}" style="flex:1;padding:6px 8px;border:1px solid #ccd0d4;border-radius:4px;font-size:13px;direction:ltr;">
          <label style="display:inline-flex;align-items:center;gap:4px;font-size:11px;cursor:pointer;white-space:nowrap;color:#50575e;" title="باز شدن در تب جدید"><input type="checkbox" class="nav-child-new-tab" ${child.new_tab === 'yes' ? 'checked' : ''} style="width:15px;height:15px;">تب جدید</label>
          <button type="button" class="button nav-remove-child" title="حذف زیرمنو" style="color:#d63638;border-color:#d63638;line-height:1;padding:2px 9px;">×</button>
        </div>`;
    };

    // ============================================================
    // فریم‌ورک ویجت‌های لندینگ مهندسان (eng_*) — schema-driven
    // هر ویجت یک schema دارد: فیلدهای اسکالر + لیست‌های تکرارشونده (با امکان زیرلیست)
    // ============================================================
    window.ENG_SCHEMAS = {
      eng_hero: {
        icon: '🏗️', name: 'هیرو مهندسی', color: '135deg,#0b1f3a,#17365e',
        fields: [
          { k: 'eh_kicker', t: 'text', label: 'کیکر (بالای عنوان)', def: 'بیش از ۲۸ سال تجربه در صنعت ساخت' },
          { k: 'eh_title', t: 'text', label: 'عنوان', def: 'می‌سازیم، آن‌چه را که' },
          { k: 'eh_title_highlight', t: 'text', label: 'بخش هایلایت عنوان', def: 'آینده به آن تکیه می‌کند' },
          { k: 'eh_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'گروه فنی و مهندسی «مهندسان» با تکیه بر دانش روز، پروژه‌های عمرانی را از طراحی تا بهره‌برداری اجرا می‌کند.' },
          { k: 'eh_btn1_text', t: 'text', label: 'دکمه ۱ متن', def: 'مشاهده پروژه‌ها' },
          { k: 'eh_btn1_link', t: 'text', label: 'دکمه ۱ لینک', def: '#projects' },
          { k: 'eh_btn2_text', t: 'text', label: 'دکمه ۲ متن', def: 'آشنایی با خدمات' },
          { k: 'eh_btn2_link', t: 'text', label: 'دکمه ۲ لینک', def: '#services' },
          { k: 'eh_bp_title', t: 'text', label: 'عنوان کارت پروژه', def: 'پروژه برج اداری آرتمیس' },
          { k: 'eh_bp_badge', t: 'text', label: 'برچسب کارت', def: 'در حال اجرا' },
          { k: 'eh_image', t: 'image', label: 'تصویر کارت (اختیاری)', def: '' },
          { k: 'eh_bp_foot_left', t: 'text', label: 'پاورقی کارت (راست)', def: 'پیشرفت کل: ٪۷۴' },
          { k: 'eh_bp_foot_right', t: 'text', label: 'پاورقی کارت (چپ)', def: 'تحویل: تابستان ۱۴۰۵' },
          { k: 'eh_chip1', t: 'text', label: 'چیپ شناور ۱', def: 'گواهی صلاحیت رتبه ۱' },
          { k: 'eh_chip2', t: 'text', label: 'چیپ شناور ۲', def: 'تحویل به‌موقع، تضمین‌شده' },
          { k: 'eh_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'eh_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'eh_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' },
          { k: 'eh_text_light', t: 'color', label: 'رنگ متن روشن (روی پس‌زمینه تیره)', def: '' },
          { k: 'eh_text_dark', t: 'color', label: 'رنگ متن کم‌رنگ (زیرعنوان)', def: '' },
          { k: 'eh_title_grad_from', t: 'color', label: 'گرادیانت عنوان: رنگ شروع', def: '' },
          { k: 'eh_title_grad_to', t: 'color', label: 'گرادیانت عنوان: رنگ پایان', def: '' }
        ],
        lists: [
          { k: 'eh_trust', label: 'آمار اعتماد', item: [
            { k: 'num', t: 'text', label: 'عدد' }, { k: 'label', t: 'text', label: 'برچسب' }
          ], def: [
            { num: '۲۸', label: 'سال سابقه اجرایی' }, { num: '۱۴۰', label: 'پروژه تکمیل‌شده' }, { num: '۹۸٪', label: 'رضایت کارفرما' }
          ] },
          { k: 'eh_bp_rows', label: 'ردیف‌های پیشرفت کارت', item: [
            { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' }, { k: 'title', t: 'text', label: 'عنوان' }, { k: 'percent', t: 'text', label: 'درصد (مثل 92%)' }
          ], def: [
            { icon: '🏗️', title: 'اسکلت و سازه', percent: '92%' }, { icon: '⚡', title: 'تأسیسات برقی و مکانیکی', percent: '71%' }, { icon: '🎨', title: 'نازک‌کاری و نما', percent: '48%' }
          ] }
        ]
      },
      eng_clients: {
        icon: '🤝', name: 'نوار مشتریان (مارکی)', color: '135deg,#102a4c,#1f4475',
        fields: [
          { k: 'ecl_label', t: 'text', label: 'برچسب بالا', def: 'افتخار همکاری با سازمان‌ها و شرکت‌های پیشرو' },
          { k: 'ecl_speed', t: 'number', label: 'سرعت (ثانیه)', def: 36, min: 8, max: 120 },
          { k: 'ecl_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'ecl_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'ecl_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'ecl_logos', label: 'لوگوها', item: [
            { k: 'name', t: 'text', label: 'نام' }, { k: 'image', t: 'image', label: 'تصویر لوگو (اختیاری)' }, { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG — اگر تصویر نباشد)' }
          ], def: [
            { name: 'هلدینگ عمران پارس', icon: '🏢' }, { name: 'بانک آینده‌سازان', icon: '🏦' }, { name: 'شهرداری منطقه ۲۲', icon: '🏛️' },
            { name: 'پتروشیمی خلیج فارس', icon: '⚗️' }, { name: 'گروه صنعتی البرز', icon: '🏭' }, { name: 'فولاد کویر یزد', icon: '🔩' }
          ] }
        ]
      },
      eng_services: {
        icon: '🛠️', name: 'خدمات (تب‌دار)', color: '135deg,#17365e,#1f4475',
        fields: [
          { k: 'esv_kicker', t: 'text', label: 'کیکر', def: 'خدمات ما' },
          { k: 'esv_title', t: 'text', label: 'عنوان', def: 'راهکار کامل برای هر پروژه' },
          { k: 'esv_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'از مطالعات اولیه و طراحی تا اجرا، نظارت و بهره‌برداری — همه زیر یک سقف.' },
          { k: 'esv_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'esv_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'esv_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'esv_tabs', label: 'تب‌ها', item: [
            { k: 'title', t: 'text', label: 'عنوان تب' },
            { k: 'cards', sub: true, label: 'کارت‌های خدمت', item: [
              { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' },
              { k: 'title', t: 'text', label: 'عنوان' },
              { k: 'desc', t: 'textarea', label: 'توضیح' },
              { k: 'linkText', t: 'text', label: 'متن لینک' },
              { k: 'link', t: 'text', label: 'لینک' }
            ] }
          ], def: [
            { title: 'ساختمانی و ابنیه', cards: [
              { icon: '🏢', title: 'ساختمان‌های مسکونی', desc: 'طراحی و اجرای مجتمع‌های مسکونی و برج‌های بلندمرتبه.', linkText: 'اطلاعات بیشتر', link: '#contact' },
              { icon: '🏬', title: 'برج‌های اداری و تجاری', desc: 'ساخت مراکز تجاری و اداری مدرن با بهره‌وری انرژی.', linkText: 'اطلاعات بیشتر', link: '#contact' },
              { icon: '🧱', title: 'بازسازی و مقاوم‌سازی', desc: 'بهسازی لرزه‌ای و بازسازی کامل ساختمان‌های موجود.', linkText: 'اطلاعات بیشتر', link: '#contact' }
            ] },
            { title: 'زیرساخت و راه', cards: [
              { icon: '🛣️', title: 'راه و بزرگراه', desc: 'احداث آزادراه، بزرگراه و راه‌های اصلی.', linkText: 'اطلاعات بیشتر', link: '#contact' },
              { icon: '🌉', title: 'پل و تقاطع غیرهم‌سطح', desc: 'طراحی و اجرای پل‌های بزرگ و سازه‌های خاص.', linkText: 'اطلاعات بیشتر', link: '#contact' },
              { icon: '🚇', title: 'تونل و مترو', desc: 'حفاری و اجرای تونل‌های شهری و بین‌شهری.', linkText: 'اطلاعات بیشتر', link: '#contact' }
            ] }
          ] }
        ]
      },
      eng_stats: {
        icon: '📊', name: 'نوار آمار', color: '135deg,#07142a,#0b1f3a',
        fields: [
          { k: 'est_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'est_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'est_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'est_items', label: 'آیتم‌های آمار', item: [
            { k: 'num', t: 'text', label: 'عدد' }, { k: 'suffix', t: 'text', label: 'پسوند (مثل +)' }, { k: 'label', t: 'text', label: 'برچسب' }
          ], def: [
            { num: '۲۸', suffix: '+', label: 'سال تجربه' }, { num: '۱۴۰', suffix: '+', label: 'پروژه تکمیل‌شده' },
            { num: '۸۵۰', suffix: '+', label: 'نیروی متخصص' }, { num: '۱۲', suffix: '', label: 'استان محل فعالیت' }
          ] }
        ]
      },
      eng_projects: {
        icon: '🏗️', name: 'پروژه‌ها (فیلتردار)', color: '135deg,#17365e,#1f4475',
        fields: [
          { k: 'epr_kicker', t: 'text', label: 'کیکر', def: 'نمونه‌کارها' },
          { k: 'epr_title', t: 'text', label: 'عنوان', def: 'پروژه‌های شاخص ما' },
          { k: 'epr_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'گزیده‌ای از پروژه‌هایی که با افتخار اجرا و تحویل داده‌ایم.' },
          { k: 'epr_meta1_icon', t: 'textarea', label: 'آیکون مشخصه ۱ (emoji یا SVG)', def: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg>' },
          { k: 'epr_meta2_icon', t: 'textarea', label: 'آیکون مشخصه ۲ (emoji یا SVG)', def: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21V7l9-4 9 4v14M3 21h18"/></svg>' },
          { k: 'epr_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'epr_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'epr_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'epr_filters', label: 'فیلترها (کلید لاتین + برچسب)', item: [
            { k: 'key', t: 'text', label: 'کلید (لاتین)' }, { k: 'label', t: 'text', label: 'برچسب' }
          ], def: [
            { key: 'residential', label: 'مسکونی' }, { key: 'commercial', label: 'تجاری و اداری' }, { key: 'infra', label: 'زیرساخت' }, { key: 'industrial', label: 'صنعتی' }
          ] },
          { k: 'epr_projects', label: 'پروژه‌ها', item: [
            { k: 'image', t: 'image', label: 'تصویر' },
            { k: 'tag', t: 'text', label: 'برچسب نمایشی' },
            { k: 'cat', t: 'text', label: 'کلید فیلتر (لاتین)' },
            { k: 'title', t: 'text', label: 'عنوان' },
            { k: 'meta1', t: 'text', label: 'مشخصه ۱ (موقعیت)' },
            { k: 'meta2', t: 'text', label: 'مشخصه ۲' }
          ], def: [
            { image: '', tag: 'تجاری و اداری', cat: 'commercial', title: 'برج اداری آرتمیس', meta1: 'تهران، ونک', meta2: '۲۸ طبقه' },
            { image: '', tag: 'مسکونی', cat: 'residential', title: 'مجتمع مسکونی باران', meta1: 'اصفهان', meta2: '۳۲۰ واحد' },
            { image: '', tag: 'زیرساخت', cat: 'infra', title: 'پل کابلی خلیج', meta1: 'بندرعباس', meta2: '۱.۲ کیلومتر' }
          ] }
        ]
      },
      eng_timeline: {
        icon: '📅', name: 'خط زمانی (تاریخچه)', color: '135deg,#07142a,#102a4c',
        fields: [
          { k: 'etl_kicker', t: 'text', label: 'کیکر', def: 'داستان ما' },
          { k: 'etl_title', t: 'text', label: 'عنوان', def: 'سه دهه ساختن و آموختن' },
          { k: 'etl_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'از یک دفتر کوچک مهندسی تا یکی از پیمانکاران برتر کشور.' },
          { k: 'etl_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'etl_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'etl_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'etl_items', label: 'رویدادها', item: [
            { k: 'year', t: 'text', label: 'سال' }, { k: 'title', t: 'text', label: 'عنوان' }, { k: 'desc', t: 'textarea', label: 'توضیح' }
          ], def: [
            { year: '۱۳۷۵', title: 'تأسیس شرکت', desc: 'آغاز فعالیت با تیمی ۵ نفره در تهران.' },
            { year: '۱۳۸۲', title: 'نخستین پروژه ملی', desc: 'برنده مناقصه ساخت مجتمع ۱۲۰ واحدی.' },
            { year: '۱۳۹۰', title: 'کسب رتبه ۱ پیمانکاری', desc: 'دریافت گواهی صلاحیت رتبه یک ابنیه.' },
            { year: 'امروز', title: 'به‌سوی آینده', desc: 'بیش از ۸۵۰ نیروی متخصص و ۱۴۰ پروژه تکمیل‌شده.' }
          ] }
        ]
      },
      eng_certs: {
        icon: '🏅', name: 'گواهینامه‌ها', color: '135deg,#1f4475,#17365e',
        fields: [
          { k: 'ecr_kicker', t: 'text', label: 'کیکر', def: 'اعتبار ما' },
          { k: 'ecr_title', t: 'text', label: 'عنوان', def: 'گواهینامه‌ها و افتخارات' },
          { k: 'ecr_icon_color', t: 'color', label: 'رنگ آیکون وسط مدال', def: '#07142A' },
          { k: 'ecr_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'ecr_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'ecr_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'ecr_items', label: 'گواهینامه‌ها', item: [
            { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' }, { k: 'title', t: 'text', label: 'عنوان' }, { k: 'desc', t: 'textarea', label: 'توضیح' }
          ], def: [
            { icon: '🥇', title: 'گواهی صلاحیت رتبه ۱', desc: 'پایه یک ابنیه و ساختمان از سازمان برنامه و بودجه.' },
            { icon: '✅', title: 'ISO 9001:2015', desc: 'سیستم مدیریت کیفیت در طراحی و اجرا.' },
            { icon: '🛡️', title: 'ISO 45001', desc: 'مدیریت ایمنی و بهداشت شغلی (HSE).' },
            { icon: '⭐', title: 'پیمانکار برتر سال ۱۴۰۲', desc: 'منتخب جشنواره ملی صنعت ساختمان.' }
          ] }
        ]
      },
      eng_team: {
        icon: '👷', name: 'تیم و متخصصان', color: '135deg,#17365e,#1f4475',
        fields: [
          { k: 'etm_kicker', t: 'text', label: 'کیکر', def: 'تیم ما' },
          { k: 'etm_title', t: 'text', label: 'عنوان', def: 'مدیران و متخصصان' },
          { k: 'etm_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'تیمی که هر پروژه را مثل پروژهٔ خودش جدی می‌گیرد.' },
          { k: 'etm_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'etm_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'etm_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'etm_members', label: 'اعضای تیم', item: [
            { k: 'image', t: 'image', label: 'عکس' }, { k: 'name', t: 'text', label: 'نام' }, { k: 'role', t: 'text', label: 'سمت' }, { k: 'bio', t: 'textarea', label: 'بیو کوتاه' }
          ], def: [
            { image: '', name: 'مهندس امیر رضایی', role: 'مدیرعامل و عضو هیئت‌مدیره', bio: 'دکترای عمران؛ ۲۵ سال سابقه مدیریت پروژه.' },
            { image: '', name: 'مهندس سارا محمدی', role: 'معاون فنی و مهندسی', bio: 'کارشناس ارشد سازه؛ متخصص بلندمرتبه.' },
            { image: '', name: 'مهندس حسین کریمی', role: 'مدیر پروژه‌های زیرساخت', bio: '۱۸ سال تجربه در پل، تونل و راه.' },
            { image: '', name: 'مهندس نگار احمدی', role: 'مدیر کنترل پروژه', bio: 'متخصص PMBOK؛ تحویل به‌موقع ۶۰+ پروژه.' }
          ] }
        ]
      },
      eng_testimonials: {
        icon: '💬', name: 'نظرات مشتریان', color: '135deg,#07142a,#0b1f3a',
        fields: [
          { k: 'ets_kicker', t: 'text', label: 'کیکر', def: 'اعتماد مشتریان' },
          { k: 'ets_title', t: 'text', label: 'عنوان', def: 'کارفرمایان ما چه می‌گویند؟' },
          { k: 'ets_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'ets_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'ets_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'ets_items', label: 'نظرات', item: [
            { k: 'text', t: 'textarea', label: 'متن نظر' }, { k: 'avatar', t: 'text', label: 'حروف آواتار' }, { k: 'name', t: 'text', label: 'نام' }, { k: 'org', t: 'text', label: 'سازمان' }
          ], def: [
            { text: 'پروژه برج اداری ما را سه ماه زودتر از برنامه و بدون افت کیفیت تحویل دادند.', avatar: 'ع.ن', name: 'علی نوری', org: 'مدیرعامل هلدینگ عمران پارس' },
            { text: 'در پروژه مقاوم‌سازی بیمارستان، بدون حتی یک روز توقف، کار را به پایان رساندند.', avatar: 'م.ص', name: 'مریم صادقی', org: 'معاون عمرانی دانشگاه علوم پزشکی' },
            { text: 'قرارداد شفاف، صورت‌وضعیت منظم و کیفیتی که از روز اول قول داده بودند.', avatar: 'ر.ک', name: 'رضا کاظمی', org: 'مدیر طرح گروه صنعتی البرز' }
          ] }
        ]
      },
      eng_blog: {
        icon: '📰', name: 'بلاگ و اخبار (ثابت)', color: '135deg,#1f4475,#17365e',
        fields: [
          { k: 'ebl_kicker', t: 'text', label: 'کیکر', def: 'بلاگ و اخبار' },
          { k: 'ebl_title', t: 'text', label: 'عنوان', def: 'تازه‌های مهندسان' },
          { k: 'ebl_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'ebl_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'ebl_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'ebl_posts', label: 'پست‌ها', item: [
            { k: 'image', t: 'image', label: 'تصویر' }, { k: 'cat', t: 'text', label: 'دسته' }, { k: 'date', t: 'text', label: 'تاریخ' },
            { k: 'title', t: 'text', label: 'عنوان' }, { k: 'desc', t: 'textarea', label: 'خلاصه' }, { k: 'linkText', t: 'text', label: 'متن لینک' }, { k: 'link', t: 'text', label: 'لینک' }
          ], def: [
            { image: '', cat: 'اخبار شرکت', date: '۱۸ خرداد ۱۴۰۵', title: 'آغاز عملیات اجرایی فاز دوم برج آرتمیس', desc: 'با اتمام فاز نخست، فاز دوم شامل ۱۴ طبقه اداری آغاز شد.', linkText: 'ادامه مطلب', link: '#' },
            { image: '', cat: 'مقاله فنی', date: '۲ خرداد ۱۴۰۵', title: 'بتن خودتراکم؛ راهکار سازه‌های پیچیده', desc: 'تجربه ما در استفاده از بتن خودتراکم در ستون‌های پل خلیج.', linkText: 'ادامه مطلب', link: '#' },
            { image: '', cat: 'گزارش', date: '۲۰ اردیبهشت ۱۴۰۵', title: 'گزارش سالانه ایمنی کارگاه‌ها منتشر شد', desc: '۱٬۲۰۰ روز کاری بدون حادثه؛ خلاصه دستاوردهای HSE.', linkText: 'ادامه مطلب', link: '#' }
          ] }
        ]
      },
      eng_contact: {
        icon: '📞', name: 'تماس با ما', color: '135deg,#102a4c,#17365e',
        fields: [
          { k: 'ect_kicker', t: 'text', label: 'کیکر', def: 'تماس با ما' },
          { k: 'ect_title', t: 'text', label: 'عنوان', def: 'پروژه بعدی‌تان را با ما شروع کنید' },
          { k: 'ect_subtitle', t: 'textarea', label: 'زیرعنوان', def: 'فرم زیر را پر کنید؛ کارشناسان ما تا ۲۴ ساعت با شما تماس می‌گیرند.' },
          { k: 'ect_form_title', t: 'text', label: 'عنوان فرم', def: 'درخواست مشاوره رایگان' },
          { k: 'ect_form_desc', t: 'text', label: 'توضیح فرم', def: 'مشخصات پروژه‌تان را برای ما بنویسید.' },
          { k: 'ect_submit_text', t: 'text', label: 'متن دکمه ارسال', def: 'ارسال درخواست' },
          { k: 'ect_map_lat', t: 'text', label: 'عرض جغرافیایی نقشه (Latitude)', def: '35.7546' },
          { k: 'ect_map_lng', t: 'text', label: 'طول جغرافیایی نقشه (Longitude)', def: '51.4100' },
          { k: 'ect_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'ect_secondary_color', t: 'color', label: 'رنگ ثانویه (طلایی)', def: '' },
          { k: 'ect_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'ect_project_types', label: 'گزینه‌های نوع پروژه (فقط نام)', item: [
            { k: 'name', t: 'text', label: 'نام گزینه' }
          ], simpleKey: 'name', def: [
            { name: 'ساختمانی و ابنیه' }, { name: 'زیرساخت و راه' }, { name: 'صنعتی و تأسیسات' }, { name: 'مشاوره و نظارت' }
          ] },
          { k: 'ect_info', label: 'اطلاعات تماس', item: [
            { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' }, { k: 'label', t: 'text', label: 'برچسب' }, { k: 'value', t: 'text', label: 'مقدار' }, { k: 'ltr', t: 'checkbox', label: 'چپ‌چین (LTR)' }
          ], def: [
            { icon: '📞', label: 'تلفن دفتر مرکزی', value: '021-88 77 66 55', ltr: 'yes' },
            { icon: '✉️', label: 'ایمیل', value: 'info@mohandesan.ir', ltr: 'yes' },
            { icon: '📍', label: 'نشانی', value: 'تهران، ونک، خیابان ملاصدرا، پلاک ۱۲', ltr: 'no' },
            { icon: '🕐', label: 'ساعت کاری', value: 'شنبه تا چهارشنبه، ۸ تا ۱۷', ltr: 'no' }
          ] }
        ]
      },

      // ════════ ویجت‌های گروه معماری پلان (ری‌دیزاین) — prefix: pln_ ════════
      pln_hero: {
        icon: '🏛️', name: 'پلان: هیرو معماری', color: '135deg,#16140f,#2c2823',
        fields: [
          { k: 'plh_badge', t: 'text', label: 'برچسب بالا', def: 'بیش از ۱۲ سال تجربه در طراحی و اجرا' },
          { k: 'plh_title', t: 'text', label: 'عنوان', def: 'خلق فضاهایی که' },
          { k: 'plh_title_highlight', t: 'text', label: 'کلمه هایلایت', def: 'زندگی' },
          { k: 'plh_title_after', t: 'text', label: 'ادامه عنوان', def: 'در آن جریان دارد' },
          { k: 'plh_lead', t: 'textarea', label: 'متن لید', def: 'گروه معماری پلان با تکیه بر دانش روز و تیمی متخصص، از ایده تا اجرا در کنار شماست تا رویای ساختمان ایده‌آل‌تان را به واقعیت تبدیل کنیم.' },
          { k: 'plh_cta_text', t: 'text', label: 'متن دکمه', def: 'مشاوره رایگان بگیرید' },
          { k: 'plh_cta_link', t: 'text', label: 'لینک دکمه', def: '#contact' },
          { k: 'plh_image', t: 'image', label: 'تصویر اصلی (ساختمان)', def: '' },
          { k: 'plh_image2', t: 'image', label: 'تصویر دوم (کوچک)', def: '' },
          { k: 'plh_badge_status', t: 'text', label: 'برچسب وضعیت روی تصویر', def: 'پروژه‌های در حال اجرا' },
          { k: 'plh_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plh_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plh_stats', label: 'آمار هیرو', item: [
            { k: 'num', t: 'text', label: 'عدد' }, { k: 'unit', t: 'text', label: 'واحد (مثل +)' }, { k: 'label', t: 'text', label: 'برچسب' }
          ], def: [
            { num: '۱۲', unit: '+', label: 'سال تجربه' }, { num: '۲۴۰', unit: '+', label: 'پروژه موفق' }, { num: '۹۸', unit: '٪', label: 'رضایت کارفرما' }
          ] }
        ]
      },
      pln_benefits: {
        icon: '✨', name: 'پلان: مزایا', color: '135deg,#211e18,#2c2823',
        fields: [
          { k: 'plb_eyebrow', t: 'text', label: 'eyebrow', def: 'چرا گروه معماری پلان؟' },
          { k: 'plb_title', t: 'text', label: 'عنوان', def: 'مزایای' },
          { k: 'plb_title_highlight', t: 'text', label: 'کلمه هایلایت', def: 'همکاری' },
          { k: 'plb_title_after', t: 'text', label: 'ادامه عنوان', def: 'با تیم ما' },
          { k: 'plb_watermark', t: 'text', label: 'واترمارک پس‌زمینه', def: 'مزایا' },
          { k: 'plb_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plb_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plb_cards', label: 'کارت‌های مزیت', item: [
            { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' }, { k: 'title', t: 'text', label: 'عنوان' }, { k: 'text', t: 'textarea', label: 'توضیح' }
          ], def: [
            { icon: '🎧', title: 'مشاوره و راهنمایی', text: 'از همان نخستین گام، کارشناسان ما با مشاوره تخصصی و رایگان، بهترین مسیر را پیش پای شما می‌گذارند.' },
            { icon: '🧭', title: 'طراحی اختصاصی', text: 'هر پروژه را متناسب با سبک زندگی، بودجه و سلیقه شما طراحی می‌کنیم؛ بدون نسخه‌های تکراری.' },
            { icon: '⚡', title: 'اجرای سریع و دقیق', text: 'تیم اجرایی منسجم ما، پروژه را در زمان مقرر و با بالاترین کیفیت ممکن به سرانجام می‌رساند.' }
          ] }
        ]
      },
      pln_testimonials: {
        icon: '🗣️', name: 'پلان: دیدگاه مشتریان (تیره)', color: '135deg,#16140f,#211e18',
        fields: [
          { k: 'plt_tag', t: 'text', label: 'تگ انگلیسی', def: 'Customer View' },
          { k: 'plt_title', t: 'text', label: 'عنوان', def: 'دیدگاه مشتریان' },
          { k: 'plt_subtitle', t: 'text', label: 'زیرعنوان', def: 'آنچه کارفرمایان درباره ما می‌گویند' },
          { k: 'plt_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plt_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plt_items', label: 'نظرات', item: [
            { k: 'name', t: 'text', label: 'نام' }, { k: 'role', t: 'text', label: 'سمت' },
            { k: 'highlight', t: 'text', label: 'جمله هایلایت' }, { k: 'quote', t: 'textarea', label: 'متن نظر' }
          ], def: [
            { name: 'آرمان میمندی‌نژاد', role: 'مدیریت زرین‌پال', highlight: 'کیفیت فراتر از انتظار', quote: 'خدمات شما فراتر از انتظار من بود. توجه به جزئیات و تعهد به کیفیت شما را از دیگران متمایز می‌کند.' },
            { name: 'سارا توکلی', role: 'بنیان‌گذار آرتین‌هوم', highlight: 'همراهی حرفه‌ای', quote: 'از همان جلسه اول تا تحویل پروژه، همراهی حرفه‌ای تیم را احساس کردیم و نتیجه عالی بود.' },
            { name: 'مهدی رستگار', role: 'مدیرعامل ساختین', highlight: 'تعهد به زمان', quote: 'پروژه دقیقاً سر وقت و مطابق برنامه تحویل شد؛ چیزی که در این صنعت کمیاب است.' },
            { name: 'نگار اسدی', role: 'معمار ارشد، استودیو نقش', highlight: 'طراحی خلاقانه', quote: 'ایده‌های طراحی تیم پلان واقعاً تازه و کاربردی بود و فضای پروژه را متحول کرد.' }
          ] }
        ]
      },
      pln_customers: {
        icon: '🏢', name: 'پلان: مشتریان (مارکی)', color: '135deg,#2c2823,#211e18',
        fields: [
          { k: 'plc_tag', t: 'text', label: 'تگ انگلیسی', def: 'Our Customers' },
          { k: 'plc_title', t: 'text', label: 'عنوان', def: 'مشتریان ما' },
          { k: 'plc_subtitle', t: 'text', label: 'زیرعنوان', def: 'برندهایی که به ما اعتماد کرده‌اند' },
          { k: 'plc_speed', t: 'number', label: 'سرعت (ثانیه)', def: 38, min: 10, max: 120 },
          { k: 'plc_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plc_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plc_logos', label: 'لوگوها', item: [
            { k: 'name', t: 'text', label: 'نام' }, { k: 'icon', t: 'textarea', label: 'آیکون/لوگو (emoji یا SVG)' }, { k: 'image', t: 'image', label: 'تصویر لوگو (اختیاری)' }
          ], def: [
            { name: 'زرین‌پال', icon: '💳', image: '' }, { name: 'آرتین‌هوم', icon: '🏠', image: '' }, { name: 'ساختین', icon: '🏗️', image: '' },
            { name: 'استودیو نقش', icon: '🎨', image: '' }, { name: 'گروه مانا', icon: '🏢', image: '' }, { name: 'پروژه آوا', icon: '🌿', image: '' },
            { name: 'سداد', icon: '🏦', image: '' }, { name: 'کوروش', icon: '⚙️', image: '' }
          ] }
        ]
      },
      pln_history: {
        icon: '📜', name: 'پلان: تاریخچه (تایم‌لاین)', color: '135deg,#211e18,#2c2823',
        fields: [
          { k: 'plhi_tag', t: 'text', label: 'تگ انگلیسی', def: 'History' },
          { k: 'plhi_title', t: 'text', label: 'عنوان', def: 'تاریخچه شرکت' },
          { k: 'plhi_subtitle', t: 'text', label: 'زیرعنوان', def: 'مسیری که با اعتماد شما ساخته شد' },
          { k: 'plhi_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plhi_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plhi_eras', label: 'دوره‌ها', item: [
            { k: 'year', t: 'text', label: 'سال' }, { k: 'title', t: 'text', label: 'عنوان' }, { k: 'sub', t: 'text', label: 'زیرعنوان' },
            { k: 'text', t: 'textarea', label: 'توضیح' }, { k: 'image', t: 'image', label: 'تصویر (اختیاری)' }
          ], def: [
            { year: '۱۳۹۵', title: 'تاسیس شرکت', sub: 'شروع یک حرکت جسورانه با ۲ دوست', text: 'کار را در دفتری کوچک و با باوری بزرگ آغاز کردیم؛ تمرکز ما از روز نخست بر کیفیت طراحی و تعهد به زمان بود.', image: '' },
            { year: '۱۳۹۶', title: 'نخستین پروژه‌ها', sub: 'اعتماد اولین کارفرمایان', text: 'با تحویل موفق نخستین پروژه‌های مسکونی، نام پلان به‌عنوان تیمی دقیق و خوش‌قول شناخته شد.', image: '' },
            { year: '۱۴۰۰', title: 'گسترش تیم', sub: 'شکل‌گیری دپارتمان‌های تخصصی', text: 'تیم معماری، اجرا و نظارت تفکیک شد و توان اجرای هم‌زمان چند پروژه بزرگ را به دست آوردیم.', image: '' },
            { year: '۱۴۰۱', title: 'ورود به پروژه‌های صنعتی', sub: 'مقیاسی تازه از مسئولیت', text: 'نخستین قراردادهای صنعتی و زیرساختی را امضا کردیم؛ تجربه‌ای که استانداردهای ما را متحول کرد.', image: '' },
            { year: '۱۴۰۴', title: 'حضور ملی', sub: 'پلان در نقشه‌ی کشور', text: 'امروز با ده‌ها پروژه موفق در شهرهای مختلف، پلان به نامی قابل‌اعتماد تبدیل شده و همچنان در حال رشد است.', image: '' }
          ] }
        ]
      },
      pln_portfolio: {
        icon: '🗂️', name: 'پلان: نمونه‌کارها', color: '135deg,#2c2823,#16140f',
        fields: [
          { k: 'plp_tag', t: 'text', label: 'تگ انگلیسی', def: 'Portfolio' },
          { k: 'plp_title', t: 'text', label: 'عنوان', def: 'نمونه‌کارهای ما' },
          { k: 'plp_subtitle', t: 'text', label: 'زیرعنوان', def: 'گزیده‌ای از پروژه‌های شاخص' },
          { k: 'plp_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plp_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: [
          { k: 'plp_tabs', label: 'دسته‌ها', item: [
            { k: 'title', t: 'text', label: 'عنوان دسته' }, { k: 'icon', t: 'textarea', label: 'آیکون (emoji یا SVG)' },
            { k: 'projects', sub: true, label: 'پروژه‌ها', item: [
              { k: 'image', t: 'image', label: 'تصویر' }, { k: 'title', t: 'text', label: 'عنوان' },
              { k: 'loc', t: 'text', label: 'موقعیت' }, { k: 'year', t: 'text', label: 'سال' }, { k: 'cat', t: 'text', label: 'دسته نمایشی' },
              { k: 'link', t: 'text', label: 'لینک پروژه (اختیاری)' }
            ] }
          ], def: [
            { title: 'سازه‌های مسکونی', icon: '🏠', projects: [
              { image: '', title: 'مجتمع مسکونی باغ‌ایرانی', loc: 'شیراز', year: '۱۴۰۳', cat: 'مسکونی' },
              { image: '', title: 'برج دوقلوی نیلوفر', loc: 'تهران', year: '۱۴۰۴', cat: 'مسکونی' },
              { image: '', title: 'خانه ویلایی دریاکنار', loc: 'بابلسر', year: '۱۴۰۱', cat: 'مسکونی' }
            ] },
            { title: 'سازه‌های تجاری', icon: '🏢', projects: [
              { image: '', title: 'مرکز تجاری اطلس', loc: 'تهران', year: '۱۴۰۳', cat: 'تجاری' },
              { image: '', title: 'هتل پنج‌ستاره ساحل', loc: 'کیش', year: '۱۴۰۲', cat: 'تجاری' },
              { image: '', title: 'کارخانه فولاد کوروش', loc: 'اهواز', year: '۱۴۰۱', cat: 'صنعتی' }
            ] }
          ] }
        ]
      },
      pln_cta: {
        icon: '🎯', name: 'پلان: فراخوان (CTA)', color: '135deg,#16140f,#211e18',
        fields: [
          { k: 'plcta_eyebrow', t: 'text', label: 'eyebrow (بالای عنوان)', def: 'آماده‌ی شروع هستید؟' },
          { k: 'plcta_title', t: 'text', label: 'عنوان (خط اول)', def: 'بیایید' },
          { k: 'plcta_title_highlight', t: 'text', label: 'کلمه هایلایت', def: 'رویای ساختمان' },
          { k: 'plcta_title_after', t: 'textarea', label: 'ادامه عنوان', def: 'شما را به واقعیت تبدیل کنیم' },
          { k: 'plcta_btn_text', t: 'text', label: 'متن دکمه', def: 'مشاوره رایگان بگیرید' },
          { k: 'plcta_btn_link', t: 'text', label: 'لینک دکمه', def: '#contact' },
          { k: 'plcta_accent_color', t: 'color', label: 'رنگ تاکیدی (اختیاری)', def: '' },
          { k: 'plcta_dark_color', t: 'color', label: 'رنگ تیره (اختیاری)', def: '' }
        ],
        lists: []
      }
    };

    // ─── ابزارهای داخلی فریم‌ورک ───
    window.__engEsc = function (v) { return (v == null ? '' : String(v)).replace(/"/g, '&quot;'); };

    // رندر یک input بر اساس نوع فیلد. cls: کلاس مبنا (eng-f | eng-rf | eng-srf)
    window.__engInput = function (cls, f, val) {
      const v = window.__engEsc(val == null ? (f.def != null ? f.def : '') : val);
      const base = 'width:100%;padding:7px 10px;border:1px solid #94a3b8;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;';
      const dk = 'data-k="' + f.k + '"';
      if (f.t === 'textarea') return `<textarea class="${cls}" ${dk} placeholder="${window.__engEsc(f.label)}" style="${base}min-height:54px;font-family:monospace;resize:vertical;">${v}</textarea>`;
      if (f.t === 'color') return `<input type="color" class="${cls}" ${dk} value="${v || '#000000'}" style="width:100%;height:34px;padding:2px;border:1px solid #94a3b8;border-radius:6px;background:#0f172a;cursor:pointer;">`;
      if (f.t === 'number') return `<input type="number" class="${cls}" ${dk} value="${v}" ${f.min != null ? 'min=' + f.min : ''} ${f.max != null ? 'max=' + f.max : ''} style="${base}">`;
      if (f.t === 'checkbox') return `<label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#cbd5e1;cursor:pointer;"><input type="checkbox" class="${cls}" ${dk} ${(v === 'yes' || v === true) ? 'checked' : ''} style="width:16px;height:16px;accent-color:#38bdf8;"> ${window.__engEsc(f.label)}</label>`;
      if (f.t === 'image') return `<input type="text" class="${cls}" ${dk} value="${v}" placeholder="آدرس تصویر" style="${base}margin-bottom:5px;"><button type="button" class="button eng-upload" style="font-size:11px;">📷 انتخاب</button>${v ? `<img src="${v}" style="max-width:100%;max-height:48px;margin-top:5px;border-radius:4px;display:block;">` : ''}`;
      return `<input type="text" class="${cls}" ${dk} value="${v}" placeholder="${window.__engEsc(f.label)}" style="${base}">`;
    };

    // رندر یک فیلد با لیبل
    window.__engField = function (cls, f, val) {
      if (f.t === 'checkbox') return `<div style="padding:6px 0;">${window.__engInput(cls, f, val)}</div>`;
      return `<div><label style="display:block;margin-bottom:4px;font-size:11px;color:#cbd5e1;">${window.__engEsc(f.label)}</label>${window.__engInput(cls, f, val)}</div>`;
    };

    // رندر یک سطر از لیست (با پشتیبانی از زیرلیست)
    window.__engRenderRow = function (list, row, ri) {
      row = row || {};
      let fieldsHtml = '';
      let subHtml = '';
      list.item.forEach(f => {
        if (f.sub) {
          const subrows = Array.isArray(row[f.k]) ? row[f.k] : [];
          const inner = subrows.map((sr, si) => window.__engRenderSubRow(f, sr, si)).join('');
          subHtml += `<div style="margin-top:8px;padding-top:8px;border-top:1px dashed rgba(255,255,255,0.15);">
            <div style="font-size:11px;font-weight:700;color:#a7f3d0;margin-bottom:6px;">${window.__engEsc(f.label)}:</div>
            <div class="eng-sublist" data-sub-key="${f.k}" style="display:flex;flex-direction:column;gap:8px;">${inner}</div>
            <button type="button" class="button eng-add-subrow" data-sub-key="${f.k}" style="margin-top:6px;font-size:11px;background:rgba(255,255,255,0.12);color:#ecfdf5;border:1px solid #34d399;border-radius:6px;padding:5px 10px;">➕ افزودن</button>
          </div>`;
        } else {
          fieldsHtml += window.__engField('eng-rf', f, row[f.k]);
        }
      });
      return `<div class="eng-row" data-idx="${ri}" style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.18);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
          <span style="font-size:11px;font-weight:700;color:#cbd5e1;">${window.__engEsc(list.label)} ${ri + 1}</span>
          <button type="button" class="button eng-remove-row" style="background:#ef4444;color:#fff;border:none;border-radius:6px;font-size:11px;padding:4px 10px;cursor:pointer;">🗑️ حذف</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;align-items:start;">${fieldsHtml}</div>
        ${subHtml}
      </div>`;
    };

    window.__engRenderSubRow = function (subField, sr, si) {
      sr = sr || {};
      const fieldsHtml = subField.item.map(f => window.__engField('eng-srf', f, sr[f.k])).join('');
      return `<div class="eng-subrow" data-idx="${si}" style="background:rgba(0,0,0,0.18);padding:8px;border-radius:6px;border:1px solid rgba(255,255,255,0.12);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-size:10px;color:#94a3b8;">#${si + 1}</span>
          <button type="button" class="button eng-remove-subrow" style="background:#ef4444;color:#fff;border:none;border-radius:6px;font-size:10px;padding:3px 8px;cursor:pointer;">حذف</button>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;align-items:start;">${fieldsHtml}</div>
      </div>`;
    };

    // رندر کامل بدنه یک ویجت eng — برمی‌گرداند یک jQuery element
    window.__engRenderWidget = function (item) {
      const sc = window.ENG_SCHEMAS[item.type];
      const $w = $('<div class="eng-widget" style="background:linear-gradient(' + sc.color + ');padding:16px;margin:10px 0;border-radius:12px;border:2px solid rgba(255,255,255,0.18);box-shadow:0 4px 14px rgba(0,0,0,0.25);color:#e2e8f0;"></div>');
      $w.append(`<div style="display:flex;align-items:center;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid rgba(255,255,255,0.12);">
        <span style="font-size:20px;margin-left:8px;">${sc.icon}</span>
        <h4 style="margin:0;color:#fff;font-size:14px;font-weight:700;">تنظیمات: ${sc.name}</h4>
      </div>`);

      // فیلدهای اسکالر
      let scalarHtml = '';
      sc.fields.forEach(f => { scalarHtml += window.__engField('eng-f', f, item[f.k]); });
      $w.append(`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:12px;">${scalarHtml}</div>`);

      // لیست‌ها
      sc.lists.forEach(list => {
        const rows = Array.isArray(item[list.k]) ? item[list.k] : [];
        const inner = rows.map((r, ri) => window.__engRenderRow(list, r, ri)).join('');
        $w.append(`<div style="background:rgba(0,0,0,0.15);padding:10px;border-radius:8px;margin-bottom:10px;">
          <div style="font-size:12px;font-weight:700;color:#fff;margin-bottom:8px;">📋 ${window.__engEsc(list.label)}</div>
          <div class="eng-list" data-list-key="${list.k}" style="display:flex;flex-direction:column;gap:10px;">${inner}</div>
          <button type="button" class="button eng-add-row" data-list-key="${list.k}" style="margin-top:8px;background:#10b981;color:#022c22;border:none;font-weight:700;padding:7px 14px;border-radius:6px;cursor:pointer;font-size:12px;">➕ افزودن «${window.__engEsc(list.label)}»</button>
        </div>`);
      });
      return $w;
    };

    // خواندن مقدار یک فیلد از DOM
    window.__engReadVal = function ($el, f) {
      if (!$el.length) return f.def != null ? f.def : '';
      if (f.t === 'checkbox') return $el.is(':checked') ? 'yes' : 'no';
      return $el.val();
    };

    // سینک DOM → item برای یک ویجت eng
    window.__engSaveWidget = function (item, $item) {
      const sc = window.ENG_SCHEMAS[item.type];
      if (!sc) return;
      sc.fields.forEach(f => { item[f.k] = window.__engReadVal($item.find('.eng-f[data-k="' + f.k + '"]').first(), f); });
      sc.lists.forEach(list => {
        const arr = [];
        $item.find('.eng-list[data-list-key="' + list.k + '"]').first().children('.eng-row').each(function () {
          const $row = $(this);
          const obj = {};
          list.item.forEach(f => {
            if (f.sub) {
              const subArr = [];
              $row.find('.eng-sublist[data-sub-key="' + f.k + '"]').first().children('.eng-subrow').each(function () {
                const $sr = $(this);
                const so = {};
                f.item.forEach(sf => { so[sf.k] = window.__engReadVal($sr.find('.eng-srf[data-k="' + sf.k + '"]').first(), sf); });
                subArr.push(so);
              });
              obj[f.k] = subArr;
            } else {
              obj[f.k] = window.__engReadVal($row.find('.eng-rf[data-k="' + f.k + '"]').first(), f);
            }
          });
          arr.push(obj);
        });
        item[list.k] = arr;
      });
    };

    // ساخت یک سطر پیش‌فرض خالی برای یک لیست
    window.__engBlankRow = function (list) {
      const o = {};
      list.item.forEach(f => { o[f.k] = f.sub ? [] : ''; });
      return o;
    };
    window.__engBlankSubRow = function (subField) {
      const o = {};
      subField.item.forEach(f => { o[f.k] = ''; });
      return o;
    };

    // defaults کامل یک ویجت eng (شامل محتوای نمونه)
    window.__engDefaults = function (type) {
      const sc = window.ENG_SCHEMAS[type];
      const o = { type: type };
      sc.fields.forEach(f => { o[f.k] = f.def != null ? f.def : ''; });
      sc.lists.forEach(list => { o[list.k] = JSON.parse(JSON.stringify(list.def || [])); });
      return o;
    };
    // defaults همه ویجت‌های eng (برای newItem)
    window.__engAllDefaults = function () {
      let all = {};
      Object.keys(window.ENG_SCHEMAS).forEach(type => {
        const d = window.__engDefaults(type);
        delete d.type;
        all = Object.assign(all, d);
      });
      return all;
    };

    // ───── Helperهای ویجت‌های سفارشی (استودیوی توسعه) ─────
    // تعریف ویجت‌ها از طریق window.BoomCustomWidgets توسط PHP تزریق می‌شود.
    const cwEsc = function (v) {
      return String(v === undefined || v === null ? '' : v)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    };
    const cwAttr = function (v) {
      return cwEsc(v).replace(/"/g, '&quot;');
    };

    window.__cwFindWidget = function (key) {
      const list = window.BoomCustomWidgets || [];
      for (let i = 0; i < list.length; i++) {
        if (list[i] && list[i].key === key) return list[i];
      }
      return null;
    };

    const CW_INPUT = 'width:100%;padding:8px 10px;border:1px solid #0e7490;border-radius:6px;font-size:12px;background:#083344;color:#ecfeff;';

    /** رندر یک فیلد ساده‌ی ویجت سفارشی */
    window.__cwFieldHtml = function (f, value) {
      const key = f.key;
      const label = f.label || key;
      let input = '';

      switch (f.type) {
        case 'textarea':
        case 'html':
          input = '<textarea class="cw-field" data-key="' + cwAttr(key) + '" rows="4" style="' + CW_INPUT + 'font-family:monospace;resize:vertical;">' + cwEsc(value) + '</textarea>';
          break;
        case 'number':
          input = '<input type="number" class="cw-field" data-key="' + cwAttr(key) + '" value="' + cwAttr(value) + '" style="' + CW_INPUT + '">';
          break;
        case 'color':
          input = '<input type="color" class="cw-field" data-key="' + cwAttr(key) + '" value="' + (cwAttr(value) || '#000000') + '" style="width:100%;height:36px;padding:2px;border:1px solid #0e7490;border-radius:6px;background:#083344;cursor:pointer;">';
          break;
        case 'checkbox':
          input = '<label style="display:flex;align-items:center;gap:8px;font-size:12px;color:#ecfeff;cursor:pointer;">'
            + '<input type="checkbox" class="cw-field" data-key="' + cwAttr(key) + '" ' + (value === 'yes' ? 'checked' : '') + ' style="accent-color:#22d3ee;width:18px;height:18px;"> فعال</label>';
          break;
        case 'select': {
          const opts = String(f.default || '').split(',').map(function (s) { return s.trim(); }).filter(Boolean);
          input = '<select class="cw-field" data-key="' + cwAttr(key) + '" style="' + CW_INPUT + 'cursor:pointer;">'
            + opts.map(function (o) {
              return '<option value="' + cwAttr(o) + '"' + (String(value) === o ? ' selected' : '') + '>' + cwEsc(o) + '</option>';
            }).join('') + '</select>';
          break;
        }
        case 'image':
          input = '<input type="text" class="cw-field" data-key="' + cwAttr(key) + '" value="' + cwAttr(value) + '" placeholder="آدرس تصویر" style="' + CW_INPUT + 'margin-bottom:6px;">'
            + '<button type="button" class="button button-upload-cw" style="font-size:11px;">انتخاب تصویر</button>'
            + (value ? '<img src="' + cwAttr(value) + '" style="max-height:52px;margin-top:6px;display:block;border-radius:5px;">' : '');
          break;
        default:
          input = '<input type="text" class="cw-field" data-key="' + cwAttr(key) + '" value="' + cwAttr(value) + '" style="' + CW_INPUT + '">';
      }

      return '<div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">'
        + '<label style="display:block;margin-bottom:6px;font-size:12px;font-weight:600;color:#a5f3fc;">'
        + cwEsc(label) + ' <code style="color:#67e8f9;font-weight:400;background:none;">{{' + cwEsc(key) + '}}</code></label>'
        + input + '</div>';
    };

    /** رندر یک ردیف از فیلد تکرارشونده */
    window.__cwRepRowHtml = function (f, row, idx) {
      const subs = f.subfields || [];
      const SUB = 'width:100%;padding:6px 8px;border:1px solid #0e7490;border-radius:5px;font-size:11px;background:#083344;color:#ecfeff;';

      const cells = subs.map(function (sf) {
        const v = (row && row[sf.key]) || '';
        let inp;
        if (sf.type === 'image') {
          inp = '<input type="text" class="cw-sub" data-sub="' + cwAttr(sf.key) + '" value="' + cwAttr(v) + '" placeholder="آدرس تصویر" style="' + SUB + '">'
            + '<button type="button" class="button button-upload-cw-sub" style="font-size:10px;margin-top:4px;padding:2px 8px;height:auto;">انتخاب</button>'
            + (v ? '<img src="' + cwAttr(v) + '" style="max-height:38px;margin-top:4px;display:block;border-radius:4px;">' : '');
        } else if (sf.type === 'textarea') {
          inp = '<textarea class="cw-sub" data-sub="' + cwAttr(sf.key) + '" rows="2" style="' + SUB + 'resize:vertical;">' + cwEsc(v) + '</textarea>';
        } else if (sf.type === 'color') {
          inp = '<input type="color" class="cw-sub" data-sub="' + cwAttr(sf.key) + '" value="' + (cwAttr(v) || '#000000') + '" style="width:100%;height:30px;padding:2px;border:1px solid #0e7490;border-radius:5px;background:#083344;cursor:pointer;">';
        } else if (sf.type === 'number') {
          inp = '<input type="number" class="cw-sub" data-sub="' + cwAttr(sf.key) + '" value="' + cwAttr(v) + '" style="' + SUB + '">';
        } else {
          inp = '<input type="text" class="cw-sub" data-sub="' + cwAttr(sf.key) + '" value="' + cwAttr(v) + '" style="' + SUB + '">';
        }
        return '<div><label style="display:block;margin-bottom:4px;font-size:10px;color:#a5f3fc;">' + cwEsc(sf.label || sf.key) + '</label>' + inp + '</div>';
      }).join('');

      return '<div class="cw-rep-row" style="background:rgba(255,255,255,0.06);padding:10px;border-radius:7px;border:1px solid #0e7490;">'
        + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">'
        + '<span style="font-size:11px;font-weight:600;color:#67e8f9;">ردیف ' + (idx + 1) + '</span>'
        + '<button type="button" class="button cw-rep-del" style="font-size:10px;padding:1px 8px;height:auto;color:#fca5a5;">حذف</button></div>'
        + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px;align-items:start;">' + cells + '</div>'
        + '</div>';
    };

    /** رندر کامل یک فیلد تکرارشونده (کانتینر + ردیف‌ها + دکمه افزودن) */
    window.__cwRepeaterHtml = function (f, rows) {
      rows = Array.isArray(rows) ? rows : [];
      const inner = rows.map(function (r, i) { return window.__cwRepRowHtml(f, r, i); }).join('');
      return '<div style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;border:1px dashed #0e7490;">'
        + '<div style="font-size:12px;font-weight:600;color:#a5f3fc;margin-bottom:10px;">'
        + cwEsc(f.label || f.key) + ' <code style="color:#67e8f9;font-weight:400;background:none;">{{#each ' + cwEsc(f.key) + '}}</code></div>'
        + '<div class="cw-rep" data-key="' + cwAttr(f.key) + '" style="display:flex;flex-direction:column;gap:8px;">' + inner + '</div>'
        + '<button type="button" class="button cw-rep-add" data-key="' + cwAttr(f.key) + '" style="margin-top:10px;font-size:11px;">افزودن ردیف</button>'
        + '</div>';
    };

    /** مقادیر پیش‌فرض یک ویجت سفارشی */
    window.__cwDefaults = function (def) {
      const data = {};
      (def && def.fields ? def.fields : []).forEach(function (f) {
        if (f.type === 'repeater') {
          data[f.key] = [];
        } else if (f.type === 'checkbox') {
          data[f.key] = f.default === 'yes' ? 'yes' : 'no';
        } else {
          data[f.key] = f.default || '';
        }
      });
      return data;
    };

    const customCss = `
      /* ──── Design System: Brand #098f81 ──── */
      :root {
        --brand: #098f81;
        --brand-light: #0ba798;
        --brand-dark: #077a6d;
        --brand-bg: #edf8f6;
        --brand-bg-subtle: #f5fbfa;
        --brand-accent: rgba(9,143,129,0.08);
        --surface: #ffffff;
        --bg: #f8fafb;
        --border: #e5e9ed;
        --border-light: #f0f2f4;
        --text-primary: #1a2332;
        --text-secondary: #5a6578;
        --text-muted: #8c95a4;
        --danger: #ef4444;
        --danger-hover: #dc2626;
        --radius-sm: 6px;
        --radius-md: 10px;
        --radius-lg: 14px;
        --radius-xl: 18px;
        --shadow-xs: 0 1px 2px rgba(0,0,0,0.04);
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
        --shadow-md: 0 4px 12px rgba(0,0,0,0.07);
        --shadow-lg: 0 8px 24px rgba(0,0,0,0.08);
        --transition: 0.2s cubic-bezier(0.4,0,0.2,1);
      }

      /* ──── Wrapper / Page ──── */
      .wrap { max-width: 1200px; }
      .wrap h1 { font-size: 22px !important; font-weight: 700 !important; color: var(--text-primary) !important; letter-spacing: -0.3px; margin-bottom: 24px !important; }

      /* ──── Tabs Layout ──── */
      .custom-tabs-container {
        display: flex;
        flex-direction: row-reverse;
        align-items: flex-start;
        gap: 0;
        background: var(--surface);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--border);
        overflow: hidden;
        min-height: 520px;
      }

      .custom-tabs-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        margin: 0;
        min-width: 200px;
        width: 200px;
        flex-shrink: 0;
        padding: 12px 8px;
        background: var(--bg);
        border-left: 1px solid var(--border);
        order: 2;
        align-self: stretch;
        overflow: hidden;
      }

      .custom-tab-btn {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 11px 14px;
        width: 100%;
        text-align: right;
        border-radius: var(--radius-sm);
        transition: all var(--transition);
        background: transparent;
        border: none !important;
        font-size: 13.5px;
        font-weight: 500;
        color: var(--text-secondary);
        cursor: pointer;
        outline: none !important;
        line-height: 1.4;
        position: relative;
      }

      .custom-tab-btn:hover {
        background: var(--brand-accent);
        color: var(--brand);
      }

      .custom-tab-btn.active,
      .custom-tab-btn:focus {
        background: var(--brand-bg) !important;
        color: var(--brand) !important;
        font-weight: 600;
      }

      .custom-tab-btn.active::before {
        content: '';
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 3px;
        height: 60%;
        background: var(--brand);
        border-radius: 0 3px 3px 0;
      }

      .custom-tab-content {
        flex: 1;
        order: 1;
        padding: 28px 32px;
        min-height: 480px;
        min-width: 0;
        overflow: hidden;
      }

      @media (max-width: 900px) {
        .custom-tabs-container { flex-direction: column; border-radius: var(--radius-lg); }
        .custom-tabs-list {
          flex-direction: row;
          width: 100%;
          min-width: unset;
          border-left: none;
          border-bottom: 1px solid var(--border);
          padding: 8px;
          overflow-x: auto;
          gap: 4px;
        }
        .custom-tab-btn {
          white-space: nowrap;
          padding: 10px 16px;
          width: auto;
          font-size: 13px;
        }
        .custom-tab-btn.active::before { display: none; }
        .custom-tab-content { padding: 20px 16px; }
      }

      /* ──── Form Elements ──── */
      .form-table th { font-size: 13px; font-weight: 600; color: var(--text-primary); padding: 16px 10px 16px 0; vertical-align: top; }
      .form-table td { padding: 12px 0; }
      .form-table input[type="text"],
      .form-table input[type="url"],
      .form-table input[type="number"],
      .form-table input[type="email"],
      .form-table textarea,
      .form-table select {
        border: 1.5px solid var(--border) !important;
        border-radius: var(--radius-sm) !important;
        padding: 9px 12px !important;
        font-size: 13.5px !important;
        color: var(--text-primary) !important;
        background: var(--surface) !important;
        transition: border-color var(--transition), box-shadow var(--transition) !important;
        outline: none !important;
      }
      .form-table input[type="text"]:focus,
      .form-table input[type="url"]:focus,
      .form-table input[type="number"]:focus,
      .form-table input[type="email"]:focus,
      .form-table textarea:focus,
      .form-table select:focus {
        border-color: var(--brand) !important;
        box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important;
      }

      /* ──── Save Button ──── */
      .custom-tab-content .submit {
        margin-top: 32px !important;
        padding-top: 24px !important;
        border-top: 1px solid var(--border-light) !important;
        text-align: right !important;
        position: relative !important;
        bottom: 0 !important;
      }
      .custom-tab-content .submit .button-primary,
      .wrap .submit .button-primary {
        background: var(--brand) !important;
        border-color: var(--brand) !important;
        color: #fff !important;
        border-radius: var(--radius-sm) !important;
        padding: 10px 28px !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        box-shadow: 0 1px 3px rgba(9,143,129,0.2) !important;
        transition: all var(--transition) !important;
        cursor: pointer;
        letter-spacing: 0;
      }
      .custom-tab-content .submit .button-primary:hover,
      .wrap .submit .button-primary:hover {
        background: var(--brand-dark) !important;
        border-color: var(--brand-dark) !important;
        box-shadow: 0 4px 12px rgba(9,143,129,0.25) !important;
        transform: translateY(-1px);
      }

      /* ──── List Wrapper ──── */
      .custom-list-wrap {
        background: var(--bg) !important;
        border-radius: var(--radius-md) !important;
        box-shadow: none !important;
        border: 1px solid var(--border) !important;
        padding: 12px !important;
      }
      .custom-list-items { margin-bottom: 8px; }

      /* ──── List Items ──── */
      .custom-list-item {
        background: var(--surface) !important;
        border: 1.5px solid var(--border) !important;
        box-shadow: var(--shadow-xs) !important;
        margin-bottom: 8px;
        border-radius: var(--radius-md) !important;
        padding: 14px 16px !important;
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
        transition: border-color var(--transition), box-shadow var(--transition);
      }
      .custom-list-item:hover {
        border-color: rgba(9,143,129,0.25) !important;
        box-shadow: var(--shadow-sm) !important;
      }
      .custom-list-item input,
      .custom-list-item textarea {
        border-radius: var(--radius-sm) !important;
        border: 1.5px solid var(--border) !important;
        padding: 8px 10px !important;
        font-size: 13px !important;
        color: var(--text-primary) !important;
        transition: border-color var(--transition), box-shadow var(--transition) !important;
        background: var(--surface) !important;
      }
      .custom-list-item input:focus,
      .custom-list-item textarea:focus,
      .custom-list-item select:focus {
        border-color: var(--brand) !important;
        box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important;
        outline: none !important;
      }
      .custom-list-item select {
        border-radius: var(--radius-sm) !important;
        border: 1.5px solid var(--border) !important;
        padding: 8px 10px !important;
        font-size: 13px !important;
        background: var(--surface) !important;
        transition: border-color var(--transition) !important;
      }
      .custom-list-item input[type="text"] { min-width: 100px; }
      .custom-list-item .field-date { width: 120px; }
      .custom-list-item .field-time { width: 90px; }
      .custom-list-item .field-title, .custom-list-item .field-discount-title { flex: 1; min-width: 120px; }
      .custom-list-item .field-small-text { flex: 1; min-width: 100px; }
      .custom-list-item .field-link { flex: 2; min-width: 180px; }
      .custom-list-item .field-html { width: 100%; height: 60px; }
      .custom-list-item label { font-size: 12px; color: var(--text-muted); margin-left: 4px; font-weight: 500; }
      .custom-list-item .field-image-preview {
        max-width: 56px;
        max-height: 56px;
        border-radius: var(--radius-sm);
        border: 1.5px solid var(--border);
        margin-left: 8px;
        object-fit: cover;
      }

      /* ──── Buttons ──── */
      .custom-list-item .button {
        background: var(--danger) !important;
        color: #fff !important;
        border: none !important;
        border-radius: var(--radius-sm) !important;
        padding: 7px 16px !important;
        cursor: pointer;
        font-size: 12.5px !important;
        font-weight: 500 !important;
        transition: all var(--transition) !important;
      }
      .custom-list-item .button:hover {
        background: var(--danger-hover) !important;
        box-shadow: 0 2px 8px rgba(239,68,68,0.2) !important;
      }
      .custom-list-item .button.button-upload {
        background: var(--brand) !important;
        margin-right: 6px;
      }
      .custom-list-item .button.button-upload:hover {
        background: var(--brand-dark) !important;
        box-shadow: 0 2px 8px rgba(9,143,129,0.2) !important;
      }
      .custom-list-wrap .button-primary {
        background: var(--brand) !important;
        border-color: var(--brand) !important;
        color: #fff !important;
        border-radius: var(--radius-sm) !important;
        padding: 9px 20px !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        transition: all var(--transition) !important;
      }
      .custom-list-wrap .button-primary:hover {
        background: var(--brand-dark) !important;
        border-color: var(--brand-dark) !important;
        box-shadow: 0 4px 12px rgba(9,143,129,0.2) !important;
      }

      /* ──── Drag Handle ──── */
      .drag-handle { cursor: grab; color: var(--text-muted); font-size: 16px; opacity: 0.5; transition: opacity var(--transition); }
      .drag-handle:hover { opacity: 1; }
      .drag-handle-submenu { user-select: none; cursor: grab; color: var(--text-muted); }

      /* ──── Job Positions ──── */
      .job-position-item { background: var(--surface); padding: 16px; margin-bottom: 10px; border-radius: var(--radius-md); border: 1.5px solid var(--border); }
      .job-position-title { font-size: 15px; font-weight: 600; margin-bottom: 10px; color: var(--text-primary); }
      .job-position-description { margin-bottom: 10px; color: var(--text-secondary); font-size: 13.5px; }
      .job-position-type { display: inline-block; padding: 4px 10px; background: var(--brand-bg); color: var(--brand); border-radius: 20px; margin-right: 10px; font-size: 12px; font-weight: 600; }
      .job-position-skills { margin-top: 10px; }
      .job-skill-tag { display: inline-block; padding: 3px 8px; background: var(--bg); border: 1px solid var(--border); border-radius: 20px; margin: 2px; font-size: 12px; color: var(--text-secondary); }

      /* ──── Mega Menu ──── */
      .megamenu-item { position: relative; }
      .megamenu-item .submenu-item:hover { box-shadow: var(--shadow-sm); transform: translateY(-1px); }
      .megamenu-item .field-child-name:focus,
      .megamenu-item .field-child-link:focus { border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .megamenu-item .remove-submenu-btn:hover { background: var(--danger-hover) !important; }
      .megamenu-item .add-submenu-btn:hover { box-shadow: 0 2px 8px rgba(9,143,129,0.2); }

      /* ──── Logos ──── */
      .logos-container { width: 100%; margin-top: 10px; }
      .logo-item {
        background: var(--surface) !important;
        border: 1.5px solid var(--border) !important;
        border-radius: var(--radius-md) !important;
        padding: 14px !important;
        margin: 8px 0 !important;
        transition: border-color var(--transition) !important;
      }
      .logo-item:hover { border-color: rgba(9,143,129,0.25) !important; }
      .logo-item h4 { color: var(--text-primary) !important; margin: 0 0 10px 0 !important; font-size: 13.5px !important; font-weight: 600 !important; }
      .logo-item input[type="text"] { border: 1.5px solid var(--border) !important; border-radius: var(--radius-sm) !important; padding: 8px 10px !important; background: var(--surface) !important; }
      .logo-item .button { font-size: 12px !important; padding: 6px 12px !important; }

      /* ──── Stories ──── */
      .story-card { position: relative; }
      .story-card .field-story-title { transition: border-color var(--transition); }
      .story-card .field-story-title:focus { border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .story-images-container { margin-top: 16px; }
      .story-image-item { position: relative; transition: all 0.25s ease; }
      .story-image-item:hover { transform: translateY(-1px); box-shadow: var(--shadow-md) !important; }
      .story-image-item input:focus, .story-image-item select:focus { outline: none !important; border-color: var(--brand) !important; box-shadow: 0 0 0 3px rgba(9,143,129,0.1) !important; }
      .story-image-item .button-upload-story-image:hover { background: var(--brand-dark) !important; }
      .story-image-item .remove-story-image-btn:hover { background: var(--danger-hover) !important; }
      .add-story-image-btn:hover { background: var(--brand-light) !important; box-shadow: 0 4px 12px rgba(9,143,129,0.2) !important; }
      .button-upload-story-thumbnail:hover { background: var(--brand-dark) !important; }

      /* ════════════════════════════════════════════════════════
         پنل «استایل‌های سفارشی» در تب تنظیمات استایل
         ════════════════════════════════════════════════════════ */
      .boom-cstyle-panel {
        margin-top: 28px !important;
        border: 1.5px solid var(--border) !important;
        border-radius: 14px !important;
        background: var(--surface) !important;
        overflow: hidden !important;
      }
      .boom-cstyle-toggle {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        width: 100% !important;
        padding: 16px 20px !important;
        background: var(--brand-bg-subtle) !important;
        border: none !important;
        border-bottom: 1.5px solid transparent !important;
        cursor: pointer !important;
        font-size: 14.5px !important;
        font-weight: 700 !important;
        color: var(--brand-dark) !important;
        text-align: right !important;
        transition: background var(--transition) !important;
      }
      .boom-cstyle-toggle:hover { background: var(--brand-accent) !important; }
      .boom-cstyle-panel.is-open .boom-cstyle-toggle {
        border-bottom-color: var(--border-light) !important;
      }
      .boom-cstyle-caret {
        width: 0 !important; height: 0 !important;
        border-left: 5px solid transparent !important;
        border-right: 5px solid transparent !important;
        border-top: 6px solid var(--brand) !important;
        transition: transform var(--transition) !important;
      }
      .boom-cstyle-panel.is-open .boom-cstyle-caret { transform: rotate(180deg) !important; }

      .boom-cstyle-body { display: none; padding: 4px 20px 8px !important; }

      .boom-cstyle-intro {
        background: var(--brand-bg) !important;
        border-right: 3px solid var(--brand) !important;
        border-radius: 10px !important;
        padding: 14px 16px !important;
        margin: 16px 0 6px !important;
      }
      .boom-cstyle-intro strong {
        display: block !important;
        font-size: 13.5px !important;
        color: var(--brand-dark) !important;
        margin-bottom: 6px !important;
      }
      .boom-cstyle-intro p {
        margin: 6px 0 !important;
        font-size: 12.5px !important;
        line-height: 2 !important;
        color: var(--text-secondary) !important;
      }
      .boom-cstyle-intro a { color: var(--brand) !important; text-decoration: none !important; }
      .boom-cstyle-intro a:hover { text-decoration: underline !important; }

      /* سلکت‌های انتخاب استایل سفارشی */
      .boom-cstyle-table select.boom-cstyle-select {
        min-width: 300px !important;
        border: 1.5px solid var(--border) !important;
        border-radius: 10px !important;
        padding: 10px 14px !important;
        padding-left: 34px !important;
        font-size: 13.5px !important;
        font-weight: 500 !important;
        color: var(--text-primary) !important;
        background-color: var(--surface) !important;
        background-image: url("data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%23098f81' d='M1 1l5 5 5-5'/%3E%3C/svg%3E") !important;
        background-repeat: no-repeat !important;
        background-position: left 14px center !important;
        -webkit-appearance: none !important;
        -moz-appearance: none !important;
        appearance: none !important;
        cursor: pointer !important;
        transition: border-color var(--transition), box-shadow var(--transition) !important;
      }
      .boom-cstyle-table select.boom-cstyle-select:hover { border-color: var(--brand-light) !important; }
      .boom-cstyle-table select.boom-cstyle-select:focus {
        border-color: var(--brand) !important;
        box-shadow: 0 0 0 3px rgba(9,143,129,0.12) !important;
      }
      .boom-cstyle-table th {
        font-size: 13px !important;
        color: var(--text-primary) !important;
        padding-top: 18px !important;
      }
      .boom-cstyle-empty { color: var(--text-muted) !important; font-style: italic !important; }

    `;
    if (!document.getElementById('custom-theme-settings-css')) {
      $('<style id="custom-theme-settings-css">' + customCss + '</style>').appendTo('head');
    }


    const $form = $('.wrap form');
    if ($form.length) {

      const $allContent = $('<div class="custom-tab-content" id="tab-content-general"></div>');
      $form.children().not('.custom-tabs-container, .about-page-field').appendTo($allContent);

      const $mainPageContent = $('<div class="custom-tab-content" id="tab-content-main" style="display:none;"><p>در این بخش تنظیمات صفحه اصلی قرار می‌گیرد.</p></div>');

      const $styleContent = $('<div class="custom-tab-content" id="tab-content-style" style="display:none;"><p>در این بخش تنظیمات استایل‌های مختلف قالب قرار می‌گیرد.</p></div>');

      const $jobsContent = $('<div class="custom-tab-content" id="tab-content-jobs" style="display:none;"></div>');

      const $aboutContent = $('<div class="custom-tab-content" id="tab-content-about" style="display:none;"><p>تنظیمات صفحه درباره ما</p></div>');

      const $contactContent = $('<div class="custom-tab-content" id="tab-content-contact" style="display:none;"><p>تنظیمات صفحه تماس با ما</p></div>');

      const $faqContent = $('<div class="custom-tab-content" id="tab-content-faq" style="display:none;"></div>');

      const $storiesContent = $('<div class="custom-tab-content" id="tab-content-stories" style="display:none;"></div>');

      const $notificationContent = $('<div class="custom-tab-content" id="tab-content-notification" style="display:none;"><p>تنظیمات اطلاعیه سایت</p></div>');

      const $securityContent = $('<div class="custom-tab-content" id="tab-content-security" style="display:none;"><p>تنظیمات امنیتی سایت</p></div>');

      const $fontContent = $('<div class="custom-tab-content" id="tab-content-font" style="display:none;"><p>تنظیمات فونت سایت</p></div>');

      const $customizationContent = $('<div class="custom-tab-content" id="tab-content-customization" style="display:none;"><p>سفارشی‌سازی با CSS و JavaScript</p></div>');

      const $translationsContent = $('<div class="custom-tab-content" id="tab-content-translations" style="display:none;"><p>تنظیمات ترجمه متن‌های سایت</p></div>');

      const $darkThemeContent = $('<div class="custom-tab-content" id="tab-content-dark-theme" style="display:none;"><p>تنظیمات تم دارک سایت</p></div>');

      const $userPanelContent = $('<div class="custom-tab-content" id="tab-content-user-panel" style="display:none;"><p>تنظیمات پنل کاربری</p></div>');

      const $headerCurrencyContent = $('<div class="custom-tab-content" id="tab-content-header-currency" style="display:none;"><p>تنظیمات نمایش ارز در هدر سایت</p></div>');

      const $purchaseAddonsContent = $('<div class="custom-tab-content" id="tab-content-purchase-addons" style="display:none;"></div>');

      // ───── تب ایمپورت / اکسپورت ─────
      const $importExportContent = $('<div class="custom-tab-content" id="tab-content-import-export" style="display:none;"></div>');

      const $storeDefaultContent = $('<div class="custom-tab-content" id="tab-content-store-default" style="display:none;"><p>اطلاعات «فروشگاه پیش‌فرض» که در استایل «مینیمال فروشگاهی» صفحه محصول نمایش داده می‌شود.</p></div>');

      const $captchaContent = $('<div class="custom-tab-content" id="tab-content-captcha" style="display:none;"><p>تنظیمات کپچا برای فرم‌های ورود و ثبت‌نام. پس از انتخاب نوع سرویس، Site Key و Secret Key را از پنل همان سرویس دریافت و وارد کنید.</p></div>');

      const $themeUsageContent = $('<div class="custom-tab-content" id="tab-content-theme-usage" style="display:none;"></div>');
      $importExportContent.html(`
        <div style="max-width:760px;display:flex;flex-direction:column;gap:18px;">
          <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
            <h2 style="margin:0 0 6px;font-size:17px;">📤 خروجی گرفتن (Export)</h2>
            <p style="margin:0 0 14px;color:#64748b;font-size:13px;line-height:1.9;">یک فایل JSON از تمام تنظیمات قالب (شامل صفحه اصلی، استایل‌ها، منوها و...) دانلود می‌شود. آدرس سایت فعلی داخل فایل ذخیره می‌گردد تا هنگام ایمپورت، دامنه به‌صورت خودکار جایگزین شود.</p>
            <button type="button" id="boom-ie-export" class="button button-primary" style="font-size:13px;">⬇️ دانلود فایل تنظیمات</button>
          </div>

          <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
            <h2 style="margin:0 0 6px;font-size:17px;">📥 ورودی دادن (Import)</h2>
            <p style="margin:0 0 14px;color:#64748b;font-size:13px;line-height:1.9;">یک فایل JSON معتبر انتخاب کنید. هنگام ایمپورت، تمام لینک‌ها و آدرس تصاویری که با دامنه‌ی سایت قبلی شروع می‌شوند، به‌صورت خودکار با دامنه‌ی همین سایت جایگزین می‌شوند.</p>
            <div style="display:flex;flex-direction:column;gap:12px;">
              <div>
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#334155;">فایل تنظیمات:</label>
                <input type="file" id="boom-ie-file" accept=".json,application/json" style="font-size:13px;">
              </div>
              <div>
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#334155;">دامنه‌ی قبلی (اختیاری):</label>
                <input type="text" id="boom-ie-old-domain" placeholder="مثلاً https://old-site.com — خالی بگذارید تا خودکار از فایل خوانده شود" style="width:100%;max-width:480px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;" dir="ltr">
                <p style="margin:6px 0 0;color:#94a3b8;font-size:12px;">اگر خالی باشد، دامنه‌ی ذخیره‌شده در خود فایل استفاده می‌شود.</p>
              </div>
              <div>
                <label style="display:flex;align-items:flex-start;gap:8px;font-size:13px;color:#334155;cursor:pointer;">
                  <input type="checkbox" id="boom-ie-import-images" checked style="margin-top:3px;">
                  <span><strong>درون‌ریزی تصاویر به کتابخانه رسانه</strong><br><span style="color:#94a3b8;font-size:12px;">تصاویری که به دامنه‌ی قبلی اشاره می‌کنند (بنرها، لوگوها و...) دانلود شده و در «رسانه‌ها»ی همین سایت قرار می‌گیرند تا درون‌ریزی کامل باشد. ممکن است چند لحظه بیشتر طول بکشد.</span></span>
                </label>
              </div>
              <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                <button type="button" id="boom-ie-import-btn" class="button button-primary" style="font-size:13px;background:#16a34a;border-color:#15803d;">⬆️ ایمپورت و جایگزینی تنظیمات</button>
                <span id="boom-ie-status" style="font-size:13px;color:#475569;"></span>
              </div>
              <p style="margin:4px 0 0;color:#b91c1c;font-size:12px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:8px 10px;">⚠️ توجه: ایمپورت، تمام تنظیمات فعلی قالب را جایگزین می‌کند. پیش از ایمپورت، یک خروجی پشتیبان بگیرید.</p>
            </div>
          </div>
        </div>
      `);


      const $aboutFields = $('.about-page-field');
      if ($aboutFields.length) {
        const $table = $('<table class="form-table" role="presentation"></table>');
        $aboutFields.appendTo($table);
        $aboutContent.empty().append($table);
      }
      const $tabsList = $('<div class="custom-tabs-list"></div>');
      $tabsList.append('<button type="button" class="custom-tab-btn active" data-tab="general">تنظیمات عمومی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="theme-usage">کاربری قالب</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="main">صفحه اصلی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="style">تنظیمات استایل</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="jobs">موقعیت‌های شغلی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="about">صفحه درباره ما</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="contact">صفحه تماس با ما</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="faq">سوالات متداول</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="stories">استوری‌ها</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="notification">اطلاعیه</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="security">تنظیمات امنیتی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="font">تنظیمات فونت</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="customization">سفارشی‌سازی</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="translations">ترجمه متن‌ها</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="dark-theme">تم دارک</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="user-panel">پنل کاربری</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="header-currency">نمایش ارز هدر</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="purchase-addons">آیتم‌های اضافه خرید</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="store-default">فروشگاه پیش‌فرض</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="captcha">کپچا</button>');
      $tabsList.append('<button type="button" class="custom-tab-btn" data-tab="import-export">ایمپورت / اکسپورت</button>');

      // دکمه‌های ذخیره بعداً در انتها اضافه خواهند شد

      const $tabsContainer = $('<div class="custom-tabs-container"></div>');
      $tabsContainer.append($tabsList).append($allContent).append($mainPageContent).append($styleContent).append($jobsContent).append($aboutContent).append($contactContent).append($faqContent).append($storiesContent).append($notificationContent).append($securityContent).append($fontContent).append($customizationContent).append($translationsContent).append($darkThemeContent).append($userPanelContent).append($headerCurrencyContent).append($purchaseAddonsContent).append($storeDefaultContent).append($captchaContent).append($importExportContent).append($themeUsageContent);
      $form.prepend($tabsContainer);

      // ── انتقال فیلدهای «کاربری قالب» به تب مخصوص + نمایش شرطی تنظیمات طلا ──
      (function setupThemeUsageTab() {
        const $intro = $('<div style="max-width:820px;margin-bottom:18px;">'
          + '<h2 style="margin:0 0 6px;font-size:17px;">کاربری قالب</h2>'
          + '<p style="margin:0;color:#64748b;font-size:13px;line-height:2;">'
          + 'مشخص کنید این قالب برای چه نوع کسب‌وکاری استفاده می‌شود. حالت «فروشگاهی» دقیقاً همان رفتار همیشگی قالب است '
          + 'و با انتخاب کاربری‌های دیگر فقط امکانات اضافه می‌شود.'
          + '</p></div>');

        const $usageTable = $('<table class="form-table" role="presentation"></table>');
        const $goldTable = $('<table class="form-table" role="presentation"></table>');

        // ردیف انتخاب کاربری
        const $usageRow = $("[name='custom_theme_options[theme_usage]']").closest('tr');
        if ($usageRow.length) $usageRow.appendTo($usageTable);

        // ردیف‌های تنظیمات طلا
        $("[data-section='gold_usage']").closest('tr').each(function () {
          $(this).appendTo($goldTable);
        });

        // لیست لینک‌های نوار بالای هدر طلا
        const $goldLinksRow = $(".custom-list-wrap[data-name='gold_header_links']").closest('tr');
        if ($goldLinksRow.length) $goldLinksRow.appendTo($goldTable);

        const $goldBox = $('<div id="boom-gold-settings" style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:6px 20px 14px;margin-top:10px;">'
          + '<h3 style="margin:14px 0 4px;font-size:15px;">تنظیمات طلا و جواهر</h3>'
          + '<p style="margin:0 0 6px;color:#64748b;font-size:12.5px;line-height:1.9;">این تنظیمات فقط در کاربری «طلا و جواهر» اعمال می‌شوند.</p>'
          + '</div>');
        $goldBox.append($goldTable);

        $themeUsageContent.append($intro).append($usageTable).append($goldBox);

        function toggleGoldBox() {
          const val = $('#boom-theme-usage-select').val();
          if (val === 'gold') { $goldBox.show(); } else { $goldBox.hide(); }
        }
        $(document).on('change', '#boom-theme-usage-select', toggleGoldBox);
        toggleGoldBox();
      })();

      // انتقال فیلدهای «فروشگاه پیش‌فرض» به تب مخصوص
      (function moveStoreDefaultFields() {
        const keys = ['store_default_name', 'store_default_subtitle', 'store_default_logo'];
        const $table = $('<table class="form-table" role="presentation"></table>');
        let moved = 0;
        keys.forEach(function (k) {
          const $row = $("input[name='custom_theme_options[" + k + "]']").closest('tr');
          if ($row.length) { $row.appendTo($table); moved++; }
        });
        if (moved) { $storeDefaultContent.find('p').remove(); $storeDefaultContent.append($table); }
      })();

      // انتقال فیلدهای «کپچا» به تب مخصوص
      (function moveCaptchaFields() {
        const keys = ['captcha_enabled', 'captcha_provider', 'captcha_site_key', 'captcha_secret_key', 'captcha_v3_threshold'];
        const $table = $('<table class="form-table" role="presentation"></table>');
        let moved = 0;
        keys.forEach(function (k) {
          const $row = $("[name='custom_theme_options[" + k + "]']").closest('tr');
          if ($row.length) { $row.appendTo($table); moved++; }
        });
        if (moved) { $captchaContent.append($table); }

        // نمایش/پنهان‌سازی فیلد آستانه بر اساس نوع سرویس (فقط reCAPTCHA v3)
        const $providerSel = $captchaContent.find("[name='custom_theme_options[captcha_provider]']");
        const $thresholdRow = $captchaContent.find("[name='custom_theme_options[captcha_v3_threshold]']").closest('tr');
        const toggleThreshold = function () {
          if ($providerSel.val() === 'recaptcha_v3') { $thresholdRow.show(); }
          else { $thresholdRow.hide(); }
        };
        $providerSel.on('change', toggleThreshold);
        toggleThreshold();
      })();

      $tabsList.on('click', '.custom-tab-btn', function () {
        $tabsList.find('.custom-tab-btn').removeClass('active');
        $(this).addClass('active');
        const tabName = $(this).data('tab');
        $('.custom-tab-content').hide();
        $('#tab-content-' + tabName).show();

        // رفع مشکل TinyMCE در تب‌های درباره ما و تماس با ما
        if (tabName === 'about' || tabName === 'contact') {
          setTimeout(function () {
            if (typeof tinyMCE !== 'undefined') {
              tinyMCE.editors.forEach(function (editor) {
                if (editor && editor.id && $('#tab-content-' + tabName).find('#' + editor.id).length > 0) {
                  tinyMCE.execCommand('mceRemoveEditor', true, editor.id);
                  tinyMCE.execCommand('mceAddEditor', true, editor.id);
                }
              });
            }
          }, 100);
        }
      });

      // ───── هندلرهای ایمپورت / اکسپورت ─────
      const boomIE = window.BoomIE || { ajaxurl: (window.ajaxurl || '/wp-admin/admin-ajax.php'), nonce: '', siteUrl: '' };

      $importExportContent.on('click', '#boom-ie-export', function () {
        const $btn = $(this);
        $btn.prop('disabled', true).text('در حال آماده‌سازی...');
        $.post(boomIE.ajaxurl, { action: 'boom_export_settings', nonce: boomIE.nonce })
          .done(function (res) {
            if (!res || !res.success) { alert('خطا در گرفتن خروجی تنظیمات.'); return; }
            const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const stamp = new Date().toISOString().slice(0, 10);
            a.href = url;
            a.download = 'boom-settings-' + stamp + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          })
          .fail(function () { alert('خطا در ارتباط با سرور.'); })
          .always(function () { $btn.prop('disabled', false).text('⬇️ دانلود فایل تنظیمات'); });
      });

      $importExportContent.on('click', '#boom-ie-import-btn', function () {
        const fileInput = document.getElementById('boom-ie-file');
        const $status = $('#boom-ie-status');
        if (!fileInput || !fileInput.files.length) { $status.css('color', '#b91c1c').text('ابتدا یک فایل انتخاب کنید.'); return; }
        if (!confirm('این کار تمام تنظیمات فعلی قالب را جایگزین می‌کند. ادامه می‌دهید؟')) return;

        const reader = new FileReader();
        reader.onload = function (e) {
          const text = e.target.result;
          try { JSON.parse(text); } catch (err) {
            $status.css('color', '#b91c1c').text('فایل انتخاب‌شده یک JSON معتبر نیست.');
            return;
          }
          const oldDomain = ($('#boom-ie-old-domain').val() || '').trim();
          const importImages = $('#boom-ie-import-images').is(':checked') ? '1' : '0';
          $status.css('color', '#475569').text(importImages === '1' ? 'در حال ایمپورت و دریافت تصاویر... (ممکن است کمی طول بکشد)' : 'در حال ایمپورت...');
          $.post(boomIE.ajaxurl, {
            action: 'boom_import_settings',
            nonce: boomIE.nonce,
            payload: text,
            old_domain: oldDomain,
            import_images: importImages
          })
            .done(function (res) {
              if (res && res.success) {
                const d = res.data || {};
                let imgMsg = '';
                if (importImages === '1') {
                  const imported = d.images_imported || 0;
                  const reused = d.images_reused || 0;
                  const failed = d.images_failed || 0;
                  imgMsg = ' (' + (imported + reused) + ' تصویر وارد شد' + (failed ? '، ' + failed + ' ناموفق' : '') + ')';
                }
                $status.css('color', '#16a34a').text('با موفقیت ایمپورت شد' + imgMsg + '. صفحه بازنشانی می‌شود...');
                setTimeout(function () { location.reload(); }, 1800);
              } else {
                const msg = (res && res.data) ? res.data : 'خطای نامشخص';
                $status.css('color', '#b91c1c').text('خطا: ' + msg);
              }
            })
            .fail(function () { $status.css('color', '#b91c1c').text('خطا در ارتباط با سرور.'); });
        };
        reader.readAsText(fileInput.files[0]);
      });
    }

    // ساخت لیست‌ها به‌صورت تابعِ قابل فراخوانی مجدد نگه داشته می‌شود.
    // دلیل: در ویرایشگر بلوکی (Gutenberg) پس از ذخیره، وردپرس HTML متاباکس‌ها را
    // با پاسخ سرور جایگزین می‌کند؛ در آن حالت رابط ساخته‌شده با جاوااسکریپت از بین
    // می‌رود و باید دوباره ساخته شود. علامت data-boom-init از ساخت دوباره روی یک
    // عنصر (و دوبار بایند شدن هندلرها) جلوگیری می‌کند.
    window.__boomInitCustomLists = function () {
    $('.custom-list-wrap').each(function () {
      if (this.getAttribute('data-boom-init') === '1') return;
      this.setAttribute('data-boom-init', '1');
      // هر لیست در یک try مستقل ساخته می‌شود؛ خطای یک ویجت نباید مانع
      // اجرای بقیه‌ی اسکریپت (به‌ویژه کد چیدمان تب‌ها در انتهای فایل) شود.
      try {
      const $wrapper = $(this);
      // صفحه‌ساز برگه‌ها با نام مستقل «boom_page_sections» علامت‌گذاری می‌شود تا
      // منطق مخصوص صفحهٔ تنظیمات (جابه‌جایی به تب‌ها و مخفی‌سازی home_sections)
      // آن را هدف نگیرد؛ ولی از نظر رندر و ذخیره دقیقاً مثل home_sections است.
      const rawName = $wrapper.data('name');
      const name = rawName === 'boom_page_sections' ? 'home_sections' : rawName;
      // یافتن textareaی مقصد. اگر به هر دلیلی همسایهٔ بلافصل نبود (مثلاً وقتی لیست
      // داخل متاباکس یا ساختار متفاوتی قرار می‌گیرد) در همان ظرف جست‌وجو می‌شود.
      // بدون این fallback، $textarea خالی می‌ماند، val() بی‌صدا کاری نمی‌کند و
      // در نتیجه چیدمان هرگز ذخیره نمی‌شود.
      let $textarea = $wrapper.next('textarea.custom-list-json');
      if (!$textarea.length) {
        $textarea = $wrapper.siblings('textarea.custom-list-json').first();
      }
      if (!$textarea.length) {
        $textarea = $wrapper.parent().find('textarea.custom-list-json').first();
      }
      if (!$textarea.length) {
        console.error('[Boom] textarea مربوط به لیست "' + rawName + '" پیدا نشد؛ ذخیره‌سازی انجام نمی‌شود.');
      }
      let items = [];

      try {
        items = JSON.parse($textarea.val()) || [];
      } catch (e) {
        items = [];
      }

      // دفاعی: ورودی باید آرایه‌ای از شیء باشد. مقدارهای null/غیرشیء که ممکن است
      // از ذخیره‌های ناقص قبلی باقی مانده باشند حذف می‌شوند، وگرنه assignUUIDs
      // روی آن‌ها خطا می‌دهد و کل لیست (از جمله دکمه «افزودن») ساخته نمی‌شود.
      if (!Array.isArray(items)) items = [];
      items = items.filter(function (it) { return it && typeof it === 'object'; });

      // Migration: تبدیل داده‌های قدیمی site_menu (بدون children) به ساختار جدید
      if (name === 'site_menu') {
        items = items.map(item => {
          // اگر children وجود نداشته باشد، یک آرایه خالی اضافه کنیم
          if (!item.children) {
            item.children = [];
          }
          // Migration سطح ۳: اگر children فرزند children نداشته باشد
          item.children = item.children.map(child => {
            if (!child.children) {
              child.children = [];
            }
            return child;
          });
          return item;
        });
      }


      function assignUUIDs() {
        items.forEach(item => {
          if (!item._uuid) {
            item._uuid = Math.random().toString(36).substring(2, 10);
          }
          // اختصاص UUID به children در site_menu
          if (name === 'site_menu' && item.children && Array.isArray(item.children)) {
            item.children.forEach(child => {
              if (!child._uuid) {
                child._uuid = 'child-' + Math.random().toString(36).substring(2, 10);
              }
              // اختصاص UUID به سطح ۳
              if (child.children && Array.isArray(child.children)) {
                child.children.forEach(grandchild => {
                  if (!grandchild._uuid) {
                    grandchild._uuid = 'grandchild-' + Math.random().toString(36).substring(2, 10);
                  }
                });
              }
            });
          }
        });
      }

      function render() {
        assignUUIDs();
        $wrapper.empty();
        const $list = $('<div class="custom-list-items"></div>');


        let isHomeSections = (name === 'home_sections');
        let isSiteMenu = (name === 'site_menu');

        let isAboutBoxes = (name === 'about_boxes');
        if ((isHomeSections || isSiteMenu) && $.fn.sortable) {
          $list.sortable({
            handle: '.drag-handle',
            axis: 'y',
            update: function () {
              let newItems = [];
              $list.find('.custom-list-item').each(function () {
                const uuid = $(this).data('id');
                const found = items.find(i => i._uuid === uuid);
                if (found) newItems.push(found);
              });
              items = newItems;
              save();
              render();
            }
          });
        }

        items.forEach((item, idx) => {
          const $item = $(`<div class="custom-list-item" data-id="${item._uuid}"></div>`);

          if (isHomeSections) {
            $item.append('<span class="drag-handle" style="cursor:grab;font-size:20px;margin-left:8px;">☰</span>');
          }

          if (name === 'slider') {
            $item.append(`<input type="text" placeholder="عنوان تخفیف" class="field-discount-title" value="${item.discount_title || ''}">`);
            $item.append(`<input type="text" placeholder="عنوان" class="field-title" value="${item.title || ''}">`);
            $item.append(`<input type="text" placeholder="نوشته کوچک" class="field-small-text" value="${item.small_text || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);

            $item.append(`<input type="text" placeholder="تاریخ (مثال: 1403/04/18)" class="field-date" value="${item.date_fa || ''}">`);
            $item.append(`<input type="time" placeholder="ساعت" class="field-time" value="${item.time || ''}">`);

            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
          } else if (name === 'user_panel_slider') {
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'product_categories') {
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-icon" value="${item.icon || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.icon) $item.append(`<img src="${item.icon}" class="field-image-preview">`);
            $item.append(`<input type="text" placeholder="نام" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
            $item.append(`<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;white-space:nowrap;"><input type="checkbox" class="field-new-tab" ${item.new_tab === 'yes' ? 'checked' : ''} style="width:16px;height:16px;">تب جدید</label>`);
          } else if (name === 'socials') {
            $item.append(`<textarea type="text" placeholder="آیکون" class="field-icon">${item.icon || ''}</textarea>`);
            $item.append(`<input type="text" placeholder="نام" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'site_menu') {
            // هندل درگ برای آیتم‌های سطح ۱
            $item.prepend('<span class="drag-handle" style="cursor:grab;font-size:20px;margin-left:8px;color:var(--text-muted);opacity:0.5;transition:opacity 0.2s;">☰</span>');

            // طراحی UI برای مگا منو دو سطحی
            const $menuSection = $('<div class="megamenu-item" style="background:linear-gradient(135deg, #f0f4ff 0%, #e8f0ff 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #4285f4;box-shadow:0 4px 12px rgba(66,133,244,0.15);width:100%;"></div>');

            // هدر آیتم منو اصلی
            $menuSection.append(`
              <div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(66,133,244,0.3);">
                <span style="font-size:22px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M10 6a4 4 0 1 0-8 0a4 4 0 0 0 8 0Zm0 12a4 4 0 1 0-8 0a4 4 0 0 0 8 0ZM22 6a4 4 0 1 0-8 0a4 4 0 0 0 8 0Zm0 12a4 4 0 1 0-8 0a4 4 0 0 0 8 0Z" /></svg></span>
                <h4 style="margin:0;color:#1a73e8;font-size:15px;font-weight:600;">آیتم منوی اصلی (سطح 1)</h4>
              </div>
            `);

            // ردیف اول: نام، لینک و آیکون
            $menuSection.append(`
              <div style="display:grid;grid-template-columns:1fr 1fr 120px;gap:12px;margin-bottom:16px;">
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">🏷️</span>
                    نام منو:
                  </label>
                  <input type="text" placeholder="مثال: لپ‌تاپ" class="field-name" value="${item.name || ''}" style="width:100%;padding:10px 12px;border:1px solid #4285f4;border-radius:6px;font-size:14px;background:#fff;">
                </div>
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">🔗</span>
                    لینک:
                  </label>
                  <input type="text" placeholder="/category/laptop" class="field-link" value="${item.link || ''}" style="width:100%;padding:10px 12px;border:1px solid #4285f4;border-radius:6px;font-size:14px;background:#fff;">
                </div>
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1a73e8;">
                    <span style="font-size:16px;margin-left:6px;">✨</span>
                    آیکون:
                  </label>
                  <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #4285f4;border-radius:6px;font-size:11px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                </div>
              </div>
            `);

            // بخش زیرمنوها (children)
            const children = item.children || [];
            const $childrenSection = $('<div class="megamenu-children" style="background:rgba(255,255,255,0.6);padding:14px;border-radius:8px;margin-top:10px;"></div>');

            $childrenSection.append(`
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <div style="display:flex;align-items:center;">
                  <span style="font-size:18px;margin-left:6px;">📂</span>
                  <h5 style="margin:0;color:#5f6368;font-size:14px;font-weight:600;">زیرمنوها (سطح 2)</h5>
                  <span style="margin-right:8px;background:#e8f0fe;color:#1967d2;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">${children.length} مورد</span>
                </div>
                <button type="button" class="button button-primary add-submenu-btn" data-parent-id="${item._uuid}" style="padding:6px 14px;font-size:12px;">
                  ➕ افزودن زیرمنو
                </button>
              </div>
            `);

            const $childrenList = $('<div class="children-list" style="display:flex;flex-direction:column;gap:8px;"></div>');

            children.forEach((child, childIdx) => {
              const childUuid = child._uuid || 'child-' + childIdx;
              const grandchildren = child.children || [];
              const $childItem = $(`
                <div class="submenu-item" data-child-id="${childUuid}" style="background:#fff;padding:14px;border-radius:8px;border:1px solid #dadce0;transition:all 0.2s;margin-bottom:4px;">
                  <div style="display:grid;grid-template-columns:30px 1fr 1fr 40px;gap:10px;align-items:center;">
                    <span style="color:#5f6368;font-size:18px;cursor:move;" class="drag-handle-submenu">⋮⋮</span>
                    <input type="text" placeholder="نام زیرمنو" class="field-child-name" value="${child.name || ''}" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                    <input type="text" placeholder="لینک زیرمنو" class="field-child-link" value="${child.link || ''}" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                    <button type="button" class="button remove-submenu-btn" style="padding:4px 8px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:18px;line-height:1;">×</button>
                  </div>
                  <div class="grandchildren-section" style="background:rgba(245,245,245,0.8);padding:12px;border-radius:6px;margin-top:10px;border:1px dashed #c0c0c0;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                      <div style="display:flex;align-items:center;">
                        <span style="font-size:14px;margin-left:4px;">📁</span>
                        <h6 style="margin:0;color:#7b7b7b;font-size:13px;font-weight:600;">زیرمنوها (سطح 3)</h6>
                        <span class="grandchild-count" style="margin-right:6px;background:#e8e8e8;color:#555;padding:1px 6px;border-radius:10px;font-size:10px;font-weight:600;">${grandchildren.length} مورد</span>
                      </div>
                      <button type="button" class="button add-grandchild-btn" data-child-id="${childUuid}" style="padding:4px 10px;font-size:11px;background:#7c4dff;color:#fff;border:none;border-radius:4px;cursor:pointer;">
                        ➕ افزودن سطح ۳
                      </button>
                    </div>
                    <div class="grandchildren-list" style="display:flex;flex-direction:column;gap:6px;"></div>
                  </div>
                </div>
              `);

              // رندر آیتم‌های سطح ۳
              const $grandchildrenList = $childItem.find('.grandchildren-list');
              grandchildren.forEach((gc, gcIdx) => {
                const gcUuid = gc._uuid || 'grandchild-' + gcIdx;
                const $gcItem = $(`
                  <div class="grandchild-item" data-grandchild-id="${gcUuid}" style="background:#fff;padding:8px 10px;border-radius:4px;border:1px solid #e0e0e0;display:grid;grid-template-columns:1fr 1fr 32px;gap:8px;align-items:center;">
                    <input type="text" placeholder="نام" class="field-grandchild-name" value="${gc.name || ''}" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <input type="text" placeholder="لینک" class="field-grandchild-link" value="${gc.link || ''}" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <button type="button" class="button remove-grandchild-btn" style="padding:2px 6px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:14px;line-height:1;">×</button>
                  </div>
                `);
                $gcItem.find('.remove-grandchild-btn').on('click', function () {
                  $gcItem.fadeOut(200, function () { $gcItem.remove(); save(); });
                });
                $grandchildrenList.append($gcItem);
              });

              // رویداد افزودن آیتم سطح ۳
              $childItem.find('.add-grandchild-btn').on('click', function () {
                const newGcId = 'grandchild-' + Date.now();
                const $newGc = $(`
                  <div class="grandchild-item" data-grandchild-id="${newGcId}" style="background:#fff;padding:8px 10px;border-radius:4px;border:1px solid #e0e0e0;display:grid;grid-template-columns:1fr 1fr 32px;gap:8px;align-items:center;">
                    <input type="text" placeholder="نام" class="field-grandchild-name" value="" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <input type="text" placeholder="لینک" class="field-grandchild-link" value="" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <button type="button" class="button remove-grandchild-btn" style="padding:2px 6px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:14px;line-height:1;">×</button>
                  </div>
                `);
                $newGc.find('.remove-grandchild-btn').on('click', function () {
                  $newGc.fadeOut(200, function () { $newGc.remove(); save(); });
                });
                $grandchildrenList.append($newGc);
                const gcCount = $grandchildrenList.find('.grandchild-item').length;
                $childItem.find('.grandchild-count').text(gcCount + ' مورد');
                save();
              });

              $childItem.find('.remove-submenu-btn').on('click', function () {
                $childItem.fadeOut(200, function () {
                  $childItem.remove();
                  save();
                });
              });

              $childrenList.append($childItem);
            });

            if ($.fn.sortable) $childrenList.sortable({
              handle: '.drag-handle-submenu',
              axis: 'y',
              update: function () {
                save();
              }
            });

            $childrenSection.append($childrenList);
            $menuSection.append($childrenSection);
            $item.append($menuSection);

            // رویداد افزودن زیرمنو
            $item.find('.add-submenu-btn').on('click', function () {
              const parentId = $(this).data('parent-id');
              const $list = $item.find('.children-list');
              const newChildId = 'child-' + Date.now();

              const $newChild = $(`
                <div class="submenu-item" data-child-id="${newChildId}" style="background:#fff;padding:14px;border-radius:8px;border:1px solid #dadce0;transition:all 0.2s;margin-bottom:4px;">
                  <div style="display:grid;grid-template-columns:30px 1fr 1fr 40px;gap:10px;align-items:center;">
                    <span style="color:#5f6368;font-size:18px;cursor:move;" class="drag-handle-submenu">⋮⋮</span>
                    <input type="text" placeholder="نام زیرمنو" class="field-child-name" value="" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                    <input type="text" placeholder="لینک زیرمنو" class="field-child-link" value="" style="padding:8px 10px;border:1px solid #dadce0;border-radius:4px;font-size:13px;">
                    <button type="button" class="button remove-submenu-btn" style="padding:4px 8px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:18px;line-height:1;">×</button>
                  </div>
                  <div class="grandchildren-section" style="background:rgba(245,245,245,0.8);padding:12px;border-radius:6px;margin-top:10px;border:1px dashed #c0c0c0;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                      <div style="display:flex;align-items:center;">
                        <span style="font-size:14px;margin-left:4px;">📁</span>
                        <h6 style="margin:0;color:#7b7b7b;font-size:13px;font-weight:600;">زیرمنوها (سطح 3)</h6>
                        <span class="grandchild-count" style="margin-right:6px;background:#e8e8e8;color:#555;padding:1px 6px;border-radius:10px;font-size:10px;font-weight:600;">0 مورد</span>
                      </div>
                      <button type="button" class="button add-grandchild-btn" data-child-id="${newChildId}" style="padding:4px 10px;font-size:11px;background:#7c4dff;color:#fff;border:none;border-radius:4px;cursor:pointer;">
                        ➕ افزودن سطح ۳
                      </button>
                    </div>
                    <div class="grandchildren-list" style="display:flex;flex-direction:column;gap:6px;"></div>
                  </div>
                </div>
              `);

              // رویداد افزودن آیتم سطح ۳ برای آیتم جدید
              $newChild.find('.add-grandchild-btn').on('click', function () {
                const newGcId = 'grandchild-' + Date.now();
                const $gcList = $newChild.find('.grandchildren-list');
                const $newGc = $(`
                  <div class="grandchild-item" data-grandchild-id="${newGcId}" style="background:#fff;padding:8px 10px;border-radius:4px;border:1px solid #e0e0e0;display:grid;grid-template-columns:1fr 1fr 32px;gap:8px;align-items:center;">
                    <input type="text" placeholder="نام" class="field-grandchild-name" value="" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <input type="text" placeholder="لینک" class="field-grandchild-link" value="" style="padding:6px 8px;border:1px solid #e0e0e0;border-radius:4px;font-size:12px;">
                    <button type="button" class="button remove-grandchild-btn" style="padding:2px 6px;background:#ea4335;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:14px;line-height:1;">×</button>
                  </div>
                `);
                $newGc.find('.remove-grandchild-btn').on('click', function () {
                  $newGc.fadeOut(200, function () { $newGc.remove(); save(); });
                });
                $gcList.append($newGc);
                const gcCount = $gcList.find('.grandchild-item').length;
                $newChild.find('.grandchild-count').text(gcCount + ' مورد');
                save();
              });

              $newChild.find('.remove-submenu-btn').on('click', function () {
                $newChild.fadeOut(200, function () {
                  $newChild.remove();
                  save();
                });
              });

              $list.append($newChild);

              // به‌روزرسانی شمارنده
              const count = $list.find('.submenu-item').length;
              $item.find('.megamenu-children > div:first-child span[style*="background:#e8f0fe"]').text(count + ' مورد');

              save();
            });

          } else if (name === 'navbar_menu') {
            $item.append(`<input type="text" placeholder="نام منو" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
            $item.append(`<label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;white-space:nowrap;margin-right:8px;"><input type="checkbox" class="field-new-tab" ${item.new_tab === 'yes' ? 'checked' : ''} style="width:16px;height:16px;">باز شدن در تب جدید</label>`);

            // بخش زیرمنوها (دراپ‌داون سطح ۲)
            const $navSub = $('<div class="nav-sub-wrap" style="width:100%;margin-top:10px;padding:12px;background:#fbfbfc;border:1px dashed #c3c4c7;border-radius:8px;"></div>');
            $navSub.append('<div style="font-size:12px;font-weight:600;color:#50575e;margin-bottom:8px;">زیرمنوها (دراپ‌داون):</div>');
            const $navChildren = $('<div class="nav-children-cont"></div>');
            (Array.isArray(item.children) ? item.children : []).forEach(ch => {
              $navChildren.append(window.__navRenderChild(ch));
            });
            $navSub.append($navChildren);
            $navSub.append('<button type="button" class="button nav-add-child" style="margin-top:4px;">+ افزودن زیرمنو</button>');
            $item.append($navSub);
          } else if (name === 'job_positions_list') {
            $item.append(`<input type="text" class="field-title" placeholder="عنوان موقعیت شغلی" value="${item.title || ''}" style="width:100%;margin-bottom:10px;">`);
            $item.append(`<textarea class="field-description" placeholder="توضیحات موقعیت شغلی" style="width:100%;margin-bottom:10px;min-height:100px;">${item.description || ''}</textarea>`);
            const jobType = item.job_type || 'تمام وقت';
            $item.append(`
              <select class="field-job-type" style="margin-bottom:10px;width:200px;">
                <option value="تمام وقت"${jobType === 'تمام وقت' ? ' selected' : ''}>تمام وقت</option>
                <option value="پاره وقت"${jobType === 'پاره وقت' ? ' selected' : ''}>پاره وقت</option>
                <option value="دورکاری"${jobType === 'دورکاری' ? ' selected' : ''}>دورکاری</option>
                <option value="کارآموزی"${jobType === 'کارآموزی' ? ' selected' : ''}>کارآموزی</option>
              </select>
            `);
            $item.append(`<input type="text" class="field-skills" placeholder="مهارت‌ها (با کاما جدا کنید)" value="${item.skills || ''}" style="width:100%;">`);
          } else if (name === 'faq_list') {
            $item.append(`<input type="text" class="field-question" placeholder="سوال" value="${item.question || ''}" style="width:100%;margin-bottom:10px;">`);
            $item.append(`<textarea class="field-answer" placeholder="پاسخ" style="width:100%;margin-bottom:10px;min-height:100px;">${item.answer || ''}</textarea>`);
          } else if (name === 'site_badges') {
            $item.append(`<textarea placeholder="کد HTML" class="field-html">${item.html || ''}</textarea>`);
          } else if (name === 'footer_menu_1' || name === 'footer_menu_2' || name === 'gold_header_links') {
            $item.append(`<input type="text" placeholder="عنوان" class="field-name" value="${item.name || ''}">`);
            $item.append(`<input type="text" placeholder="لینک" class="field-link" value="${item.link || ''}">`);
          } else if (name === 'home_sections') {
            $item.append(`<label>نوع سکشن:</label>`);
            const typeOptions = [
              { value: 'product_categories', text: 'دسته‌بندی محصولات' },
              { value: 'products', text: 'سکشن محصولات' },
              { value: 'special_products', text: 'محصولات فروش ویژه' },
              { value: 'site_badges', text: 'نمادها' },
              { value: 'blog_posts', text: 'سکشن پست‌های بلاگ' },
              { value: 'custom_html', text: 'HTML سفارشی' },
              { value: 'site_description_box', text: 'باکس توضیحات سایت' },
              { value: 'banners', text: 'سکشن بنر' },
              { value: 'slider', text: 'سکشن اسلایدر' },
              { value: 'logo_slider', text: 'اسلایدر لوگوها' },
              { value: 'spacer', text: 'فاصله' },
              { value: 'brick_products', text: 'محصولات آجری' },
              { value: 'banner_slider', text: 'اسلایدر بنر' },
              { value: 'currency_price', text: 'نمایش قیمت ارز' },
              { value: 'hero', text: 'هیرو (Hero)' },
              { value: 'card_swap', text: 'سواپ کارت‌ها (Card Swap)' },
              { value: 'bento_features', text: 'بنتو گرید قابلیت‌ها (Bento)' },
              { value: 'category_nav', text: 'ناوبری دسته‌بندی (Category Nav)' },
              { value: 'gold_banner', text: '— طلا و جواهر: بنر' },
              { value: 'gold_product_carousel', text: '— طلا و جواهر: کاروسل محصول' },
              { value: 'gold_categories', text: '— طلا و جواهر: دسته‌بندی' },
              { value: 'eng_hero', text: '— مهندسان: هیرو' },
              { value: 'eng_clients', text: '— مهندسان: نوار مشتریان' },
              { value: 'eng_services', text: '— مهندسان: خدمات (تب‌دار)' },
              { value: 'eng_stats', text: '— مهندسان: نوار آمار' },
              { value: 'eng_projects', text: '— مهندسان: پروژه‌ها (فیلتردار)' },
              { value: 'eng_timeline', text: '— مهندسان: خط زمانی' },
              { value: 'eng_certs', text: '— مهندسان: گواهینامه‌ها' },
              { value: 'eng_team', text: '— مهندسان: تیم' },
              { value: 'eng_testimonials', text: '— مهندسان: نظرات' },
              { value: 'eng_blog', text: '— مهندسان: بلاگ' },
              { value: 'eng_contact', text: '— مهندسان: تماس' },
              { value: 'pln_hero', text: '✦ پلان: هیرو معماری' },
              { value: 'pln_benefits', text: '✦ پلان: مزایا' },
              { value: 'pln_testimonials', text: '✦ پلان: دیدگاه مشتریان' },
              { value: 'pln_customers', text: '✦ پلان: مشتریان' },
              { value: 'pln_history', text: '✦ پلان: تاریخچه' },
              { value: 'pln_portfolio', text: '✦ پلان: نمونه‌کارها' },
              { value: 'pln_cta', text: '✦ پلان: فراخوان (CTA)' },
              { value: 'special_sale_carousel', text: 'کاروسل فروش ویژه (Special Sale)' },
              { value: 'recommended_panels', text: 'سه‌پنل محصولات پیشنهادی (Recommended Panels)' }
            ];

            // افزودن ویجت‌های سفارشی ساخته‌شده در «استودیوی توسعه»
            (window.BoomCustomWidgets || []).forEach(function (w) {
              if (w && w.key) {
                typeOptions.push({ value: 'cw:' + w.key, text: '◆ ' + (w.label || w.key) });
              }
            });

            const typeSelect = $('<select class="field-section-type"></select>');
            typeOptions.forEach(opt => {
              typeSelect.append(`<option value="${opt.value}"${item.type === opt.value ? ' selected' : ''}>${opt.text}</option>`);
            });
            $item.append(typeSelect);

            if (item.type === 'products') {
              // ساختار بهبود یافته برای سکشن محصولات
              const $productsSection = $('<div style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(156,39,176,0.15);"></div>');

              $productsSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 22c-.818 0-1.6-.33-3.163-.99C4.946 19.366 3 18.543 3 17.16V7m9 15c.818 0 1.6-.33 3.163-.99C19.054 19.366 21 18.543 21 17.16V7m-9 15V11.355M8.326 9.691L5.405 8.278C3.802 7.502 3 7.114 3 6.5s.802-1.002 2.405-1.778l2.92-1.413C10.13 2.436 11.03 2 12 2s1.871.436 3.674 1.309l2.921 1.413C20.198 5.498 21 5.886 21 6.5s-.802 1.002-2.405 1.778l-2.92 1.413C13.87 10.564 12.97 11 12 11s-1.871-.436-3.674-1.309M6 12l2 1m9-9L7 9" /></svg></span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات سکشن محصولات</h4>
              </div>`);

              // ردیف اول: آیکون و نام و لینک
              $productsSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5" d="M3 12c4.5 0 9-4.5 9-9c0 4.5 4.5 9 9 9c-4.5 0-9 4.5-9 9c0-4.5-4.5-9-9-9Zm-1 7.5c.833 0 2.5-1.667 2.5-2.5c0 .833 1.667 2.5 2.5 2.5c-.833 0-2.5 1.667-2.5 2.5c0-.833-1.667-2.5-2.5-2.5ZM16 5c1 0 3-2 3-3c0 1 2 3 3 3c-1 0-3 2-3 3c0-1-2-3-3-3Z" /></svg></span>
                      آیکون:
                    </label>
                    <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #e0fae2;border-radius:6px;font-size:12px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                      نام سکشن:
                    </label>
                    <input type="text" placeholder="مثال: محصولات پرفروش" class="field-name" value="${item.name || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-link" value="${item.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف دوم: جستجوی دسته‌بندی
              const selectedCats = item.product_cats || [];
              const $catList = $('<div class="field-product-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              selectedCats.forEach(cat => {
                $catList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });

              $productsSection.append(`
                <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;position:relative;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                    دسته‌بندی محصولات:
                  </label>
                  <input type="text" class="field-product-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #e0fae2;border-radius:8px;font-size:13px;background:#fff;transition:all 0.3s;">
                  <div class="product-cat-search-results" style="position:relative;z-index:1000;"></div>
                </div>
              `);
              $productsSection.find('.field-product-cat-search').after($catList);

              // ردیف سوم: تعداد و ترتیب نمایش
              $productsSection.append(`
                <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                  <div>
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M3 6h10M3 12h10M3 18h10" /><path stroke-linejoin="round" d="M18 15h1.5c.279 0 .418 0 .534.023a1.2 1.2 0 0 1 .943.943c.023.116.023.255.023.534s0 .418-.023.534a1.2 1.2 0 0 1-.943.943C19.918 18 19.78 18 19.5 18s-.418 0-.534.023a1.2 1.2 0 0 0-.943.943C18 19.082 18 19.22 18 19.5v.9c0 .283 0 .424.088.512s.23.088.512.088H21M18 3h1.2a.3.3 0 0 1 .3.3V9m0 0H18m1.5 0H21" /></g></svg></span>
                      تعداد محصول:
                    </label>
                    <input type="number" min="1" max="30" class="field-product-count" placeholder="تعداد" value="${item.product_count || 4}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div>
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="round" stroke-width="1.5" d="M3.5 9.5v9c0 .466 0 .699.076.883a1 1 0 0 0 .541.54C4.301 20 4.534 20 5 20s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-9c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C5.699 8 5.466 8 5 8s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7-4v13c0 .465 0 .698.076.882a1 1 0 0 0 .541.541c.184.077.417.077.883.077s.699 0 .883-.077a1 1 0 0 0 .54-.54c.077-.185.077-.418.077-.883v-13c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C12.699 4 12.466 4 12 4s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7 7v6c0 .466 0 .699.076.883a1 1 0 0 0 .541.54c.184.077.417.077.883.077s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-6c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C19.699 11 19.466 11 19 11s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Z" /></svg></span>
                      ترتیب نمایش:
                    </label>
                    <select class="field-product-sort" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;cursor:pointer;">
                      <option value="popularity"${item.product_sort === 'popularity' ? ' selected' : ''}>محبوب‌ترین</option>
                      <option value="sales"${item.product_sort === 'sales' ? ' selected' : ''}>پرفروش‌ترین</option>
                      <option value="latest"${item.product_sort === 'latest' ? ' selected' : ''}>جدیدترین</option>
                    </select>
                  </div>
                </div>
              `);

              // افزودن checkbox مخفی کردن محصولات ناموجود
              const hideOutOfStockChecked = item.hide_out_of_stock === 'yes' ? ' checked' : '';
              $productsSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;margin-top:12px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-hide-out-of-stock"${hideOutOfStockChecked} style="width:20px;height:20px;cursor:pointer;accent-color:#4CAF50;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        مخفی کردن محصولات ناموجود
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، فقط محصولات موجود نمایش داده می‌شوند</div>
                    </div>
                  </label>
                </div>
              `);

              // افزودن checkbox حرکت خودکار اسلایدر
              const autoSlideChecked = item.auto_slide === 'yes' ? ' checked' : '';
              const autoSlideSpeed = item.auto_slide_speed || 3000;
              $productsSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;margin-top:12px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-auto-slide"${autoSlideChecked} style="width:20px;height:20px;cursor:pointer;accent-color:#4CAF50;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        🎬 حرکت خودکار (Auto-slide)
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، اسلایدر محصولات به‌صورت خودکار به سمت چپ حرکت می‌کند و loop می‌شود</div>
                    </div>
                  </label>
                  <div style="margin-top:10px;padding-top:10px;border-top:1px dashed #c8e6c9;display:flex;align-items:center;gap:8px;">
                    <label style="font-size:12px;color:#444;font-weight:600;">⏱️ فاصله بین اسلایدها (میلی‌ثانیه):</label>
                    <input type="number" min="500" max="20000" step="100" class="field-auto-slide-speed" value="${autoSlideSpeed}" style="width:110px;padding:6px 10px;border:1px solid #c8e6c9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              $item.append($productsSection);
            } else if (item.type === 'special_products') {
              // ساختار بهبود یافته برای محصولات فروش ویژه
              const $specialSection = $('<div style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(255,193,7,0.2);"></div>');

              $specialSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m5.226 11.33l6.998-8.983c.547-.703 1.573-.266 1.573.67V9.97c0 .56.402 1.015.899 1.015H18.1c.773 0 1.185 1.03.674 1.686l-6.998 8.983c-.547.702-1.573.265-1.573-.671V14.03c0-.56-.403-1.015-.899-1.015H5.9c-.773 0-1.185-1.03-.674-1.686" /></svg></span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات محصولات فروش ویژه</h4>
              </div>`);

              // ردیف اول: آیکون، نام و تعداد
              $specialSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr 160px 180px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5" d="M3 12c4.5 0 9-4.5 9-9c0 4.5 4.5 9 9 9c-4.5 0-9 4.5-9 9c0-4.5-4.5-9-9-9Zm-1 7.5c.833 0 2.5-1.667 2.5-2.5c0 .833 1.667 2.5 2.5 2.5c-.833 0-2.5 1.667-2.5 2.5c0-.833-1.667-2.5-2.5-2.5ZM16 5c1 0 3-2 3-3c0 1 2 3 3 3c-1 0-3 2-3 3c0-1-2-3-3-3Z" /></svg></span>
                      آیکون:
                    </label>
                    <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #e0fae2;border-radius:6px;font-size:12px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                  </div>
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M12 17c-1.674 0-3.13 1.265-3.882 3.131c-.36.892.156 1.869.84 1.869h6.083c.685 0 1.2-.977.841-1.869C15.13 18.265 13.674 17 12 17Z" /><path stroke-linejoin="round" d="M18.5 5h1.202c1.201 0 1.801 0 2.115.377c.313.378.183.944-.078 2.077l-.39 1.7C20.76 11.708 18.61 13.608 16 14M5.5 5H4.298c-1.201 0-1.802 0-2.115.377c-.313.378-.183.944.078 2.077l.39 1.7C3.24 11.708 5.39 13.608 8 14" /><path d="M12 17c3.02 0 5.565-4.662 6.33-11.01c.211-1.754.317-2.632-.243-3.311S16.622 2 14.813 2H9.187c-1.81 0-2.714 0-3.274.679S5.46 4.236 5.67 5.991C6.435 12.338 8.98 17 12 17Z" /></g></svg></span>
                      نام سکشن:
                    </label>
                    <input type="text" placeholder="مثال: پیشنهادهای شگفت‌انگیز" class="field-name" value="${item.name || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M3 6h10M3 12h10M3 18h10" /><path stroke-linejoin="round" d="M18 15h1.5c.279 0 .418 0 .534.023a1.2 1.2 0 0 1 .943.943c.023.116.023.255.023.534s0 .418-.023.534a1.2 1.2 0 0 1-.943.943C19.918 18 19.78 18 19.5 18s-.418 0-.534.023a1.2 1.2 0 0 0-.943.943C18 19.082 18 19.22 18 19.5v.9c0 .283 0 .424.088.512s.23.088.512.088H21M18 3h1.2a.3.3 0 0 1 .3.3V9m0 0H18m1.5 0H21" /></g></svg></span>
                      تعداد محصول:
                    </label>
                    <input type="number" min="1" max="30" class="field-product-count" placeholder="تعداد" value="${item.product_count || 4}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="square" stroke-linejoin="round" stroke-width="1.5" d="M3.5 9.5v9c0 .466 0 .699.076.883a1 1 0 0 0 .541.54C4.301 20 4.534 20 5 20s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-9c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C5.699 8 5.466 8 5 8s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7-4v13c0 .465 0 .698.076.882a1 1 0 0 0 .541.541c.184.077.417.077.883.077s.699 0 .883-.077a1 1 0 0 0 .54-.54c.077-.185.077-.418.077-.883v-13c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C12.699 4 12.466 4 12 4s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Zm7 7v6c0 .466 0 .699.076.883a1 1 0 0 0 .541.54c.184.077.417.077.883.077s.699 0 .883-.076a1 1 0 0 0 .54-.541c.077-.184.077-.417.077-.883v-6c0-.466 0-.699-.076-.883a1 1 0 0 0-.541-.54C19.699 11 19.466 11 19 11s-.699 0-.883.076a1 1 0 0 0-.54.541c-.077.184-.077.417-.077.883Z" /></svg></span>
                      ترتیب نمایش:
                    </label>
                    <select class="field-product-sort" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;cursor:pointer;">
                      <option value="latest"${!item.product_sort || item.product_sort === 'latest' ? ' selected' : ''}>جدیدترین</option>
                      <option value="popularity"${item.product_sort === 'popularity' ? ' selected' : ''}>محبوب‌ترین</option>
                      <option value="sales"${item.product_sort === 'sales' ? ' selected' : ''}>پرفروش‌ترین</option>
                      <option value="price_low"${item.product_sort === 'price_low' ? ' selected' : ''}>ارزان‌ترین</option>
                      <option value="price_high"${item.product_sort === 'price_high' ? ' selected' : ''}>گران‌ترین</option>
                      <option value="rating"${item.product_sort === 'rating' ? ' selected' : ''}>بیشترین امتیاز</option>
                      <option value="discount"${item.product_sort === 'discount' ? ' selected' : ''}>بیشترین تخفیف</option>
                      <option value="rand"${item.product_sort === 'rand' ? ' selected' : ''}>تصادفی</option>
                    </select>
                  </div>
                </div>
              `);

              // راهنما
              $specialSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:10px 12px;border-radius:8px;display:flex;align-items:center;gap:8px;margin-bottom:12px;">
                  <span style="font-size:18px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M12 7a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Zm-3 6a3 3 0 1 0 6 0" /><path stroke-linecap="round" d="M5 13h14m-7-6V2m0 18v2m3-3l2 1.5M9 19l-2 1.5" /></g></svg></span>
                  <p style="margin:0;font-size:12px;color:#000000;opacity:0.9;">محصولاتی که تخفیف دارند نمایش داده می‌شوند</p>
                </div>
              `);

              // فیلد لینک دکمه مشاهده همه
              $specialSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></span>
                    لینک دکمه مشاهده همه:
                  </label>
                  <input type="url" placeholder="https://..." class="field-view-all-link" value="${item.view_all_link || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                </div>
              `);

              // افزودن checkbox مخفی کردن محصولات ناموجود
              const hideOutOfStockCheckedSpecial = item.hide_out_of_stock === 'yes' ? ' checked' : '';
              $specialSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-hide-out-of-stock"${hideOutOfStockCheckedSpecial} style="width:20px;height:20px;cursor:pointer;accent-color:#4CAF50;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        مخفی کردن محصولات ناموجود
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، فقط محصولات موجود نمایش داده می‌شوند</div>
                    </div>
                  </label>
                </div>
              `);

              $item.append($specialSection);
            } else if (item.type === 'blog_posts') {
              // ساختار بهبود یافته برای پست‌های بلاگ
              const $blogSection = $('<div style="background:linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #81c784;box-shadow:0 2px 8px rgba(76,175,80,0.15);"></div>');

              $blogSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M2.5 12c0-4.478 0-6.718 1.391-8.109S7.521 2.5 12 2.5c4.478 0 6.718 0 8.109 1.391S21.5 7.521 21.5 12c0 4.478 0 6.718-1.391 8.109S16.479 21.5 12 21.5c-4.478 0-6.718 0-8.109-1.391S2.5 16.479 2.5 12Z" /><path stroke-linecap="round" d="M10 10h1m-1 5h4" /><path d="M14.958 11.462v-.953c0-1.873 0-2.81-.476-3.466c-.9-1.243-2.649-1.029-4.003-1.029S7.376 5.8 6.475 7.044C6 7.7 6 8.635 6 10.508v2.497c0 2.354 0 3.531.729 4.263S8.63 18 10.977 18h3.71c2.598 0 3.637-1.828 3.226-4.431c-.245-1.55-1.582-2.107-2.955-2.107Z" /></g></svg></span>
                <h4 style="margin:0;color:#2e7d32;font-size:15px;font-weight:600;">تنظیمات سکشن بلاگ</h4>
              </div>`);

              // جستجوی دسته‌بندی بلاگ
              const selectedBlogCats = item.blog_cats || [];
              const $blogCatList = $('<div class="field-blog-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              selectedBlogCats.forEach(cat => {
                $blogCatList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });

              $blogSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;position:relative;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#2e7d32;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                    دسته‌بندی بلاگ:
                  </label>
                  <input type="text" class="field-blog-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #81c784;border-radius:8px;font-size:13px;background:#fff;transition:all 0.3s;">
                  <div class="blog-cat-search-results" style="position:relative;z-index:1000;"></div>
                  <p style="margin:8px 0 0 0;font-size:12px;color:#2e7d32;opacity:0.8;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5"><path d="M12 7a6 6 0 0 0-6 6h12a6 6 0 0 0-6-6Zm-3 6a3 3 0 1 0 6 0" /><path stroke-linecap="round" d="M5 13h14m-7-6V2m0 18v2m3-3l2 1.5M9 19l-2 1.5" /></g></svg> می‌توانید چند دسته‌بندی انتخاب کنید</p>
                </div>
              `);
              $blogSection.find('.field-blog-cat-search').after($blogCatList);

              $item.append($blogSection);
            } else if (item.type === 'banners') {
              $item.append(`<input type="number" min="1" max="10" class="field-banner-count" placeholder="تعداد بنر" value="${item.banner_count || 1}" style="width:70px;">`);


              const currentStyle = item.banner_style || 'style1';
              $item.append(`
                <div style="margin:10px 0;">
                  <label style="display:inline-block;width:80px;font-size:12px;">استایل:</label>
                  <select class="field-banner-style" style="width:150px;">
                    <option value="style1"${currentStyle === 'style1' ? ' selected' : ''}>استایل 1</option>
                    <option value="style2"${currentStyle === 'style2' ? ' selected' : ''}>استایل 2</option>
                  </select>
                </div>
              `);

              $item.append(`
                <div style="margin:10px 0;">
                  <label style="display:inline-flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;">
                    <input type="checkbox" class="field-banner-new-tab" ${item.banner_new_tab === 'yes' ? 'checked' : ''} style="width:18px;height:18px;">
                    باز کردن لینک بنرها در تب جدید
                  </label>
                </div>
              `);


              let banners = item.banners || [];
              const bannerCount = parseInt(item.banner_count) || 1;


              while (banners.length < bannerCount) {
                banners.push({ desktop_image: '', mobile_image: '', alt: '', link: '', new_tab: 'no' });
              }
              while (banners.length > bannerCount) {
                banners.pop();
              }

              const $bannersContainer = $('<div class="banners-container" style="width:100%;"></div>');
              banners.forEach((banner, bannerIdx) => {
                const $bannerItem = $('<div class="banner-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e1e8ed;box-shadow:0 2px 8px rgba(0,0,0,0.08);transition:all 0.3s ease;"></div>');

                // Header بنر با آیکون
                $bannerItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.6);">
                  <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                  <h4 style="margin:0;color:#2c3e50;font-size:15px;font-weight:600;">بنر شماره ${bannerIdx + 1}</h4>
                </div>`);

                // بخش تصویر دسکتاپ
                const desktopPreview = banner.desktop_image
                  ? `<div style="margin-top:8px;"><img src="${banner.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                  : '';
                $bannerItem.append(`
                  <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                      تصویر دسکتاپ:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-banner-desktop-image" value="${banner.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-banner" data-type="desktop" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب تصویر
                      </button>
                    </div>
                    ${desktopPreview}
                  </div>
                `);

                // بخش تصویر موبایل
                const mobilePreview = banner.mobile_image
                  ? `<div style="margin-top:8px;"><img src="${banner.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                  : '';
                $bannerItem.append(`
                  <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                      تصویر موبایل:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر موبایل" class="field-banner-mobile-image" value="${banner.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-banner" data-type="mobile" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب تصویر
                      </button>
                    </div>
                    ${mobilePreview}
                  </div>
                `);

                // بخش متن جایگزین (alt) — اختیاری
                $bannerItem.append(`
                  <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 5h16M4 12h10M4 19h7" /></svg></span>
                      متن جایگزین تصویر (alt) — اختیاری:
                    </label>
                    <input type="text" placeholder="مثلاً: بنر تخفیف لوازم جانبی" class="field-banner-alt" value="${(banner.alt || '').replace(/"/g, '&quot;')}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                    <p style="margin:6px 0 0;font-size:11px;color:#7f8c8d;">برای سئو و دسترس‌پذیری. اگر خالی بماند مشکلی ایجاد نمی‌شود.</p>
                  </div>
                `);

                // بخش لینک
                $bannerItem.append(`
                  <div style="background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک بنر:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-banner-link" value="${(banner.link || '').replace(/"/g, '&quot;')}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                    <label style="display:inline-flex;align-items:center;gap:8px;margin-top:10px;font-size:12px;cursor:pointer;color:#34495e;">
                      <input type="checkbox" class="field-banner-new-tab-single" ${banner.new_tab === 'yes' ? 'checked' : ''} style="width:16px;height:16px;">
                      این لینک در تب جدید باز شود
                    </label>
                    <p style="margin:6px 0 0;font-size:11px;color:#7f8c8d;">اگر خاموش باشد و لینک داخلی باشد، بدون بارگذاری مجدد (SPA) باز می‌شود.</p>
                  </div>
                `);

                $bannersContainer.append($bannerItem);
              });
              $item.append($bannersContainer);
            } else if (item.type === 'slider') {

              $item.append(`<label>استایل اسلایدر:</label>`);
              const styleOptions = [
                { value: 'style1', text: 'استایل یک' },
                { value: 'style2', text: 'استایل دو' },
                { value: 'style3', text: 'استایل سه' },
                { value: 'style4', text: 'استایل چهار' },
                { value: 'style5', text: 'استایل پنج (تمام عرض دسکتاپ)' },
              ];
              const styleSelect = $('<select class="field-slider-style"></select>');
              styleOptions.forEach(opt => {
                styleSelect.append(`<option value="${opt.value}"${item.slider_style === opt.value ? ' selected' : ''}>${opt.text}</option>`);
              });
              $item.append(styleSelect);


              $item.append(`<input type="number" min="1" max="10" class="field-slider-count" placeholder="تعداد اسلاید" value="${item.slider_count || 1}" style="width:70px;">`);

              $item.append(`
                <div style="margin:10px 0;">
                  <label style="display:inline-flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;">
                    <input type="checkbox" class="field-slider-new-tab" ${item.slider_new_tab === 'yes' ? 'checked' : ''} style="width:18px;height:18px;">
                    باز کردن لینک اسلایدها در تب جدید
                  </label>
                </div>
              `);


              let slides = item.slides || [];
              const slideCount = parseInt(item.slider_count) || 1;
              const currentStyle = item.slider_style || 'style1';


              while (slides.length < slideCount) {
                if (currentStyle === 'style1') {
                  slides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
                } else if (currentStyle === 'style2') {
                  slides.push({ small_text: '', title: '', image: '', link: '' });
                } else if (currentStyle === 'style3') {
                  slides.push({ desktop_image: '', mobile_image: '', link: '' });
                } else if (currentStyle === 'style4') {
                  slides.push({ desktop_image: '', mobile_image: '', link: '' });
                } else if (currentStyle === 'style5') {
                  slides.push({ desktop_image: '', mobile_image: '', link: '' });
                }
              }
              while (slides.length > slideCount) {
                slides.pop();
              }

              const $slidesContainer = $('<div class="slides-container" style="width:100%;"></div>');
              slides.forEach((slide, slideIdx) => {
                const $slideItem = $('<div class="slide-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(0,188,212,0.15);transition:all 0.3s ease;"></div>');

                // Header اسلاید با آیکون
                $slideItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                  <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="m17.024 3.034l-.955-.255c-2.7-.72-4.05-1.079-5.113-.468c-1.064.61-1.426 1.953-2.15 4.637l-1.022 3.797c-.724 2.685-1.086 4.027-.471 5.085c.614 1.057 1.964 1.417 4.664 2.136l.954.255c2.7.72 4.05 1.079 5.114.468c1.063-.61 1.425-1.953 2.148-4.637l1.023-3.797c.724-2.685 1.085-4.027.471-5.085s-1.963-1.417-4.664-2.136Z" /><path d="M16.854 7.433c0 .814-.664 1.474-1.483 1.474c-.818 0-1.482-.66-1.482-1.474s.664-1.474 1.482-1.474c.82 0 1.483.66 1.483 1.474Z" /><path stroke-linecap="round" d="m12 20.946l-.952.26c-2.694.733-4.04 1.1-5.102.477c-1.06-.622-1.422-1.99-2.143-4.728l-1.021-3.872c-.722-2.737-1.083-4.106-.47-5.184C2.842 6.966 4 7 5.5 7" /></g></svg></span>
                  <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">اسلاید شماره ${slideIdx + 1}</h4>
                </div>`);

                if (currentStyle === 'style1') {
                  // استایل 1: فرم کامل با تخفیف و تایمر

                  const imagePreview = slide.image
                    ? `<div style="margin-top:8px;"><img src="${slide.image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                        عنوان تخفیف:
                      </label>
                      <input type="text" placeholder="مثال: تخفیف ویژه" class="field-slide-discount-title" value="${slide.discount_title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                    
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">⏰</span>
                        زمان شروع تخفیف:
                      </label>
                      <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="تاریخ (1403/04/18)" class="field-slide-date" value="${slide.date_fa || ''}" style="flex:1;min-width:150px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <input type="time" class="field-slide-time" value="${slide.time || ''}" style="width:120px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                      </div>
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                        عنوان اصلی:
                      </label>
                      <input type="text" placeholder="عنوان اسلاید" class="field-slide-title" value="${slide.title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                        تصویر اسلاید:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر" class="field-slide-image" value="${slide.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="image" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${imagePreview}
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">💬</span>
                        توضیح کوتاه:
                      </label>
                      <input type="text" placeholder="توضیحات کوتاه اسلاید" class="field-slide-small-text" value="${slide.small_text || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);

                } else if (currentStyle === 'style2') {
                  // استایل 2: فرم ساده

                  const imagePreview = slide.image
                    ? `<div style="margin-top:8px;"><img src="${slide.image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;">💬</span>
                        توضیح کوتاه:
                      </label>
                      <input type="text" placeholder="توضیحات کوتاه" class="field-slide-small-text" value="${slide.small_text || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                        عنوان:
                      </label>
                      <input type="text" placeholder="عنوان اسلاید" class="field-slide-title" value="${slide.title || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                        تصویر:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر" class="field-slide-image" value="${slide.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="image" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${imagePreview}
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);

                } else if (currentStyle === 'style3' || currentStyle === 'style4' || currentStyle === 'style5') {
                  // استایل 3 و 4 و 5: تصویر دسکتاپ و موبایل

                  const desktopPreview = slide.desktop_image
                    ? `<div style="margin-top:8px;"><img src="${slide.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';
                  const mobilePreview = slide.mobile_image
                    ? `<div style="margin-top:8px;"><img src="${slide.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                    : '';

                  $slideItem.append(`
                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                        تصویر دسکتاپ:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-slide-desktop-image" value="${slide.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="desktop" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${desktopPreview}
                    </div>

                    <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                        تصویر موبایل:
                      </label>
                      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <input type="text" placeholder="آدرس تصویر موبایل" class="field-slide-mobile-image" value="${slide.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                        <button type="button" class="button button-primary button-upload-slide" data-type="mobile" data-slide="${slideIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                          <span style="margin-left:4px;">📁</span> انتخاب
                        </button>
                      </div>
                      ${mobilePreview}
                    </div>

                    <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                      <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                        <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                        لینک:
                      </label>
                      <input type="text" placeholder="https://example.com" class="field-slide-link" value="${slide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #b2dfdb;border-radius:6px;font-size:13px;background:#fff;">
                    </div>
                  `);
                }

                $slidesContainer.append($slideItem);
              });
              $item.append($slidesContainer);
            } else if (item.type === 'logo_slider') {
              $item.append(`<input type="text" placeholder="عنوان سکشن" class="field-name" value="${item.name || ''}" style="width:200px;margin-bottom:10px;">`);
              $item.append(`<input type="number" min="1" max="20" class="field-logo-count" placeholder="تعداد لوگو" value="${item.logo_count || 1}" style="width:70px;margin-bottom:10px;">`);


              let logos = item.logos || [];
              const logoCount = parseInt(item.logo_count) || 1;


              while (logos.length < logoCount) {
                logos.push({ image: '', link: '', alt: '' });
              }
              while (logos.length > logoCount) {
                logos.pop();
              }

              const $logosContainer = $('<div class="logos-container" style="width:100%;"></div>');
              logos.forEach((logo, logoIdx) => {
                const $logoItem = $('<div class="logo-item" style="background:linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #ffcc80;box-shadow:0 2px 8px rgba(255,152,0,0.15);transition:all 0.3s ease;"></div>');

                // Header لوگو با آیکون
                $logoItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                  <span style="font-size:20px;margin-left:8px;">🏢</span>
                  <h4 style="margin:0;color:#e65100;font-size:15px;font-weight:600;">لوگو شماره ${logoIdx + 1}</h4>
                </div>`);

                // بخش تصویر لوگو
                const logoPreview = logo.image
                  ? `<div style="margin-top:8px;"><img src="${logo.image}" class="field-image-preview" style="max-width:100px;max-height:60px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);background:#fff;padding:4px;"></div>`
                  : '';
                $logoItem.append(`
                  <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
                      تصویر لوگو:
                    </label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر لوگو" class="field-logo-image" value="${logo.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-logo" data-logo="${logoIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                        <span style="margin-left:4px;">📁</span> انتخاب
                      </button>
                    </div>
                    ${logoPreview}
                  </div>
                `);

                // بخش لینک
                $logoItem.append(`
                  <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-logo-link" value="${logo.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                // بخش Alt Text
                $logoItem.append(`
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#bf360c;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                      متن جایگزین (Alt):
                    </label>
                    <input type="text" placeholder="توضیح کوتاه درباره لوگو" class="field-logo-alt" value="${logo.alt || ''}" style="width:100%;padding:8px 12px;border:1px solid #ffccbc;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                $logosContainer.append($logoItem);
              });
              $item.append($logosContainer);
            }

            else if (item.type === 'spacer') {
              const $spacerSection = $('<div style="background:linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #ce93d8;box-shadow:0 2px 8px rgba(156,39,176,0.15);"></div>');

              $spacerSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 2v20M5 5l2 2m10-2l-2 2M5 19l2-2m10 2l-2-2"/></svg></span>
                <h4 style="margin:0;color:#7b1fa2;font-size:15px;font-weight:600;">تنظیمات فاصله</h4>
              </div>`);

              $spacerSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:12px;border-radius:8px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#7b1fa2;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12h18M12 3v18"/></svg></span>
                    ارتفاع فاصله (پیکسل):
                  </label>
                  <div style="display:flex;align-items:center;gap:10px;">
                    <input type="number" min="1" max="500" class="field-spacer-height" placeholder="مثال: 40" value="${item.height || 40}" style="width:120px;padding:8px 12px;border:1px solid #ce93d8;border-radius:6px;font-size:14px;background:#fff;">
                    <span style="font-size:13px;color:#7b1fa2;font-weight:500;">px</span>
                  </div>
                  <p style="margin:8px 0 0 0;font-size:12px;color:#7b1fa2;opacity:0.8;">مقدار فاصله خالی بین سکشن‌ها بر حسب پیکسل (۱ تا ۵۰۰)</p>
                </div>
              `);

              $item.append($spacerSection);
            }

            else if (item.type === 'custom_html') {
              $item.append(`<textarea class="field-html" placeholder="کد HTML">${item.html || ''}</textarea>`);
            }

            else if (item.type === 'brick_products') {
              // ساختار ویجت محصولات آجری
              const $brickSection = $('<div style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e0fae2;box-shadow:0 2px 8px rgba(9,143,129,0.15);"></div>');

              $brickSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 5h18v4H3zm0 4h9v5H3zm9 0h9v5h-9zm-9 5h18v5H3z"/></svg></span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات محصولات آجری</h4>
              </div>`);

              // ردیف اول: آیکون و نام و لینک
              $brickSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="1.5" d="M3 12c4.5 0 9-4.5 9-9c0 4.5 4.5 9 9 9c-4.5 0-9 4.5-9 9c0-4.5-4.5-9-9-9Zm-1 7.5c.833 0 2.5-1.667 2.5-2.5c0 .833 1.667 2.5 2.5 2.5c-.833 0-2.5 1.667-2.5 2.5c0-.833-1.667-2.5-2.5-2.5ZM16 5c1 0 3-2 3-3c0 1 2 3 3 3c-1 0-3 2-3 3c0-1-2-3-3-3Z" /></svg></span>
                      آیکون:
                    </label>
                    <textarea placeholder="SVG" class="field-icon" style="width:100%;min-height:60px;padding:8px;border:1px solid #e0fae2;border-radius:6px;font-size:12px;background:#fff;font-family:monospace;resize:none;">${item.icon || ''}</textarea>
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 4.5h5m-3 5h3m-5 5h5m-3 5h3M13 3v18m7-12.5l-1.542 1.242C17.153 10.794 16.5 11.32 16.5 12s.653 1.206 1.958 2.258L20 15.5" /></svg></span>
                      نام سکشن:
                    </label>
                    <input type="text" placeholder="مثال: محصولات آجری" class="field-name" value="${item.name || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                      <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                      لینک عنوان:
                    </label>
                    <input type="text" placeholder="https://example.com" class="field-link" value="${item.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف دوم: جستجوی دسته‌بندی محصولات
              const selectedBrickCats = item.product_cats || [];
              const $brickCatList = $('<div class="field-product-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              selectedBrickCats.forEach(cat => {
                $brickCatList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });

              $brickSection.append(`
                <div style="margin-bottom:12px;background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;position:relative;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 12c0-3.771 0-5.657 1.172-6.828S6.229 4 10 4h3c1.963 0 2.944 0 3.789.422c.844.423 1.433 1.208 2.611 2.778C21.133 9.511 22 10.667 22 12s-.867 2.489-2.6 4.8c-1.178 1.57-1.767 2.355-2.611 2.778C15.944 20 14.963 20 13 20h-3c-3.771 0-5.657 0-6.828-1.172S2 15.771 2 12Z" /></svg></span>
                    دسته‌بندی محصولات:
                  </label>
                  <input type="text" class="field-product-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #e0fae2;border-radius:8px;font-size:13px;background:#fff;transition:all 0.3s;">
                  <div class="product-cat-search-results" style="position:relative;z-index:1000;"></div>
                </div>
              `);
              $brickSection.find('.field-product-cat-search').after($brickCatList);

              // ردیف سوم: تعداد محصول
              $brickSection.append(`
                <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"><path d="M3 6h10M3 12h10M3 18h10" /><path stroke-linejoin="round" d="M18 15h1.5c.279 0 .418 0 .534.023a1.2 1.2 0 0 1 .943.943c.023.116.023.255.023.534s0 .418-.023.534a1.2 1.2 0 0 1-.943.943C19.918 18 19.78 18 19.5 18s-.418 0-.534.023a1.2 1.2 0 0 0-.943.943C18 19.082 18 19.22 18 19.5v.9c0 .283 0 .424.088.512s.23.088.512.088H21M18 3h1.2a.3.3 0 0 1 .3.3V9m0 0H18m1.5 0H21" /></g></svg></span>
                    تعداد محصول:
                  </label>
                  <input type="number" min="1" max="30" class="field-product-count" placeholder="تعداد" value="${item.product_count || 4}" style="width:120px;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;">
                </div>
              `);

              // انتخاب استایل
              $brickSection.append(`
                <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">
                    <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32l1.41-1.41"/></svg></span>
                    استایل:
                  </label>
                  <select class="field-brick-style" style="width:100%;padding:8px 12px;border:1px solid #e0fae2;border-radius:6px;font-size:13px;background:#fff;cursor:pointer;">
                    <option value="style1"${(item.brick_style || 'style1') === 'style1' ? ' selected' : ''}>استایل ۱</option>
                    <option value="style2"${item.brick_style === 'style2' ? ' selected' : ''}>استایل ۲</option>
                  </select>
                </div>
              `);

              // افزودن checkbox مخفی کردن محصولات ناموجود
              const hideOutOfStockBrick = item.hide_out_of_stock === 'yes' ? ' checked' : '';
              $brickSection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;border:2px solid #e0fae2;">
                  <label style="display:flex;align-items:center;cursor:pointer;user-select:none;">
                    <input type="checkbox" class="field-hide-out-of-stock"${hideOutOfStockBrick} style="width:20px;height:20px;cursor:pointer;accent-color:#098f81;margin-left:10px;">
                    <div style="flex:1;">
                      <div style="display:flex;align-items:center;font-size:14px;font-weight:600;color:#000000;margin-bottom:4px;">
                        مخفی کردن محصولات ناموجود
                      </div>
                      <div style="font-size:12px;color:#666;line-height:1.4;">با فعال کردن این گزینه، فقط محصولات موجود نمایش داده می‌شوند</div>
                    </div>
                  </label>
                </div>
              `);

              $item.append($brickSection);
            } else if (item.type === 'currency_price') {
              // ساختار نمایش قیمت ارز
              const $currencySection = $('<div style="background:linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #90caf9;box-shadow:0 2px 8px rgba(33,150,243,0.15);"></div>');

              $currencySection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;">💰</span>
                <h4 style="margin:0;color:#1565c0;font-size:15px;font-weight:600;">تنظیمات نمایش قیمت ارز</h4>
              </div>`);

              // ردیف صفر: منبع قیمت (دستی / قیمت متغیر)
              const priceSource = item.price_source || 'manual';
              const dynamicCurrency = item.dynamic_currency || '';
              $currencySection.append(`
                <div style="background:rgba(255,255,255,0.9);padding:14px;border-radius:8px;margin-bottom:12px;border:2px solid #90caf9;">
                  <label style="display:flex;align-items:center;margin-bottom:10px;font-size:13px;font-weight:600;color:#1565c0;">📊 منبع قیمت:</label>
                  <div style="display:flex;gap:16px;margin-bottom:12px;">
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;color:#333;">
                      <input type="radio" name="price_source_${item._uuid}" class="field-currency-price-source" value="manual" ${priceSource === 'manual' ? 'checked' : ''} style="accent-color:#1565c0;">
                      💵 قیمت دستی
                    </label>
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;color:#333;">
                      <input type="radio" name="price_source_${item._uuid}" class="field-currency-price-source" value="dynamic" ${priceSource === 'dynamic' ? 'checked' : ''} style="accent-color:#1565c0;">
                      🔄 قیمت متغیر (از سیستم ارز)
                    </label>
                  </div>
                  <div class="dynamic-currency-select" style="display:${priceSource === 'dynamic' ? 'block' : 'none'};background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;border:1px dashed #90caf9;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🪙 انتخاب ارز:</label>
                    <select class="field-currency-dynamic-currency" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;cursor:pointer;">
                      <option value="" ${dynamicCurrency === '' ? 'selected' : ''}>-- انتخاب کنید --</option>
                      <option value="USD" ${dynamicCurrency === 'USD' ? 'selected' : ''}>دلار آمریکا (USD)</option>
                      <option value="EUR" ${dynamicCurrency === 'EUR' ? 'selected' : ''}>یورو (EUR)</option>
                      <option value="GBP" ${dynamicCurrency === 'GBP' ? 'selected' : ''}>پوند انگلیس (GBP)</option>
                      <option value="AED" ${dynamicCurrency === 'AED' ? 'selected' : ''}>درهم امارات (AED)</option>
                      <option value="TRY" ${dynamicCurrency === 'TRY' ? 'selected' : ''}>لیر ترکیه (TRY)</option>
                      <option value="CNY" ${dynamicCurrency === 'CNY' ? 'selected' : ''}>یوان چین (CNY)</option>
                      <option value="JPY" ${dynamicCurrency === 'JPY' ? 'selected' : ''}>ین ژاپن (JPY)</option>
                      <option value="AUD" ${dynamicCurrency === 'AUD' ? 'selected' : ''}>دلار استرالیا (AUD)</option>
                      <option value="CAD" ${dynamicCurrency === 'CAD' ? 'selected' : ''}>دلار کانادا (CAD)</option>
                      <option value="CHF" ${dynamicCurrency === 'CHF' ? 'selected' : ''}>فرانک سوئیس (CHF)</option>
                      <option value="SILVER" ${dynamicCurrency === 'SILVER' ? 'selected' : ''}>نقره (گرم)</option>
                    </select>
                    <p style="margin:8px 0 0 0;font-size:12px;color:#1565c0;opacity:0.8;">💡 قیمت از سیستم مدیریت ارز قالب به صورت خودکار دریافت می‌شود</p>
                  </div>
                </div>
              `);

              // ردیف اول: عنوان و زیرعنوان
              $currencySection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🏷️ عنوان:</label>
                    <input type="text" placeholder="مثال: خرید و فروش نقره آب شده" class="field-currency-title" value="${item.currency_title || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">💬 زیرعنوان:</label>
                    <input type="text" placeholder="مثال: با هر میزان سرمایه همین الان شروع کنید" class="field-currency-subtitle" value="${item.currency_subtitle || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف دوم: نام ارز، واحد ارز، قیمت هر واحد
              $currencySection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🪙 نام ارز:</label>
                    <input type="text" placeholder="مثال: نقره" class="field-currency-name" value="${item.currency_name || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">📏 واحد ارز:</label>
                    <input type="text" placeholder="مثال: گرم" class="field-currency-unit" value="${item.currency_unit || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div class="manual-price-field" style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;${priceSource === 'dynamic' ? 'opacity:0.5;pointer-events:none;' : ''}">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">💲 قیمت هر واحد:</label>
                    <input type="number" min="0" placeholder="${priceSource === 'dynamic' ? 'خودکار از سیستم ارز' : 'مثال: 406940'}" class="field-currency-price-per-unit" value="${item.price_per_unit || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;" ${priceSource === 'dynamic' ? 'readonly' : ''}>
                  </div>
                </div>
              `);

              // ردیف سوم: لیبل قیمت، لیبل خرید، لیبل فروش
              $currencySection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🏷️ لیبل قیمت:</label>
                    <input type="text" placeholder="مثال: قیمت لحظه‌ای نقره:" class="field-currency-price-label" value="${item.price_label || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🛒 لیبل خرید:</label>
                    <input type="text" placeholder="مثال: خرید" class="field-currency-buy-label" value="${item.buy_label || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">💸 لیبل فروش:</label>
                    <input type="text" placeholder="مثال: فروش" class="field-currency-sell-label" value="${item.sell_label || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف چهارم: placeholder ها و واحد مبلغ
              $currencySection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">✏️ placeholder مبلغ:</label>
                    <input type="text" placeholder="مثال: مبلغ مورد نظر را وارد کنید" class="field-currency-input-placeholder" value="${item.input_placeholder || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">✏️ placeholder وزن:</label>
                    <input type="text" placeholder="مثال: وزن نقره" class="field-currency-weight-placeholder" value="${item.weight_placeholder || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">💵 واحد مبلغ:</label>
                    <input type="text" placeholder="مثال: تومان" class="field-currency-amount-unit" value="${item.amount_unit || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                </div>
              `);

              // ردیف پنجم: متن دکمه، رنگ پس‌زمینه، رنگ تاکیدی
              $currencySection.append(`
                <div style="display:grid;grid-template-columns:1fr 100px 100px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🔘 متن دکمه:</label>
                    <input type="text" placeholder="مثال: ثبت‌نام و شروع" class="field-currency-button-text" value="${item.button_text || ''}" style="width:100%;padding:8px 12px;border:1px solid #90caf9;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🎨 رنگ پس‌زمینه:</label>
                    <input type="color" class="field-currency-bg-color" value="${item.bg_color || '#dce9f5'}" style="width:100%;height:36px;padding:2px;border:1px solid #90caf9;border-radius:6px;cursor:pointer;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#1565c0;">🎨 رنگ تاکیدی:</label>
                    <input type="color" class="field-currency-accent-color" value="${item.accent_color || '#1a6fd4'}" style="width:100%;height:36px;padding:2px;border:1px solid #90caf9;border-radius:6px;cursor:pointer;">
                  </div>
                </div>
              `);

              $item.append($currencySection);
            } else if (item.type === 'hero') {
              // ───── ساختار ویجت هیرو ─────
              const heroBg = item.hero_bg_style || 'letter_glitch';
              const heroColors = Array.isArray(item.hero_glitch_colors) && item.hero_glitch_colors.length === 3
                ? item.hero_glitch_colors
                : ['#2b4539', '#61dca3', '#61b3dc'];
              const heroAlign = item.hero_align || 'center';
              const heroOuterVignette = item.hero_outer_vignette !== 'no';
              const heroCenterVignette = item.hero_center_vignette === 'yes';
              const heroWidthMode = item.hero_width_mode || 'container';

              const $heroSection = $('<div style="background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #334155;box-shadow:0 4px 14px rgba(15,23,42,0.25);color:#e2e8f0;"></div>');

              $heroSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.1);">
                <span style="font-size:22px;margin-left:8px;">✨</span>
                <h4 style="margin:0;color:#f1f5f9;font-size:15px;font-weight:600;">تنظیمات ویجت هیرو</h4>
              </div>`);

              // ردیف ۱: عنوان و زیرعنوان
              $heroSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🏷️ عنوان اصلی:</label>
                    <input type="text" placeholder="مثال: به فروشگاه ما خوش آمدید" class="field-hero-title" value="${item.hero_title || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">💬 زیرعنوان:</label>
                    <input type="text" placeholder="مثال: بهترین محصولات با بهترین قیمت" class="field-hero-subtitle" value="${item.hero_subtitle || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                </div>
              `);

              // ردیف ۲: متن دکمه + لینک دکمه + متن دکمه ثانویه + لینک ثانویه
              $heroSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔘 متن دکمه اصلی:</label>
                    <input type="text" placeholder="مثال: شروع خرید" class="field-hero-btn-text" value="${item.hero_btn_text || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔗 لینک دکمه اصلی:</label>
                    <input type="text" placeholder="/shop" class="field-hero-btn-link" value="${item.hero_btn_link || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔘 متن دکمه ثانویه:</label>
                    <input type="text" placeholder="(اختیاری) بیشتر بدانید" class="field-hero-btn2-text" value="${item.hero_btn2_text || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔗 لینک دکمه ثانویه:</label>
                    <input type="text" placeholder="/about" class="field-hero-btn2-link" value="${item.hero_btn2_link || ''}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                </div>
              `);

              // ردیف ۳: استایل بک‌گراند + چینش + ارتفاع + عرض سکشن
              $heroSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">📏 عرض سکشن:</label>
                    <select class="field-hero-width-mode" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                      <option value="container" ${heroWidthMode === 'container' ? 'selected' : ''}>کانتینر (گوشه‌گرد)</option>
                      <option value="full" ${heroWidthMode === 'full' ? 'selected' : ''}>تمام عرض صفحه</option>
                    </select>
                  </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🎨 استایل بک‌گراند:</label>
                    <select class="field-hero-bg-style" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                      <option value="letter_glitch" ${heroBg === 'letter_glitch' ? 'selected' : ''}>Letter Glitch</option>
                      <option value="beams" ${heroBg === 'beams' ? 'selected' : ''}>Beams (پرتوهای سه‌بعدی)</option>
                    </select>
                    <p style="margin:6px 0 0 0;font-size:11px;color:#94a3b8;opacity:0.8;">استایل‌های بیشتر در آینده اضافه می‌شوند</p>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">↔️ چینش محتوا:</label>
                    <select class="field-hero-align" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                      <option value="center" ${heroAlign === 'center' ? 'selected' : ''}>وسط‌چین</option>
                      <option value="right" ${heroAlign === 'right' ? 'selected' : ''}>راست‌چین</option>
                      <option value="left" ${heroAlign === 'left' ? 'selected' : ''}>چپ‌چین</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">📐 ارتفاع (vh):</label>
                    <input type="number" min="20" max="100" placeholder="60" class="field-hero-height" value="${item.hero_height || 60}" style="width:100%;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                </div>
              `);

              // ردیف ۴: تنظیمات خاص Letter Glitch (۳ رنگ + سرعت + کاراکترها)
              $heroSection.append(`
                <div class="hero-bg-options-letter-glitch" style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;margin-bottom:12px;border:1px dashed #475569;${heroBg === 'letter_glitch' ? '' : 'display:none;'}">
                  <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:10px;">تنظیمات Letter Glitch:</div>
                  <div style="display:grid;grid-template-columns:80px 80px 80px 1fr 1fr;gap:10px;align-items:end;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">رنگ ۱:</label>
                      <input type="color" class="field-hero-color-1" value="${heroColors[0]}" style="width:100%;height:36px;padding:2px;border:1px solid #475569;border-radius:6px;cursor:pointer;background:#0f172a;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">رنگ ۲:</label>
                      <input type="color" class="field-hero-color-2" value="${heroColors[1]}" style="width:100%;height:36px;padding:2px;border:1px solid #475569;border-radius:6px;cursor:pointer;background:#0f172a;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">رنگ ۳:</label>
                      <input type="color" class="field-hero-color-3" value="${heroColors[2]}" style="width:100%;height:36px;padding:2px;border:1px solid #475569;border-radius:6px;cursor:pointer;background:#0f172a;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">سرعت گلیچ (ms):</label>
                      <input type="number" min="10" max="500" class="field-hero-glitch-speed" value="${item.hero_glitch_speed || 50}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">وینیت:</label>
                      <div style="display:flex;gap:8px;align-items:center;height:36px;">
                        <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#cbd5e1;cursor:pointer;">
                          <input type="checkbox" class="field-hero-outer-vignette" ${heroOuterVignette ? 'checked' : ''} style="accent-color:#61dca3;"> بیرونی
                        </label>
                        <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:#cbd5e1;cursor:pointer;">
                          <input type="checkbox" class="field-hero-center-vignette" ${heroCenterVignette ? 'checked' : ''} style="accent-color:#61dca3;"> مرکزی
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              `);

              // تنظیمات خاص Beams (رنگ نور + تعداد + سرعت + نویز + مقیاس + چرخش)
              $heroSection.append(`
                <div class="hero-bg-options-beams" style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;margin-bottom:12px;border:1px dashed #475569;${heroBg === 'beams' ? '' : 'display:none;'}">
                  <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:10px;">تنظیمات Beams:</div>
                  <div style="display:grid;grid-template-columns:90px 1fr 1fr 1fr 1fr 1fr;gap:10px;align-items:end;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">رنگ نور:</label>
                      <input type="color" class="field-hero-beams-light-color" value="${item.hero_beams_light_color || '#ffffff'}" style="width:100%;height:36px;padding:2px;border:1px solid #475569;border-radius:6px;cursor:pointer;background:#0f172a;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">تعداد پرتو:</label>
                      <input type="number" min="1" max="40" class="field-hero-beams-number" value="${item.hero_beams_number || 12}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">سرعت:</label>
                      <input type="number" min="0" max="20" step="0.1" class="field-hero-beams-speed" value="${item.hero_beams_speed || 2}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">شدت نویز:</label>
                      <input type="number" min="0" max="10" step="0.05" class="field-hero-beams-noise" value="${item.hero_beams_noise || 1.75}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">مقیاس:</label>
                      <input type="number" min="0.01" max="5" step="0.01" class="field-hero-beams-scale" value="${item.hero_beams_scale || 0.2}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">چرخش (deg):</label>
                      <input type="number" min="-180" max="180" class="field-hero-beams-rotation" value="${item.hero_beams_rotation || 0}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">عرض پرتو:</label>
                      <input type="number" min="0.1" max="20" step="0.1" class="field-hero-beams-width" value="${item.hero_beams_width || 2}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">ارتفاع پرتو:</label>
                      <input type="number" min="1" max="100" step="0.5" class="field-hero-beams-height" value="${item.hero_beams_height || 15}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                  </div>
                </div>
              `);

              // ردیف ۵: رنگ متن و شفافیت overlay
              $heroSection.append(`
                <div style="display:grid;grid-template-columns:120px 1fr;gap:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🎨 رنگ متن:</label>
                    <input type="color" class="field-hero-text-color" value="${item.hero_text_color || '#ffffff'}" style="width:100%;height:36px;padding:2px;border:1px solid #475569;border-radius:6px;cursor:pointer;background:#0f172a;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🌓 شفافیت پوشش تیره روی بک‌گراند (٪):</label>
                    <input type="number" min="0" max="100" class="field-hero-overlay-opacity" value="${item.hero_overlay_opacity || 40}" style="width:160px;padding:9px 12px;border:1px solid #475569;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                    <span style="margin-right:8px;font-size:12px;color:#94a3b8;">برای خوانایی متن روی بک‌گراند</span>
                  </div>
                </div>
              `);

              // تغییر استایل بک‌گراند → نمایش تنظیمات مربوطه
              $heroSection.on('change', '.field-hero-bg-style', function () {
                const val = $(this).val();
                $heroSection.find('.hero-bg-options-letter-glitch').toggle(val === 'letter_glitch');
                $heroSection.find('.hero-bg-options-beams').toggle(val === 'beams');
              });

              $item.append($heroSection);
            } else if (item.type === 'card_swap') {
              // ───── ساختار ویجت سواپ کارت‌ها ─────
              const csWidthMode = item.cs_width_mode || 'container';
              const csAlign = item.cs_align || 'right';
              const csEasing = item.cs_easing || 'elastic';
              const csPauseOnHover = item.cs_pause_on_hover === 'yes';
              const csCards = Array.isArray(item.cs_cards) && item.cs_cards.length ? item.cs_cards : [{ image: '', title: '', desc: '', link: '' }];

              const $csSection = $('<div style="background:linear-gradient(135deg,#1e1b4b 0%,#312e81 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #4338ca;box-shadow:0 4px 14px rgba(67,56,202,0.25);color:#e2e8f0;"></div>');

              $csSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.1);">
                <span style="font-size:22px;margin-left:8px;">🎴</span>
                <h4 style="margin:0;color:#f1f5f9;font-size:15px;font-weight:600;">تنظیمات سواپ کارت‌ها</h4>
              </div>`);

              // عنوان + زیرعنوان
              $csSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🏷️ عنوان:</label>
                    <input type="text" placeholder="مثال: محصولات ویژه" class="field-cs-title" value="${item.cs_title || ''}" style="width:100%;padding:9px 12px;border:1px solid #4338ca;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">💬 زیرعنوان:</label>
                    <input type="text" placeholder="توضیح کوتاه" class="field-cs-subtitle" value="${item.cs_subtitle || ''}" style="width:100%;padding:9px 12px;border:1px solid #4338ca;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                </div>
              `);

              // دکمه CTA
              $csSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔘 متن دکمه:</label>
                    <input type="text" placeholder="(اختیاری) مثال: مشاهده همه" class="field-cs-btn-text" value="${item.cs_btn_text || ''}" style="width:100%;padding:9px 12px;border:1px solid #4338ca;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🔗 لینک دکمه:</label>
                    <input type="text" placeholder="/shop" class="field-cs-btn-link" value="${item.cs_btn_link || ''}" style="width:100%;padding:9px 12px;border:1px solid #4338ca;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  </div>
                </div>
              `);

              // عرض سکشن + چینش متن + ارتفاع + رنگ پس‌زمینه + رنگ متن
              $csSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr 100px 100px;gap:10px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">📏 عرض سکشن:</label>
                    <select class="field-cs-width-mode" style="width:100%;padding:8px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                      <option value="container" ${csWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${csWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">↔️ چینش متن:</label>
                    <select class="field-cs-align" style="width:100%;padding:8px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                      <option value="right" ${csAlign === 'right' ? 'selected' : ''}>راست (کارت چپ)</option>
                      <option value="left" ${csAlign === 'left' ? 'selected' : ''}>چپ (کارت راست)</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">📐 ارتفاع (px):</label>
                    <input type="number" min="300" max="1000" class="field-cs-height" value="${item.cs_height || 600}" style="width:100%;padding:8px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">پس‌زمینه:</label>
                    <input type="color" class="field-cs-bg-color" value="${item.cs_bg_color || '#0f172a'}" style="width:100%;height:36px;padding:2px;border:1px solid #4338ca;border-radius:6px;cursor:pointer;background:#0f172a;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">رنگ متن:</label>
                    <input type="color" class="field-cs-text-color" value="${item.cs_text_color || '#ffffff'}" style="width:100%;height:36px;padding:2px;border:1px solid #4338ca;border-radius:6px;cursor:pointer;background:#0f172a;">
                  </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">🎨 رنگ پس‌زمینه نوار بالای کارت:</label>
                    <input type="color" class="field-cs-card-bar-bg" value="${item.cs_card_bar_bg || '#000000'}" style="width:120px;height:36px;padding:2px;border:1px solid #4338ca;border-radius:6px;cursor:pointer;background:#0f172a;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#cbd5e1;">✏️ رنگ متن عنوان بالای کارت:</label>
                    <input type="color" class="field-cs-card-bar-text" value="${item.cs_card_bar_text || '#ffffff'}" style="width:120px;height:36px;padding:2px;border:1px solid #4338ca;border-radius:6px;cursor:pointer;background:#0f172a;">
                  </div>
                </div>
              `);

              // تنظیمات انیمیشن
              $csSection.append(`
                <div style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;margin-bottom:12px;border:1px dashed #475569;">
                  <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:10px;">تنظیمات انیمیشن:</div>
                  <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 110px;gap:10px;align-items:end;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">فاصله کارت‌ها:</label>
                      <input type="number" min="10" max="200" class="field-cs-card-distance" value="${item.cs_card_distance || 60}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">فاصله عمودی:</label>
                      <input type="number" min="10" max="200" class="field-cs-vertical-distance" value="${item.cs_vertical_distance || 70}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">تأخیر (ms):</label>
                      <input type="number" min="1000" max="20000" step="100" class="field-cs-delay" value="${item.cs_delay || 5000}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">میزان skew:</label>
                      <input type="number" min="0" max="30" step="1" class="field-cs-skew" value="${item.cs_skew || 6}" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">نوع easing:</label>
                      <select class="field-cs-easing" style="width:100%;padding:8px 10px;border:1px solid #475569;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;cursor:pointer;">
                        <option value="elastic" ${csEasing === 'elastic' ? 'selected' : ''}>کشسانی</option>
                        <option value="linear" ${csEasing === 'linear' ? 'selected' : ''}>خطی</option>
                      </select>
                    </div>
                    <div>
                      <label style="display:flex;align-items:center;gap:6px;font-size:11px;color:#cbd5e1;cursor:pointer;height:36px;">
                        <input type="checkbox" class="field-cs-pause-on-hover" ${csPauseOnHover ? 'checked' : ''} style="accent-color:#818cf8;width:18px;height:18px;"> توقف روی هاور
                      </label>
                    </div>
                  </div>
                </div>
              `);

              // تعداد کارت + لیست کارت‌ها
              $csSection.append(`
                <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#cbd5e1;">🎴 تعداد کارت‌ها:</label>
                  <input type="number" min="2" max="10" class="field-cs-card-count" value="${csCards.length}" style="width:120px;padding:8px 12px;border:1px solid #4338ca;border-radius:6px;font-size:13px;background:#0f172a;color:#f8fafc;">
                  <span style="margin-right:8px;font-size:12px;color:#94a3b8;">(بین ۲ تا ۱۰)</span>
                </div>
              `);

              const $csCardsContainer = $('<div class="cs-cards-container" style="display:flex;flex-direction:column;gap:10px;"></div>');
              const renderCsCard = (card, ci) => `
                <div class="cs-card-item" data-idx="${ci}" style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;border:1px solid #4338ca;">
                  <div style="font-size:12px;font-weight:600;color:#a5b4fc;margin-bottom:10px;">کارت ${ci + 1}</div>
                  <div style="display:grid;grid-template-columns:200px 100px 1fr 1fr;gap:10px;align-items:start;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">تصویر:</label>
                      <input type="text" class="field-cs-card-image" value="${card.image || ''}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;margin-bottom:6px;">
                      <button type="button" class="button button-upload-cs-card" data-idx="${ci}" style="font-size:11px;">📷 انتخاب تصویر</button>
                      ${card.image ? `<img src="${card.image}" style="max-width:100%;max-height:60px;margin-top:6px;border-radius:4px;display:block;">` : ''}
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">آیکون:</label>
                      <textarea class="field-cs-card-icon" placeholder="emoji یا SVG" style="width:100%;min-height:60px;padding:6px 8px;border:1px solid #4338ca;border-radius:6px;font-size:11px;background:#0f172a;color:#f8fafc;font-family:monospace;resize:none;">${card.icon || ''}</textarea>
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">عنوان کارت:</label>
                      <input type="text" class="field-cs-card-title" value="${card.title || ''}" placeholder="عنوان" style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">لینک (اختیاری):</label>
                      <input type="text" class="field-cs-card-link" value="${card.link || ''}" placeholder="/product/..." style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                    </div>
                  </div>
                </div>
              `;
              csCards.forEach((card, ci) => $csCardsContainer.append(renderCsCard(card, ci)));
              $csSection.append($csCardsContainer);

              $item.append($csSection);
            } else if (item.type === 'bento_features') {
              // ───── ساختار ویجت Magic Bento ─────
              const bfWidthMode = item.bf_width_mode || 'container';
              const bfItems = Array.isArray(item.bf_items) && item.bf_items.length ? item.bf_items : [
                { label: 'Analytics', title: 'تحلیل پیشرفته', description: 'رفتار کاربر را زیر نظر بگیرید', icon: '📊', color: '#120F17', image: '', link: '' },
                { label: 'Dashboard', title: 'داشبورد یکپارچه', description: 'نمای متمرکز داده‌ها', icon: '🧭', color: '#120F17', image: '', link: '' },
                { label: 'Collaboration', title: 'همکاری تیمی', description: 'با هم بی‌وقفه کار کنید', icon: '🤝', color: '#120F17', image: '', link: '' },
                { label: 'Automation', title: 'اتوماسیون', description: 'فرآیندها را خودکار کنید', icon: '⚡', color: '#120F17', image: '', link: '' },
                { label: 'Integration', title: 'یکپارچه‌سازی', description: 'به ابزارهای محبوب وصل شوید', icon: '🔌', color: '#120F17', image: '', link: '' },
                { label: 'Security', title: 'امنیت سازمانی', description: 'محافظت در سطح Enterprise', icon: '🔒', color: '#120F17', image: '', link: '' }
              ];
              const bfGlow = item.bf_glow_color || '132, 0, 255';
              const bfSpotR = item.bf_spotlight_radius || 400;
              const bfPCount = item.bf_particle_count || 12;
              const bfTextAutoHide = item.bf_text_auto_hide !== 'no';
              const bfEnableStars = item.bf_enable_stars !== 'no';
              const bfEnableSpotlight = item.bf_enable_spotlight !== 'no';
              const bfEnableBorderGlow = item.bf_enable_border_glow !== 'no';
              const bfEnableTilt = item.bf_enable_tilt === 'yes';
              const bfEnableMagnetism = item.bf_enable_magnetism === 'yes';
              const bfClickEffect = item.bf_click_effect !== 'no';
              const bfDisableAnimations = item.bf_disable_animations === 'yes';

              const $bfSection = $('<div style="background:linear-gradient(135deg,#3b0764 0%,#831843 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #a21caf;box-shadow:0 4px 14px rgba(162,28,175,0.25);color:#fce7f3;"></div>');

              $bfSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.1);">
                <span style="font-size:22px;margin-left:8px;">🟪</span>
                <h4 style="margin:0;color:#fdf2f8;font-size:15px;font-weight:600;">تنظیمات بنتو گرید قابلیت‌ها</h4>
              </div>`);

              // عنوان + زیرعنوان + رنگ عنوان + رنگ زیرعنوان
              $bfSection.append(`
                <div style="display:grid;grid-template-columns:1fr 80px 1fr 80px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fbcfe8;">🏷️ عنوان سکشن:</label>
                    <input type="text" placeholder="مثلاً: قابلیت‌های کلیدی" class="field-bf-title" value="${item.bf_title || ''}" style="width:100%;padding:9px 12px;border:1px solid #a21caf;border-radius:6px;font-size:13px;background:#1e1b4b;color:#fdf2f8;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:11px;font-weight:600;color:#fbcfe8;">رنگ عنوان:</label>
                    <input type="color" class="field-bf-title-color" value="${item.bf_title_color || '#ffffff'}" style="width:100%;height:32px;padding:2px;border:1px solid #a21caf;border-radius:6px;cursor:pointer;background:#1e1b4b;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fbcfe8;">💬 زیرعنوان:</label>
                    <input type="text" placeholder="توضیح کوتاه بالای گرید" class="field-bf-subtitle" value="${item.bf_subtitle || ''}" style="width:100%;padding:9px 12px;border:1px solid #a21caf;border-radius:6px;font-size:13px;background:#1e1b4b;color:#fdf2f8;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:11px;font-weight:600;color:#fbcfe8;">رنگ زیرعنوان:</label>
                    <input type="color" class="field-bf-subtitle-color" value="${item.bf_subtitle_color || '#a1a1aa'}" style="width:100%;height:32px;padding:2px;border:1px solid #a21caf;border-radius:6px;cursor:pointer;background:#1e1b4b;">
                  </div>
                </div>
              `);

              // عرض سکشن + رنگ glow (به فرمت R, G, B)
              const glowHex = (() => {
                const m = (bfGlow || '').toString().match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
                if (!m) return '#8400ff';
                const r = Math.max(0, Math.min(255, parseInt(m[1])));
                const g = Math.max(0, Math.min(255, parseInt(m[2])));
                const b = Math.max(0, Math.min(255, parseInt(m[3])));
                return '#' + [r, g, b].map(n => n.toString(16).padStart(2, '0')).join('');
              })();
              $bfSection.append(`
                <div style="display:grid;grid-template-columns:1fr 130px 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#fbcfe8;">📏 عرض سکشن:</label>
                    <select class="field-bf-width-mode" style="width:100%;padding:8px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;cursor:pointer;">
                      <option value="container" ${bfWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${bfWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#fbcfe8;">✨ رنگ Glow:</label>
                    <input type="color" class="field-bf-glow-picker" value="${glowHex}" style="width:100%;height:36px;padding:2px;border:1px solid #a21caf;border-radius:6px;cursor:pointer;background:#1e1b4b;">
                    <input type="hidden" class="field-bf-glow-color" value="${bfGlow}">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#fbcfe8;">⭕ شعاع Spotlight:</label>
                    <input type="number" min="100" max="1000" step="10" class="field-bf-spotlight-radius" value="${bfSpotR}" style="width:100%;padding:8px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                  </div>
                </div>
              `);

              // پنل افکت‌ها
              $bfSection.append(`
                <div style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;margin-bottom:12px;border:1px dashed #a21caf;">
                  <div style="font-size:12px;font-weight:600;color:#f9a8d4;margin-bottom:10px;">افکت‌های MagicBento:</div>
                  <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:10px;">
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-enable-stars" ${bfEnableStars ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> ⭐ Stars (ذرات)</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-enable-spotlight" ${bfEnableSpotlight ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 🔦 Spotlight (نور موس)</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-enable-border-glow" ${bfEnableBorderGlow ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 💎 Border Glow</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-click-effect" ${bfClickEffect ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 💥 Click Ripple</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-enable-tilt" ${bfEnableTilt ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 🎢 Tilt (چرخش)</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-enable-magnetism" ${bfEnableMagnetism ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 🧲 Magnetism</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-text-auto-hide" ${bfTextAutoHide ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> ✂️ Auto-hide متن</label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf2f8;cursor:pointer;"><input type="checkbox" class="field-bf-disable-animations" ${bfDisableAnimations ? 'checked' : ''} style="accent-color:#a21caf;width:18px;height:18px;"> 🚫 خاموش‌کردن همه</label>
                  </div>
                  <div style="margin-top:12px;background:rgba(255,255,255,0.05);padding:10px;border-radius:6px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">تعداد ذرات (Stars):</label>
                    <input type="number" min="1" max="50" class="field-bf-particle-count" value="${bfPCount}" style="width:120px;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                  </div>
                </div>
              `);

              // تعداد آیتم
              $bfSection.append(`
                <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fbcfe8;">🧩 تعداد سل‌ها:</label>
                  <input type="number" min="3" max="12" class="field-bf-item-count" value="${bfItems.length}" style="width:120px;padding:8px 12px;border:1px solid #a21caf;border-radius:6px;font-size:13px;background:#1e1b4b;color:#fdf2f8;">
                  <span style="margin-right:8px;font-size:12px;color:#f9a8d4;">(بین ۳ تا ۱۲)</span>
                </div>
              `);

              const $bfItemsContainer = $('<div class="bf-items-container" style="display:flex;flex-direction:column;gap:10px;"></div>');
              const renderBfItem = (it, bi) => `
                <div class="bf-item" data-idx="${bi}" style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;border:1px solid #a21caf;">
                  <div style="font-size:12px;font-weight:600;color:#f9a8d4;margin-bottom:10px;">کارت ${bi + 1}</div>
                  <div style="display:grid;grid-template-columns:100px 100px 1fr 1fr 80px 1fr;gap:10px;align-items:start;">
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">برچسب (Label):</label>
                      <input type="text" class="field-bf-item-label" value="${it.label || ''}" placeholder="Label" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">آیکون:</label>
                      <textarea class="field-bf-item-icon" placeholder="emoji یا SVG" style="width:100%;min-height:60px;padding:6px 8px;border:1px solid #a21caf;border-radius:6px;font-size:11px;background:#1e1b4b;color:#fdf2f8;font-family:monospace;resize:none;">${it.icon || ''}</textarea>
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">عنوان:</label>
                      <input type="text" class="field-bf-item-title" value="${it.title || ''}" placeholder="عنوان" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;margin-bottom:6px;">
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">لینک (اختیاری):</label>
                      <input type="text" class="field-bf-item-link" value="${it.link || ''}" placeholder="/..." style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">توضیح:</label>
                      <textarea class="field-bf-item-desc" placeholder="توضیح کوتاه" style="width:100%;min-height:60px;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;resize:none;">${it.description || it.desc || ''}</textarea>
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">رنگ پس‌زمینه:</label>
                      <input type="color" class="field-bf-item-color" value="${it.color || '#120F17'}" style="width:100%;height:32px;padding:2px;border:1px solid #a21caf;border-radius:6px;cursor:pointer;background:#1e1b4b;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">تصویر (اختیاری):</label>
                      <input type="text" class="field-bf-item-image" value="${it.image || ''}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:11px;background:#1e1b4b;color:#fdf2f8;margin-bottom:6px;">
                      <button type="button" class="button button-upload-bf" data-idx="${bi}" style="font-size:11px;">📷 انتخاب</button>
                      ${it.image ? `<img src="${it.image}" style="max-width:100%;max-height:50px;margin-top:6px;border-radius:4px;display:block;">` : ''}
                    </div>
                  </div>
                </div>
              `;
              bfItems.forEach((it, bi) => $bfItemsContainer.append(renderBfItem(it, bi)));
              $bfSection.append($bfItemsContainer);

              $item.append($bfSection);
            } else if (item.type === 'category_nav') {
              // ───── ساختار ویجت ناوبری دسته‌بندی ─────
              const cnWidthMode = item.cn_width_mode || 'container';
              const cnCats = Array.isArray(item.cn_categories) && item.cn_categories.length ? item.cn_categories : [
                { name: 'دسته نمونه', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] }
              ];

              const $cnSection = $('<div style="background:linear-gradient(135deg,#064e3b 0%,#065f46 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #10b981;box-shadow:0 4px 14px rgba(16,185,129,0.25);color:#d1fae5;"></div>');

              $cnSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.1);">
                <span style="font-size:22px;margin-left:8px;">🗂️</span>
                <h4 style="margin:0;color:#ecfdf5;font-size:15px;font-weight:600;">تنظیمات ناوبری دسته‌بندی</h4>
              </div>`);

              // عنوان + عرض + رنگ تاکیدی
              $cnSection.append(`
                <div style="display:grid;grid-template-columns:1fr 150px 110px;gap:12px;margin-bottom:14px;">
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#a7f3d0;">🏷️ عنوان سکشن (اختیاری):</label>
                    <input type="text" placeholder="مثلاً: دسته‌بندی‌ها" class="field-cn-title" value="${item.cn_title || ''}" style="width:100%;padding:9px 12px;border:1px solid #10b981;border-radius:6px;font-size:13px;background:#022c22;color:#ecfdf5;">
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#a7f3d0;">📏 عرض سکشن:</label>
                    <select class="field-cn-width-mode" style="width:100%;padding:8px 10px;border:1px solid #10b981;border-radius:6px;font-size:12px;background:#022c22;color:#ecfdf5;cursor:pointer;">
                      <option value="container" ${cnWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${cnWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#a7f3d0;">🎨 رنگ تاکیدی:</label>
                    <input type="color" class="field-cn-accent-color" value="${item.cn_accent_color || '#ff6a3d'}" style="width:100%;height:36px;padding:2px;border:1px solid #10b981;border-radius:6px;cursor:pointer;background:#022c22;">
                  </div>
                </div>
                <div style="font-size:12px;color:#6ee7b7;margin-bottom:8px;background:rgba(255,255,255,0.04);padding:8px 10px;border-radius:6px;border:1px dashed #10b981;">
                  💡 سطح ۱ شامل «تصویر + نام» است و لینک ندارد. روی هر سطح ۱ کلیک شود، سطح ۲ آن (نام + لینک) با انیمیشن باز می‌شود.
                </div>
              `);

              const $cnCatsContainer = $('<div class="cn-cats-container" style="display:flex;flex-direction:column;gap:12px;"></div>');
              cnCats.forEach((cat, ci) => $cnCatsContainer.append(window.__cnRenderCat(cat, ci)));
              $cnSection.append($cnCatsContainer);

              $cnSection.append(`<button type="button" class="button cn-add-cat" style="margin-top:12px;background:#10b981;color:#022c22;border:none;font-weight:700;padding:8px 16px;border-radius:6px;cursor:pointer;">➕ افزودن دسته سطح ۱</button>`);

              $item.append($cnSection);
            } else if (item.type === 'recommended_panels') {
              // ───── ساختار ویجت سه‌پنل محصولات پیشنهادی ─────
              const recWidthMode = item.rec_width_mode || 'container';
              const defaultRecPanel = () => ({ title: '', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' });
              let recPanels = Array.isArray(item.rec_panels) && item.rec_panels.length ? item.rec_panels.slice(0, 3) : [];
              while (recPanels.length < 3) recPanels.push(defaultRecPanel());

              const $recSection = $('<div style="background:linear-gradient(135deg,#0f2a6b 0%,#1d4ed8 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #2563eb;box-shadow:0 4px 14px rgba(37,99,235,0.28);color:#dbeafe;"></div>');

              $recSection.append(`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.12);">
                <h4 style="margin:0;color:#eff6ff;font-size:15px;font-weight:600;">تنظیمات سه‌پنل محصولات پیشنهادی</h4>
                <div style="background:rgba(255,255,255,0.08);padding:6px 10px;border-radius:8px;">
                  <label style="font-size:12px;color:#bfdbfe;">عرض سکشن:
                    <select class="field-rec-width-mode" style="margin-right:6px;padding:5px 8px;border:1px solid #2563eb;border-radius:6px;font-size:12px;background:#0b1e4d;color:#eff6ff;cursor:pointer;">
                      <option value="container" ${recWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${recWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </label>
                </div>
              </div>`);

              const $recPanelsWrap = $('<div style="display:flex;flex-direction:column;gap:14px;"></div>');
              recPanels.forEach((panel, pi) => {
                const p = panel || {};
                const $panel = $(`<div class="rec-panel" data-panel="${pi}" style="background:rgba(255,255,255,0.06);padding:14px;border-radius:10px;border:1px solid #2563eb;"></div>`);
                $panel.append(`<div style="font-size:13px;font-weight:700;color:#93c5fd;margin-bottom:10px;">پنل ${pi + 1}</div>`);

                // عنوان + زیرعنوان
                $panel.append(`
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">عنوان:</label>
                      <input type="text" class="field-rec-title" value="${(p.title || '').replace(/"/g, '&quot;')}" placeholder="مثلاً: لوازم مکانیکی" style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">زیرعنوان:</label>
                      <input type="text" class="field-rec-subtitle" value="${(p.subtitle || '').replace(/"/g, '&quot;')}" placeholder="محصولات پیشنهادی از دسته" style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;">
                    </div>
                  </div>
                `);

                // متن دکمه + لینک دکمه + رنگ تاکیدی
                $panel.append(`
                  <div style="display:grid;grid-template-columns:1fr 1fr 120px;gap:10px;margin-bottom:10px;">
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">متن دکمه:</label>
                      <input type="text" class="field-rec-btn-text" value="${(p.btn_text || '').replace(/"/g, '&quot;')}" placeholder="بیشتر" style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">لینک دکمه:</label>
                      <input type="text" class="field-rec-btn-link" value="${(p.btn_link || '').replace(/"/g, '&quot;')}" placeholder="/product-category/..." style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">رنگ دکمه:</label>
                      <input type="color" class="field-rec-accent" value="${p.accent || '#1d5eff'}" style="width:100%;height:36px;padding:2px;border:1px solid #2563eb;border-radius:6px;cursor:pointer;background:#0b1e4d;">
                    </div>
                  </div>
                `);

                // انتخاب دسته‌بندی (اسکوپ‌شده به همین پنل)
                const $catList = $('<div class="field-rec-cat-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
                (p.product_cats || []).forEach(cat => {
                  $catList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='rec-remove-cat'>&times;</b></span>`);
                });
                const $catBox = $(`
                  <div style="background:rgba(255,255,255,0.05);padding:10px;border-radius:8px;position:relative;margin-bottom:10px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;color:#bfdbfe;">دسته‌بندی محصولات:</label>
                    <input type="text" class="field-rec-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:9px 10px;border:2px solid #2563eb;border-radius:8px;font-size:13px;background:#fff;color:#111;">
                    <div class="rec-cat-results" style="position:relative;z-index:1000;"></div>
                  </div>
                `);
                $catBox.find('.field-rec-cat-search').after($catList);
                $panel.append($catBox);

                // تعداد + نحوه‌ی نمایش (با گزینه‌ی رندوم)
                $panel.append(`
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">تعداد محصول:</label>
                      <input type="number" min="1" max="12" class="field-rec-count" value="${p.product_count || 4}" style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;">
                    </div>
                    <div>
                      <label style="display:block;margin-bottom:5px;font-size:11px;color:#bfdbfe;">نمایش بر اساس:</label>
                      <select class="field-rec-sort" style="width:100%;padding:8px 10px;border:1px solid #2563eb;border-radius:6px;font-size:13px;background:#0b1e4d;color:#eff6ff;cursor:pointer;">
                        <option value="latest" ${(p.sort || 'latest') === 'latest' ? 'selected' : ''}>جدیدترین</option>
                        <option value="popularity" ${p.sort === 'popularity' ? 'selected' : ''}>محبوب‌ترین</option>
                        <option value="sales" ${p.sort === 'sales' ? 'selected' : ''}>پرفروش‌ترین</option>
                        <option value="random" ${p.sort === 'random' ? 'selected' : ''}>تصادفی (رندوم)</option>
                      </select>
                    </div>
                  </div>
                `);

                $recPanelsWrap.append($panel);
              });
              $recSection.append($recPanelsWrap);
              $item.append($recSection);
            } else if (item.type === 'special_sale_carousel') {
              // ───── ساختار ویجت کاروسل فروش ویژه ─────
              const sscWidthMode = item.ssc_width_mode || 'container';
              const sscShowCountdown = item.ssc_show_countdown !== 'no';

              const $sscSection = $('<div style="background:linear-gradient(135deg,#7c2d12 0%,#c2410c 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #ea580c;box-shadow:0 4px 14px rgba(234,88,12,0.28);color:#ffedd5;"></div>');

              $sscSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.12);">
                <span style="font-size:22px;margin-left:8px;">٪</span>
                <h4 style="margin:0;color:#fff7ed;font-size:15px;font-weight:600;">تنظیمات کاروسل فروش ویژه</h4>
              </div>`);

              // عنوان + متن دکمه + لینک دکمه
              $sscSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fed7aa;">🏷️ عنوان:</label>
                    <input type="text" placeholder="فروش ویژه" class="field-ssc-title" value="${item.ssc_title || ''}" style="width:100%;padding:9px 12px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fed7aa;">متن دکمه:</label>
                    <input type="text" placeholder="مشاهده همه" class="field-ssc-view-all-text" value="${item.ssc_view_all_text || ''}" style="width:100%;padding:9px 12px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fed7aa;">🔗 لینک دکمه:</label>
                    <input type="text" placeholder="/shop" class="field-ssc-view-all-link" value="${item.ssc_view_all_link || ''}" style="width:100%;padding:9px 12px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;">
                  </div>
                </div>
              `);

              // رنگ‌های گرادینت پس‌زمینه + رنگ تاکیدی + رنگ عنوان + عرض
              $sscSection.append(`
                <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">گرادینت ۱ (بالا):</label>
                    <input type="color" class="field-ssc-bg1" value="${item.ssc_bg1 || '#ee7c2c'}" style="width:100%;height:34px;padding:2px;border:1px solid #ea580c;border-radius:6px;cursor:pointer;background:#431407;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">گرادینت ۲ (میانه):</label>
                    <input type="color" class="field-ssc-bg2" value="${item.ssc_bg2 || '#f0873c'}" style="width:100%;height:34px;padding:2px;border:1px solid #ea580c;border-radius:6px;cursor:pointer;background:#431407;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">گرادینت ۳ (پایین):</label>
                    <input type="color" class="field-ssc-bg3" value="${item.ssc_bg3 || '#f6a86e'}" style="width:100%;height:34px;padding:2px;border:1px solid #ea580c;border-radius:6px;cursor:pointer;background:#431407;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">رنگ تاکیدی (دکمه/تایمر/لیبل):</label>
                    <input type="color" class="field-ssc-accent" value="${item.ssc_accent || '#e8620e'}" style="width:100%;height:34px;padding:2px;border:1px solid #ea580c;border-radius:6px;cursor:pointer;background:#431407;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">رنگ عنوان:</label>
                    <input type="color" class="field-ssc-title-color" value="${item.ssc_title_color || '#ffffff'}" style="width:100%;height:34px;padding:2px;border:1px solid #ea580c;border-radius:6px;cursor:pointer;background:#431407;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:10px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:11px;font-weight:600;color:#fed7aa;">عرض سکشن:</label>
                    <select class="field-ssc-width-mode" style="width:100%;padding:7px 8px;border:1px solid #ea580c;border-radius:6px;font-size:12px;background:#431407;color:#fff7ed;cursor:pointer;">
                      <option value="container" ${sscWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${sscWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                </div>
              `);

              // آیکون SVG کنار عنوان
              $sscSection.append(`
                <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:block;margin-bottom:6px;font-size:12px;font-weight:600;color:#fed7aa;">آیکون کنار عنوان (کد SVG - اختیاری):</label>
                  <textarea class="field-ssc-icon" placeholder="&lt;svg ...&gt;&lt;/svg&gt; (خالی = علامت ٪)" style="width:100%;min-height:56px;padding:8px 10px;border:1px solid #ea580c;border-radius:6px;font-size:11px;background:#431407;color:#fff7ed;font-family:monospace;resize:vertical;direction:ltr;">${item.ssc_icon || ''}</textarea>
                  <div style="font-size:11px;color:#fdba74;margin-top:4px;">رنگ آیکون از رنگ عنوان ارث می‌برد؛ در SVG از <code>fill="currentColor"</code> یا <code>stroke="currentColor"</code> استفاده کنید.</div>
                </div>
              `);

              // شمارنده: فعال/غیرفعال + تاریخ پایان
              $sscSection.append(`
                <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;margin-bottom:12px;display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;">
                  <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#fff7ed;cursor:pointer;white-space:nowrap;">
                    <input type="checkbox" class="field-ssc-show-countdown" ${sscShowCountdown ? 'checked' : ''} style="width:18px;height:18px;accent-color:#fb923c;"> نمایش شمارنده
                  </label>
                  <div>
                    <label style="display:block;margin-bottom:6px;font-size:11px;color:#fed7aa;">تاریخ و ساعت پایان فروش ویژه:</label>
                    <input type="datetime-local" class="field-ssc-deadline" value="${item.ssc_deadline || ''}" style="width:100%;padding:8px 10px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;">
                  </div>
                </div>
              `);

              // انتخاب محصولات بر اساس دسته‌بندی (همان مکانیزم ویجت محصولات)
              const sscSelectedCats = item.product_cats || [];
              const $sscCatList = $('<div class="field-product-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              sscSelectedCats.forEach(cat => {
                $sscCatList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });
              $sscSection.append(`
                <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;position:relative;margin-bottom:12px;">
                  <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#fed7aa;">دسته‌بندی محصولات:</label>
                  <input type="text" class="field-product-cat-search" placeholder="🔍 جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #ea580c;border-radius:8px;font-size:13px;background:#fff;color:#111;">
                  <div class="product-cat-search-results" style="position:relative;z-index:1000;"></div>
                </div>
              `);
              $sscSection.find('.field-product-cat-search').after($sscCatList);

              // تعداد + ترتیب + مخفی‌کردن ناموجود
              $sscSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:12px;font-weight:600;color:#fed7aa;">تعداد محصول:</label>
                    <input type="number" min="1" max="30" class="field-product-count" value="${item.product_count || 10}" style="width:100%;padding:8px 12px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:12px;font-weight:600;color:#fed7aa;">ترتیب نمایش:</label>
                    <select class="field-product-sort" style="width:100%;padding:8px 12px;border:1px solid #ea580c;border-radius:6px;font-size:13px;background:#431407;color:#fff7ed;cursor:pointer;">
                      <option value="popularity"${item.product_sort === 'popularity' ? ' selected' : ''}>محبوب‌ترین</option>
                      <option value="sales"${item.product_sort === 'sales' ? ' selected' : ''}>پرفروش‌ترین</option>
                      <option value="latest"${item.product_sort === 'latest' ? ' selected' : ''}>جدیدترین</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600;color:#fff7ed;cursor:pointer;white-space:nowrap;">
                      <input type="checkbox" class="field-hide-out-of-stock"${item.hide_out_of_stock === 'yes' ? ' checked' : ''} style="width:18px;height:18px;accent-color:#fb923c;"> مخفی‌کردن ناموجود
                    </label>
                  </div>
                </div>
              `);

              $item.append($sscSection);
            } else if (item.type === 'gold_banner') {
              // ───── بنر طلا و جواهر ─────
              const gbWidthMode = item.gb_width_mode || 'container';
              const gbItems = Array.isArray(item.gb_items) && item.gb_items.length ? item.gb_items : [
                { image: '', title: 'کمتر از ۲۰ میلیون تومان', subtitle: 'محصولات مینیمال', link: '' },
                { image: '', title: '۲۰ تا ۶۰ میلیون تومان', subtitle: 'محصولات روزانه', link: '' },
                { image: '', title: '۶۰ تا ۱۰۰ میلیون تومان', subtitle: 'محصولات ویژه', link: '' },
                { image: '', title: 'بالاتر از ۱۰۰ میلیون تومان', subtitle: 'محصولات لوکس', link: '' }
              ];

              const $gbSection = $('<div style="background:linear-gradient(135deg,#3f2d0c 0%,#78551a 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #c9a227;box-shadow:0 4px 14px rgba(201,162,39,0.25);color:#fdf6e3;"></div>');

              $gbSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.12);">
                <h4 style="margin:0;color:#fdf6e3;font-size:15px;font-weight:600;">تنظیمات بنر طلا و جواهر</h4>
              </div>`);

              $gbSection.append(`
                <div style="display:grid;grid-template-columns:200px 200px;gap:12px;margin-bottom:14px;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">عرض سکشن:</label>
                    <select class="field-gb-width-mode" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;cursor:pointer;">
                      <option value="container" ${gbWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${gbWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">تعداد کارت‌ها:</label>
                    <input type="number" min="2" max="8" class="field-gb-item-count" value="${gbItems.length}" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                </div>
              `);

              const $gbItemsContainer = $('<div class="gb-items-container" style="display:flex;flex-direction:column;gap:10px;"></div>');
              gbItems.forEach((it, gi) => $gbItemsContainer.append(window.__gbRenderItem(it, gi)));
              $gbSection.append($gbItemsContainer);

              $item.append($gbSection);
            } else if (item.type === 'gold_product_carousel') {
              // ───── کاروسل محصول طلا و جواهر ─────
              const gpWidthMode = item.gp_width_mode || 'container';

              const $gpSection = $('<div style="background:linear-gradient(135deg,#3f2d0c 0%,#78551a 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #c9a227;box-shadow:0 4px 14px rgba(201,162,39,0.25);color:#fdf6e3;"></div>');

              $gpSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.12);">
                <h4 style="margin:0;color:#fdf6e3;font-size:15px;font-weight:600;">تنظیمات کاروسل محصول طلا و جواهر</h4>
              </div>`);

              $gpSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 160px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">متن «مشاهده بیشتر»:</label>
                    <input type="text" class="field-gp-more-text" value="${item.gp_more_text || 'مشاهده بیشتر'}" style="width:100%;padding:9px 12px;border:1px solid #c9a227;border-radius:6px;font-size:13px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">لینک «مشاهده بیشتر»:</label>
                    <input type="text" class="field-gp-more-link" value="${item.gp_more_link || ''}" placeholder="/shop" style="width:100%;padding:9px 12px;border:1px solid #c9a227;border-radius:6px;font-size:13px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">عرض سکشن:</label>
                    <select class="field-gp-width-mode" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;cursor:pointer;">
                      <option value="container" ${gpWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${gpWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                </div>
              `);

              // انتخاب دسته‌بندی محصولات (همان مکانیزم بقیه کاروسل‌ها)
              const gpSelectedCats = item.product_cats || [];
              const $gpCatList = $('<div class="field-product-cats-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;"></div>');
              gpSelectedCats.forEach(cat => {
                $gpCatList.append(`<span class="cat-chip" data-id="${cat.id}">${cat.name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
              });
              $gpSection.append(`
                <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;position:relative;margin-bottom:12px;">
                  <label style="display:block;margin-bottom:8px;font-size:13px;font-weight:600;color:#f5e6b8;">دسته‌بندی محصولات:</label>
                  <input type="text" class="field-product-cat-search" placeholder="جستجو کنید..." autocomplete="off" value="" style="width:100%;padding:10px 12px;border:2px solid #c9a227;border-radius:8px;font-size:13px;background:#fff;color:#111;">
                  <div class="product-cat-search-results" style="position:relative;z-index:1000;"></div>
                </div>
              `);
              $gpSection.find('.field-product-cat-search').after($gpCatList);

              $gpSection.append(`
                <div style="display:grid;grid-template-columns:160px auto;gap:12px;align-items:end;margin-bottom:14px;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:6px;font-size:12px;font-weight:600;color:#f5e6b8;">تعداد محصول:</label>
                    <input type="number" min="1" max="30" class="field-gp-product-count" value="${item.gp_product_count || 10}" style="width:100%;padding:8px 12px;border:1px solid #c9a227;border-radius:6px;font-size:13px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600;color:#fdf6e3;cursor:pointer;white-space:nowrap;">
                      <input type="checkbox" class="field-gp-hide-out-of-stock"${item.gp_hide_out_of_stock === 'yes' ? ' checked' : ''} style="width:18px;height:18px;accent-color:#c9a227;"> مخفی‌کردن ناموجود
                    </label>
                  </div>
                </div>
              `);

              // تب‌های مرتب‌سازی
              $gpSection.append(`
                <div style="background:rgba(255,255,255,0.04);padding:12px;border-radius:8px;border:1px dashed #c9a227;">
                  <div style="font-size:12px;font-weight:600;color:#f5e6b8;margin-bottom:10px;">تب‌های مرتب‌سازی (بالای اسلایدر):</div>
                  <div style="display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:center;">
                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf6e3;cursor:pointer;">
                      <input type="checkbox" class="field-gp-tab-newest"${item.gp_tab_newest !== 'no' ? ' checked' : ''} style="width:17px;height:17px;accent-color:#c9a227;"> جدیدترین
                    </label>
                    <input type="text" class="field-gp-tab-newest-label" value="${item.gp_tab_newest_label || 'جدیدترین‌ها'}" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">

                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf6e3;cursor:pointer;">
                      <input type="checkbox" class="field-gp-tab-popular"${item.gp_tab_popular !== 'no' ? ' checked' : ''} style="width:17px;height:17px;accent-color:#c9a227;"> محبوب‌ترین
                    </label>
                    <input type="text" class="field-gp-tab-popular-label" value="${item.gp_tab_popular_label || 'محبوب‌ترین‌ها'}" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">

                    <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:#fdf6e3;cursor:pointer;">
                      <input type="checkbox" class="field-gp-tab-lowwage"${item.gp_tab_lowwage !== 'no' ? ' checked' : ''} style="width:17px;height:17px;accent-color:#c9a227;"> کم‌اجرت
                    </label>
                    <input type="text" class="field-gp-tab-lowwage-label" value="${item.gp_tab_lowwage_label || 'کم‌اجرت‌ها'}" style="width:100%;padding:7px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                  <p style="margin:10px 0 0;font-size:11px;color:#e8d9a8;line-height:1.9;">تب‌ها روی همان محصولات دسته‌بندی‌های انتخاب‌شده، فقط ترتیب نمایش را عوض می‌کنند. «کم‌اجرت» بر اساس درصد اجرتِ ثبت‌شده روی محصول مرتب می‌شود.</p>
                </div>
              `);

              $item.append($gpSection);
            } else if (item.type === 'gold_categories') {
              // ───── دسته‌بندی طلا و جواهر ─────
              const gcWidthMode = item.gc_width_mode || 'container';
              const gcItems = Array.isArray(item.gc_items) && item.gc_items.length ? item.gc_items : [
                { image: '', title: 'گوشواره', link: '' },
                { image: '', title: 'انگشتر', link: '' },
                { image: '', title: 'سرویس', link: '' },
                { image: '', title: 'دستبند', link: '' },
                { image: '', title: 'گردنبند', link: '' }
              ];

              const $gcSection = $('<div style="background:linear-gradient(135deg,#3f2d0c 0%,#78551a 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #c9a227;box-shadow:0 4px 14px rgba(201,162,39,0.25);color:#fdf6e3;"></div>');

              $gcSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.12);">
                <h4 style="margin:0;color:#fdf6e3;font-size:15px;font-weight:600;">تنظیمات دسته‌بندی طلا و جواهر</h4>
              </div>`);

              $gcSection.append(`
                <div style="display:grid;grid-template-columns:200px 200px 1fr;gap:12px;margin-bottom:14px;">
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">عرض سکشن:</label>
                    <select class="field-gc-width-mode" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;cursor:pointer;">
                      <option value="container" ${gcWidthMode === 'container' ? 'selected' : ''}>کانتینر</option>
                      <option value="full" ${gcWidthMode === 'full' ? 'selected' : ''}>تمام عرض</option>
                    </select>
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">تعداد دسته‌ها:</label>
                    <input type="number" min="2" max="10" class="field-gc-item-count" value="${gcItems.length}" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                  <div style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;">
                    <label style="display:block;margin-bottom:8px;font-size:12px;font-weight:600;color:#f5e6b8;">متن دکمه هاور (دسکتاپ):</label>
                    <input type="text" class="field-gc-cta-text" value="${item.gc_cta_text || 'مشاهده'}" style="width:100%;padding:8px 10px;border:1px solid #c9a227;border-radius:6px;font-size:12px;background:#2b1d06;color:#fdf6e3;">
                  </div>
                </div>
              `);

              const $gcItemsContainer = $('<div class="gc-items-container" style="display:flex;flex-direction:column;gap:10px;"></div>');
              gcItems.forEach((it, gi) => $gcItemsContainer.append(window.__gcRenderItem(it, gi)));
              $gcSection.append($gcItemsContainer);

              $item.append($gcSection);
            } else if (item.type && window.ENG_SCHEMAS && window.ENG_SCHEMAS[item.type]) {
              // ───── ویجت‌های schema-driven (مهندسان + پلان) ─────
              $item.append(window.__engRenderWidget(item));
            } else if (typeof item.type === 'string' && item.type.indexOf('cw:') === 0) {
              // ───── ویجت سفارشی (استودیوی توسعه) ─────
              const cwKey = item.type.slice(3);
              const cwDef = window.__cwFindWidget(cwKey);

              const $cwSection = $('<div style="background:linear-gradient(135deg,#0c4a6e 0%,#155e75 100%);padding:18px;margin:10px 0;border-radius:12px;border:2px solid #0e7490;box-shadow:0 4px 14px rgba(14,116,144,0.25);color:#ecfeff;"></div>');

              if (!cwDef) {
                $cwSection.append('<div style="padding:10px;font-size:13px;color:#fecaca;">ویجت سفارشی «' + cwKey + '» یافت نشد. شاید حذف شده باشد.</div>');
              } else {
                $cwSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.1);">
                  <h4 style="margin:0;color:#cffafe;font-size:15px;font-weight:600;">${cwDef.label || cwKey}</h4>
                  ${cwDef.description ? `<span style="margin-right:10px;font-size:12px;color:#7dd3fc;">${cwDef.description}</span>` : ''}
                </div>`);

                const cwData = (item.cw_data && typeof item.cw_data === 'object') ? item.cw_data : {};
                const simple = [];

                (cwDef.fields || []).forEach(function (f) {
                  if (!f || !f.key) return;
                  if (f.type === 'repeater') {
                    // فیلدهای تکرارشونده تمام‌عرض رندر می‌شوند
                    return;
                  }
                  simple.push(window.__cwFieldHtml(f, cwData[f.key] !== undefined ? cwData[f.key] : (f.default || '')));
                });

                if (simple.length) {
                  $cwSection.append('<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:12px;">' + simple.join('') + '</div>');
                }

                (cwDef.fields || []).forEach(function (f) {
                  if (!f || !f.key || f.type !== 'repeater') return;
                  $cwSection.append('<div style="margin-bottom:12px;">' + window.__cwRepeaterHtml(f, cwData[f.key]) + '</div>');
                });
              }

              $item.append($cwSection);
            } else if (item.type === 'banner_slider') {
              // ساختار اسلایدر بنر
              const $bannerSliderSection = $('<div style="background:linear-gradient(135deg, #fce4ec 0%, #f3e5f5 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #f8bbd0;box-shadow:0 2px 8px rgba(233,30,99,0.15);"></div>');

              $bannerSliderSection.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.7);">
                <span style="font-size:20px;margin-left:8px;">🎠</span>
                <h4 style="margin:0;color:#000000;font-size:15px;font-weight:600;">تنظیمات اسلایدر بنر</h4>
              </div>`);

              // نیمه اول و دوم عنوان + رنگ
              $bannerSliderSection.append(`
                <div style="display:grid;grid-template-columns:1fr 1fr 100px;gap:12px;margin-bottom:12px;">
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">نیمه اول عنوان سکشن:</label>
                    <input type="text" placeholder="نیمه اول عنوان" class="field-banner-slider-title-first" value="${item.banner_slider_title_first || ''}" style="width:100%;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">نیمه دوم عنوان سکشن:</label>
                    <input type="text" placeholder="نیمه دوم عنوان" class="field-banner-slider-title-second" value="${item.banner_slider_title_second || ''}" style="width:100%;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                  <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">رنگ نیمه اول:</label>
                    <input type="color" class="field-banner-slider-title-color" value="${item.banner_slider_title_color || '#000000'}" style="width:100%;height:36px;padding:2px;border:1px solid #f8bbd0;border-radius:6px;cursor:pointer;">
                  </div>
                </div>
              `);

              // تعداد اسلاید
              $bannerSliderSection.append(`
                <div style="background:rgba(255,255,255,0.8);padding:12px;border-radius:8px;margin-bottom:12px;">
                  <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">تعداد اسلاید:</label>
                  <input type="number" min="1" max="10" class="field-banner-slider-count" value="${item.banner_slider_count || 1}" style="width:80px;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                </div>
              `);

              // اسلایدها
              let bsSlides = item.banner_slider_slides || [];
              const bsSlideCount = parseInt(item.banner_slider_count) || 1;
              while (bsSlides.length < bsSlideCount) {
                bsSlides.push({ image: '', category: '', title: '', description: '', link: '' });
              }
              while (bsSlides.length > bsSlideCount) {
                bsSlides.pop();
              }

              const $bsSlidesContainer = $('<div class="banner-slider-slides-container" style="width:100%;"></div>');
              bsSlides.forEach((bsSlide, bsIdx) => {
                const $bsSlideItem = $('<div class="banner-slider-slide-item" style="background:rgba(255,255,255,0.9);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #f8bbd0;box-shadow:0 2px 6px rgba(233,30,99,0.1);transition:all 0.3s ease;"></div>');

                $bsSlideItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid #fce4ec;">
                  <span style="font-size:18px;margin-left:8px;">🖼️</span>
                  <h4 style="margin:0;color:#c2185b;font-size:14px;font-weight:600;">اسلاید شماره ${bsIdx + 1}</h4>
                </div>`);

                // تصویر اسلاید
                const bsImagePreview = bsSlide.image
                  ? `<div style="margin-top:8px;"><img src="${bsSlide.image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
                  : '';
                $bsSlideItem.append(`
                  <div style="margin-bottom:12px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">تصویر:</label>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                      <input type="text" placeholder="آدرس تصویر" class="field-bs-slide-image" value="${bsSlide.image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                      <button type="button" class="button button-primary button-upload-banner-slider" data-bs-slide="${bsIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">📁 انتخاب تصویر</button>
                    </div>
                    ${bsImagePreview}
                  </div>
                `);

                // دسته‌بندی
                $bsSlideItem.append(`
                  <div style="margin-bottom:12px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">دسته‌بندی:</label>
                    <input type="text" placeholder="مثل: لوازم آرایشی" class="field-bs-slide-category" value="${bsSlide.category || ''}" style="width:100%;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                // عنوان اسلاید
                $bsSlideItem.append(`
                  <div style="margin-bottom:12px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">عنوان اسلاید:</label>
                    <input type="text" placeholder="عنوان" class="field-bs-slide-title" value="${bsSlide.title || ''}" style="width:100%;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                // توضیحات
                $bsSlideItem.append(`
                  <div style="margin-bottom:12px;">
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">توضیحات:</label>
                    <textarea placeholder="توضیحات اسلاید" class="field-bs-slide-description" style="width:100%;min-height:60px;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;resize:vertical;">${bsSlide.description || ''}</textarea>
                  </div>
                `);

                // لینک
                $bsSlideItem.append(`
                  <div>
                    <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#000000;">لینک:</label>
                    <input type="text" placeholder="https://example.com" class="field-bs-slide-link" value="${bsSlide.link || ''}" style="width:100%;padding:8px 12px;border:1px solid #f8bbd0;border-radius:6px;font-size:13px;background:#fff;">
                  </div>
                `);

                $bsSlidesContainer.append($bsSlideItem);
              });

              $bannerSliderSection.append($bsSlidesContainer);
              $item.append($bannerSliderSection);
            }

          } else if (name === 'about_boxes') {
            $item.append(`<input type="text" placeholder="عنوان" class="field-title" value="${item.title || ''}">`);
            $item.append(`<input type="text" placeholder="توضیح کوتاه" class="field-small-text" value="${item.short_desc || ''}">`);
            $item.append(`<input type="text" placeholder="آدرس تصویر" class="field-image" value="${item.image || ''}" style="width:180px;">`);
            $item.append(`<button type="button" class="button button-upload">انتخاب تصویر</button>`);
            if (item.image) $item.append(`<img src="${item.image}" class="field-image-preview">`);
          } else if (name === 'stories_list') {
            // UI استوری‌ها
            const $storyCard = $('<div class="story-card" style="background:linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);padding:20px;border-radius:16px;border:2px solid #cbd5e0;box-shadow:0 4px 12px rgba(0,0,0,0.1);"></div>');

            // عنوان استوری
            $storyCard.append(`
              <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  عنوان استوری:
                </label>
                <input type="text" placeholder="مثال: محصولات جدید" class="field-story-title" value="${item.title || ''}" style="width:100%;padding:10px 12px;border:1px solid#cbd5e0;border-radius:8px;font-size:14px;background:#fff;">
              </div>
            `);

            // تصویر شاخص
            const thumbnailPreview = item.thumbnail
              ? `<div style="margin-top:10px;"><img src="${item.thumbnail}" class="field-image-preview" style="width:100px;height:100px;object-fit:cover;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.15);"></div>`
              : '';
            $storyCard.append(`
              <div style="margin-bottom:16px;background:rgba(255,255,255,0.7);padding:14px;border-radius:10px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  تصویر شاخص (Thumbnail):
                </label>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر شاخص" class="field-story-thumbnail" value="${item.thumbnail || ''}" style="flex:1;min-width:200px;padding:10px 12px;border:1px solid #cbd5e0;border-radius:8px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-story-thumbnail" style="padding:10px 18px;font-size:13px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.1);">
                    انتخاب تصویر
                  </button>
                </div>
                ${thumbnailPreview}
              </div>
            `);

            // تعداد محتوا
            $storyCard.append(`
              <div style="margin-bottom:16px;">
                <label style="display:block;margin-bottom:8px;font-size:14px;font-weight:600;color:#2d3748;">
                  تعداد محتوا (تصاویر/ویدیوها):
                </label>
                <input type="number" min="1" max="10" class="field-story-images-count" data-story-id="${item._uuid}" value="${(item.images && item.images.length) || 1}" style="width:100px;padding:10px 12px;border:1px solid #cbd5e0;border-radius:8px;font-size:14px;background:#fff;">
              </div>
            `);

            // لیست محتوا
            const $imagesContainer = $('<div class="story-images-container" style="margin-top:16px;"></div>');
            let images = item.images || [{ url: '', caption: '', type: 'image' }];

            images.forEach((img, imgIdx) => {
              const $imageItem = $('<div class="story-image-item" style="background:rgba(255,255,255,0.9);padding:16px;margin:12px 0;border-radius:12px;border:2px solid #e2e8f0;box-shadow:0 2px 6px rgba(0,0,0,0.08);"></div>');

              $imageItem.append(`
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:10px;border-bottom:2px solid #e2e8f0;">
                  <h4 style="margin:0;color:#4a5568;font-size:14px;font-weight:600;">محتوا ${imgIdx + 1}</h4>
                  <button type="button" class="button button-small remove-story-image-btn" data-img-idx="${imgIdx}" style="background:#e53935;color:#fff;padding:4px 12px;border-radius:6px;font-size:12px;">حذف</button>
                </div>
              `);

              // نوع محتوا
              $imageItem.append(`
                <div style="margin-bottom:12px;">
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    نوع محتوا:
                  </label>
                  <select class="field-story-image-type" data-img-idx="${imgIdx}" style="width:100%;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                    <option value="image" ${img.type === 'image' ? 'selected' : ''}>تصویر</option>
                    <option value="video" ${img.type === 'video' ? 'selected' : ''}>ویدیو</option>
                  </select>
                </div>
              `);

              // URL محتوا
              const mediaPreview = img.url
                ? (img.type === 'video'
                  ? `<div style="margin-top:10px;"><video src="${img.url}" controls style="max-width:200px;max-height:150px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></video></div>`
                  : `<div style="margin-top:10px;"><img src="${img.url}" class="field-image-preview" style="max-width:200px;max-height:150px;object-fit:cover;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`)
                : '';

              $imageItem.append(`
                <div style="margin-bottom:12px;">
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    آدرس ${img.type === 'video' ? 'ویدیو' : 'تصویر'}:
                  </label>
                  <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <input type="text" placeholder="آدرس محتوا" class="field-story-image-url" data-img-idx="${imgIdx}" value="${img.url || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                    <button type="button" class="button button-primary button-upload-story-image" data-img-idx="${imgIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                      انتخاب
                    </button>
                  </div>
                  ${mediaPreview}
                </div>
              `);

              // کپشن
              $imageItem.append(`
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:13px;font-weight:600;color:#4a5568;">
                    توضیحات (Caption):
                  </label>
                  <input type="text" placeholder="توضیح کوتاه برای این محتوا" class="field-story-image-caption" data-img-idx="${imgIdx}" value="${img.caption || ''}" style="width:100%;padding:8px 12px;border:1px solid #cbd5e0;border-radius:6px;font-size:13px;background:#fff;">
                </div>
              `);

              $imagesContainer.append($imageItem);
            });

            // دکمه افزودن محتوا
            if (images.length < 10) {
              $imagesContainer.append(`
                <button type="button" class="button button-secondary add-story-image-btn" style="margin-top:10px;width:100%;padding:10px;border-radius:8px;background:#48bb78;color:#fff;font-size:14px;font-weight:600;">
                  + افزودن محتوا
                </button>
              `);
            }

            $storyCard.append($imagesContainer);
            $item.append($storyCard);
          }

          const $removeBtn = $('<button type="button" class="button">حذف</button>');
          $removeBtn.on('click', function () {
            const id = $(this).closest('.custom-list-item').data('id');
            items = items.filter(i => i._uuid !== id);
            save();
            render();
          });

          $item.append($removeBtn);
          $list.append($item);
        });


        let canAdd = true;
        if (isAboutBoxes && items.length >= 4) canAdd = false;
        if (canAdd) {
          const $addBtn = $('<button type="button" class="button button-primary" style="margin-top:5px;">افزودن آیتم جدید</button>');
          $addBtn.on('click', function () {
            let newItem;
            if (name === 'about_boxes') {
              newItem = { title: '', short_desc: '', image: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'slider') {
              newItem = { discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'user_panel_slider') {
              newItem = { image: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'product_categories') {
              newItem = { icon: '', name: '', link: '', new_tab: 'no', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'socials') {
              newItem = { icon: '', name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'site_menu') {
              newItem = { name: '', link: '', icon: '', children: [], _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'navbar_menu') {
              newItem = { name: '', link: '', new_tab: 'no', children: [], _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'job_positions_list') {
              newItem = { title: '', description: '', job_type: 'تمام وقت', skills: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'faq_list') {
              newItem = { question: '', answer: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'stories_list') {
              newItem = {
                title: '',
                thumbnail: '',
                images: [{ url: '', caption: '', type: 'image' }],
                _uuid: Math.random().toString(36).substring(2, 10)
              };
            } else if (name === 'site_badges') {
              newItem = { html: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'footer_menu_1' || name === 'footer_menu_2' || name === 'gold_header_links') {
              newItem = { name: '', link: '', _uuid: Math.random().toString(36).substring(2, 10) };
            } else if (name === 'home_sections') {
              let defaultType = 'products';

              newItem = {
                type: defaultType,
                icon: '',
                name: '',
                link: '',
                product_cats: [],
                product_count: 4,
                product_sort: 'popularity',
                hide_out_of_stock: 'no',
                auto_slide: 'no',
                auto_slide_speed: 3000,
                blog_cats: [],
                html: '',
                banner_count: 1,
                banner_style: 'style1',
                banners: [{ desktop_image: '', mobile_image: '', alt: '', link: '', new_tab: 'no' }],
                slider_style: 'style1',
                slider_count: 1,
                slides: [{ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' }],
                logo_count: 1,
                logos: [{ image: '', link: '', alt: '' }],
                banner_slider_title_first: '',
                banner_slider_title_second: '',
                banner_slider_title_color: '#000000',
                banner_slider_count: 1,
                banner_slider_slides: [{ image: '', category: '', title: '', description: '', link: '' }],
                hero_title: '',
                hero_subtitle: '',
                hero_btn_text: '',
                hero_btn_link: '',
                hero_btn2_text: '',
                hero_btn2_link: '',
                hero_bg_style: 'letter_glitch',
                hero_align: 'center',
                hero_width_mode: 'container',
                hero_height: 60,
                hero_text_color: '#ffffff',
                hero_overlay_opacity: 40,
                hero_glitch_colors: ['#2b4539', '#61dca3', '#61b3dc'],
                hero_glitch_speed: 50,
                hero_outer_vignette: 'yes',
                hero_center_vignette: 'no',
                hero_beams_light_color: '#ffffff',
                hero_beams_number: 12,
                hero_beams_speed: 2,
                hero_beams_noise: 1.75,
                hero_beams_scale: 0.2,
                hero_beams_rotation: 0,
                hero_beams_width: 2,
                hero_beams_height: 15,
                cs_title: '',
                cs_subtitle: '',
                cs_btn_text: '',
                cs_btn_link: '',
                cs_width_mode: 'container',
                cs_align: 'right',
                cs_height: 600,
                cs_bg_color: '#0f172a',
                cs_text_color: '#ffffff',
                cs_card_bar_bg: '#000000',
                cs_card_bar_text: '#ffffff',
                cs_card_distance: 60,
                cs_vertical_distance: 70,
                cs_delay: 5000,
                cs_skew: 6,
                cs_easing: 'elastic',
                cs_pause_on_hover: 'no',
                cs_cards: [
                  { image: '', icon: '', title: 'کارت ۱', link: '' },
                  { image: '', icon: '', title: 'کارت ۲', link: '' },
                  { image: '', icon: '', title: 'کارت ۳', link: '' }
                ],
                bf_title: '',
                bf_subtitle: '',
                bf_title_color: '#ffffff',
                bf_subtitle_color: '#a1a1aa',
                bf_width_mode: 'container',
                bf_glow_color: '132, 0, 255',
                bf_spotlight_radius: 400,
                bf_particle_count: 12,
                bf_text_auto_hide: 'yes',
                bf_enable_stars: 'yes',
                bf_enable_spotlight: 'yes',
                bf_enable_border_glow: 'yes',
                bf_enable_tilt: 'no',
                bf_enable_magnetism: 'no',
                bf_click_effect: 'yes',
                bf_disable_animations: 'no',
                bf_items: [
                  { label: 'Analytics', title: 'تحلیل پیشرفته', description: 'رفتار کاربر را زیر نظر بگیرید', icon: '📊', color: '#120F17', image: '', link: '' },
                  { label: 'Dashboard', title: 'داشبورد یکپارچه', description: 'نمای متمرکز داده‌ها', icon: '🧭', color: '#120F17', image: '', link: '' },
                  { label: 'Collaboration', title: 'همکاری تیمی', description: 'با هم بی‌وقفه کار کنید', icon: '🤝', color: '#120F17', image: '', link: '' },
                  { label: 'Automation', title: 'اتوماسیون', description: 'فرآیندها را خودکار کنید', icon: '⚡', color: '#120F17', image: '', link: '' },
                  { label: 'Integration', title: 'یکپارچه‌سازی', description: 'به ابزارهای محبوب وصل شوید', icon: '🔌', color: '#120F17', image: '', link: '' },
                  { label: 'Security', title: 'امنیت سازمانی', description: 'محافظت در سطح Enterprise', icon: '🔒', color: '#120F17', image: '', link: '' }
                ],
                cn_title: '',
                cn_width_mode: 'container',
                cn_accent_color: '#ff6a3d',
                cn_categories: [
                  { name: 'دسته ۱', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] },
                  { name: 'دسته ۲', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] }
                ],
                gb_width_mode: 'container',
                gb_items: [
                  { image: '', title: 'کمتر از ۲۰ میلیون تومان', subtitle: 'محصولات مینیمال', link: '' },
                  { image: '', title: '۲۰ تا ۶۰ میلیون تومان', subtitle: 'محصولات روزانه', link: '' },
                  { image: '', title: '۶۰ تا ۱۰۰ میلیون تومان', subtitle: 'محصولات ویژه', link: '' },
                  { image: '', title: 'بالاتر از ۱۰۰ میلیون تومان', subtitle: 'محصولات لوکس', link: '' }
                ],
                gp_more_text: 'مشاهده بیشتر',
                gp_more_link: '',
                gp_width_mode: 'container',
                gp_product_count: 10,
                gp_hide_out_of_stock: 'no',
                gp_tab_newest: 'yes',
                gp_tab_newest_label: 'جدیدترین‌ها',
                gp_tab_popular: 'yes',
                gp_tab_popular_label: 'محبوب‌ترین‌ها',
                gp_tab_lowwage: 'yes',
                gp_tab_lowwage_label: 'کم‌اجرت‌ها',
                gc_width_mode: 'container',
                gc_cta_text: 'مشاهده',
                gc_items: [
                  { image: '', title: 'گوشواره', link: '' },
                  { image: '', title: 'انگشتر', link: '' },
                  { image: '', title: 'سرویس', link: '' },
                  { image: '', title: 'دستبند', link: '' },
                  { image: '', title: 'گردنبند', link: '' }
                ],
                ssc_title: 'فروش ویژه',
                ssc_view_all_text: 'مشاهده همه',
                ssc_view_all_link: '',
                ssc_bg1: '#ee7c2c',
                ssc_bg2: '#f0873c',
                ssc_bg3: '#f6a86e',
                ssc_accent: '#e8620e',
                ssc_title_color: '#ffffff',
                ssc_icon: '',
                ssc_width_mode: 'container',
                ssc_show_countdown: 'yes',
                ssc_deadline: '',
                rec_width_mode: 'container',
                rec_panels: [
                  { title: 'لوازم مکانیکی', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' },
                  { title: 'روغن موتور', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' },
                  { title: 'چراغ خودرو', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' }
                ],
                _uuid: Math.random().toString(36).substring(2, 10)
              };
              // افزودن defaults همه ویجت‌های لندینگ مهندسان
              newItem = Object.assign(window.__engAllDefaults(), newItem);
            }
            items.push(newItem);
            save();
            render();
          });
          $wrapper.append($list).append($addBtn);
        } else {
          $wrapper.append($list);
        }
      }

      function save() {
        // همگام‌سازی DOM → items داخل try انجام می‌شود تا اگر یک ویجت هنگام خواندن
        // فیلدهایش خطا داد، باز هم آرایهٔ سکشن‌ها در textarea نوشته شود.
        // پیش از این، خطای یک ویجت باعث می‌شد کل چیدمان ذخیره نشود.
        try {
        $wrapper.find('.custom-list-item').each(function () {
          const $item = $(this);
          const id = $item.data('id');
          const index = items.findIndex(i => i._uuid === id);
          if (index !== -1) {
            if (name === 'about_boxes') {
              items[index].title = $item.find('.field-title').val();
              items[index].short_desc = $item.find('.field-small-text').val();
              items[index].image = $item.find('.field-image').val();
            } else if (name === 'slider') {
              items[index].discount_title = $item.find('.field-discount-title').val();
              items[index].date_fa = $item.find('.field-date').val();
              items[index].time = $item.find('.field-time').val();
              items[index].title = $item.find('.field-title').val();
              items[index].image = $item.find('.field-image').val();
              items[index].small_text = $item.find('.field-small-text').val();
              items[index].link = $item.find('.field-link').val();

              var dateFa = items[index].date_fa;
              var time = items[index].time;
              if (dateFa && time && window.persianDate) {
                try {
                  var pd = new persianDate().parse(dateFa + ' ' + time);
                  var g = pd.toGregorian();
                  var gDate = new Date(g.year, g.month - 1, g.day, ...time.split(':'));
                  items[index].date_gregorian = gDate.toISOString();
                } catch (e) {
                  items[index].date_gregorian = '';
                }
              } else {
                items[index].date_gregorian = '';
              }
            } else if (items[index].type === 'logo_slider') {
              items[index].name = $item.find('.field-name').val();
              items[index].logo_count = $item.find('.field-logo-count').val();
              items[index].logos = [];
              $item.find('.logo-item').each(function () {
                const $logoItem = $(this);
                items[index].logos.push({
                  image: $logoItem.find('.field-logo-image').val(),
                  link: $logoItem.find('.field-logo-link').val(),
                  alt: $logoItem.find('.field-logo-alt').val()
                });
              });
            }

            else if (name === 'user_panel_slider') {
              items[index].image = $item.find('.field-image').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'product_categories') {
              items[index].icon = $item.find('.field-icon').val();
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
              items[index].new_tab = $item.find('.field-new-tab').is(':checked') ? 'yes' : 'no';
            } else if (name === 'socials') {
              items[index].icon = $item.find('.field-icon').val();
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'site_menu') {
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
              items[index].icon = $item.find('.field-icon').val();

              // ذخیره زیرمنوها (سطح ۲ و ۳)
              items[index].children = [];
              $item.find('.children-list > .submenu-item').each(function () {
                const $subItem = $(this);
                const childName = $subItem.find('> div:first .field-child-name').val();
                const childLink = $subItem.find('> div:first .field-child-link').val();
                const childId = $subItem.data('child-id');

                if (childName || childLink) {
                  // ذخیره آیتم‌های سطح ۳
                  const grandchildren = [];
                  $subItem.find('.grandchildren-list .grandchild-item').each(function () {
                    const $gcItem = $(this);
                    const gcName = $gcItem.find('.field-grandchild-name').val();
                    const gcLink = $gcItem.find('.field-grandchild-link').val();
                    const gcId = $gcItem.data('grandchild-id');
                    if (gcName || gcLink) {
                      grandchildren.push({
                        _uuid: gcId,
                        name: gcName,
                        link: gcLink
                      });
                    }
                  });

                  items[index].children.push({
                    _uuid: childId,
                    name: childName,
                    link: childLink,
                    children: grandchildren
                  });
                }
              });
            } else if (name === 'navbar_menu') {
              items[index].name = $item.find('.field-name').first().val();
              items[index].link = $item.find('.field-link').first().val();
              items[index].new_tab = $item.find('.field-new-tab').first().is(':checked') ? 'yes' : 'no';
              items[index].children = [];
              $item.find('.nav-child').each(function () {
                const $c = $(this);
                const cName = $c.find('.nav-child-name').val();
                const cLink = $c.find('.nav-child-link').val();
                if (cName || cLink) {
                  items[index].children.push({
                    name: cName,
                    link: cLink,
                    new_tab: $c.find('.nav-child-new-tab').is(':checked') ? 'yes' : 'no'
                  });
                }
              });
            } else if (name === 'job_positions_list') {
              items[index].title = $item.find('.field-title').val();
              items[index].description = $item.find('.field-description').val();
              items[index].job_type = $item.find('.field-job-type').val();
              items[index].skills = $item.find('.field-skills').val();
            } else if (name === 'faq_list') {
              items[index].question = $item.find('.field-question').val();
              items[index].answer = $item.find('.field-answer').val();
            } else if (name === 'stories_list') {
              items[index].title = $item.find('.field-story-title').val();
              items[index].thumbnail = $item.find('.field-story-thumbnail').val();
              items[index].images = [];
              $item.find('.story-image-item').each(function () {
                const $imgItem = $(this);
                const imgIdx = $imgItem.find('.field-story-image-type').data('img-idx');
                items[index].images.push({
                  url: $imgItem.find('.field-story-image-url').val(),
                  caption: $imgItem.find('.field-story-image-caption').val(),
                  type: $imgItem.find('.field-story-image-type').val()
                });
              });
            } else if (name === 'site_badges') {
              items[index].html = $item.find('.field-html').val();
            } else if (name === 'footer_menu_1' || name === 'footer_menu_2' || name === 'gold_header_links') {
              items[index].name = $item.find('.field-name').val();
              items[index].link = $item.find('.field-link').val();
            } else if (name === 'home_sections') {
              items[index].type = $item.find('.field-section-type').val();
              if (items[index].type === 'products') {
                items[index].icon = $item.find('.field-icon').val();
                items[index].name = $item.find('.field-name').val();
                items[index].link = $item.find('.field-link').val();

                items[index].product_cats = [];
                $item.find('.field-product-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].product_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].product_sort = $item.find('.field-product-sort').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
                items[index].auto_slide = $item.find('.field-auto-slide').is(':checked') ? 'yes' : 'no';
                items[index].auto_slide_speed = $item.find('.field-auto-slide-speed').val();
              } else if (items[index].type === 'special_products') {
                items[index].icon = $item.find('.field-icon').val();
                items[index].name = $item.find('.field-name').val();
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].product_sort = $item.find('.field-product-sort').val();
                items[index].view_all_link = $item.find('.field-view-all-link').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
              } else if (items[index].type === 'blog_posts') {
                items[index].blog_cats = [];
                $item.find('.field-blog-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].blog_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
              } else if (items[index].type === 'custom_html') {
                items[index].html = $item.find('.field-html').val();
              } else if (items[index].type === 'banners') {
                items[index].banner_count = $item.find('.field-banner-count').val();
                items[index].banner_style = $item.find('.field-banner-style').val();
                items[index].banner_new_tab = $item.find('.field-banner-new-tab').is(':checked') ? 'yes' : 'no';
                items[index].banners = [];
                $item.find('.banner-item').each(function () {
                  const $bannerItem = $(this);
                  items[index].banners.push({
                    desktop_image: $bannerItem.find('.field-banner-desktop-image').val(),
                    mobile_image: $bannerItem.find('.field-banner-mobile-image').val(),
                    alt: $bannerItem.find('.field-banner-alt').val() || '',
                    link: $bannerItem.find('.field-banner-link').val(),
                    new_tab: $bannerItem.find('.field-banner-new-tab-single').is(':checked') ? 'yes' : 'no'
                  });
                });
              } else if (items[index].type === 'slider') {
                items[index].slider_style = $item.find('.field-slider-style').val();
                items[index].slider_count = $item.find('.field-slider-count').val();
                items[index].slider_new_tab = $item.find('.field-slider-new-tab').is(':checked') ? 'yes' : 'no';
                items[index].slides = [];
                $item.find('.slide-item').each(function () {
                  const $slideItem = $(this);
                  const style = items[index].slider_style;

                  if (style === 'style1') {
                    items[index].slides.push({
                      discount_title: $slideItem.find('.field-slide-discount-title').val(),
                      date_fa: $slideItem.find('.field-slide-date').val(),
                      time: $slideItem.find('.field-slide-time').val(),
                      title: $slideItem.find('.field-slide-title').val(),
                      image: $slideItem.find('.field-slide-image').val(),
                      small_text: $slideItem.find('.field-slide-small-text').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style2') {
                    items[index].slides.push({
                      small_text: $slideItem.find('.field-slide-small-text').val(),
                      title: $slideItem.find('.field-slide-title').val(),
                      image: $slideItem.find('.field-slide-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style3') {
                    items[index].slides.push({
                      desktop_image: $slideItem.find('.field-slide-desktop-image').val(),
                      mobile_image: $slideItem.find('.field-slide-mobile-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style4') {
                    items[index].slides.push({
                      desktop_image: $slideItem.find('.field-slide-desktop-image').val(),
                      mobile_image: $slideItem.find('.field-slide-mobile-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  } else if (style === 'style5') {
                    items[index].slides.push({
                      desktop_image: $slideItem.find('.field-slide-desktop-image').val(),
                      mobile_image: $slideItem.find('.field-slide-mobile-image').val(),
                      link: $slideItem.find('.field-slide-link').val()
                    });
                  }
                });
              } else if (items[index].type === 'spacer') {
                items[index].height = $item.find('.field-spacer-height').val();
              } else if (items[index].type === 'site_description_box') {

                items[index] = { type: 'site_description_box', _uuid: items[index]._uuid };
              } else if (items[index].type === 'brick_products') {
                items[index].icon = $item.find('.field-icon').val();
                items[index].name = $item.find('.field-name').val();
                items[index].link = $item.find('.field-link').val();

                items[index].product_cats = [];
                $item.find('.field-product-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].product_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].brick_style = $item.find('.field-brick-style').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
              } else if (items[index].type === 'currency_price') {
                items[index].currency_title = $item.find('.field-currency-title').val();
                items[index].currency_subtitle = $item.find('.field-currency-subtitle').val();
                items[index].currency_name = $item.find('.field-currency-name').val();
                items[index].currency_unit = $item.find('.field-currency-unit').val();
                items[index].price_source = $item.find('.field-currency-price-source:checked').val() || 'manual';
                items[index].dynamic_currency = $item.find('.field-currency-dynamic-currency').val() || '';
                items[index].price_per_unit = $item.find('.field-currency-price-per-unit').val();
                items[index].price_label = $item.find('.field-currency-price-label').val();
                items[index].buy_label = $item.find('.field-currency-buy-label').val();
                items[index].sell_label = $item.find('.field-currency-sell-label').val();
                items[index].input_placeholder = $item.find('.field-currency-input-placeholder').val();
                items[index].weight_placeholder = $item.find('.field-currency-weight-placeholder').val();
                items[index].amount_unit = $item.find('.field-currency-amount-unit').val();
                items[index].button_text = $item.find('.field-currency-button-text').val();
                items[index].bg_color = $item.find('.field-currency-bg-color').val();
                items[index].accent_color = $item.find('.field-currency-accent-color').val();
              } else if (items[index].type === 'hero') {
                items[index].hero_title = $item.find('.field-hero-title').val();
                items[index].hero_subtitle = $item.find('.field-hero-subtitle').val();
                items[index].hero_btn_text = $item.find('.field-hero-btn-text').val();
                items[index].hero_btn_link = $item.find('.field-hero-btn-link').val();
                items[index].hero_btn2_text = $item.find('.field-hero-btn2-text').val();
                items[index].hero_btn2_link = $item.find('.field-hero-btn2-link').val();
                items[index].hero_bg_style = $item.find('.field-hero-bg-style').val();
                items[index].hero_align = $item.find('.field-hero-align').val();
                items[index].hero_width_mode = $item.find('.field-hero-width-mode').val();
                items[index].hero_height = $item.find('.field-hero-height').val();
                items[index].hero_text_color = $item.find('.field-hero-text-color').val();
                items[index].hero_overlay_opacity = $item.find('.field-hero-overlay-opacity').val();
                items[index].hero_glitch_colors = [
                  $item.find('.field-hero-color-1').val(),
                  $item.find('.field-hero-color-2').val(),
                  $item.find('.field-hero-color-3').val()
                ];
                items[index].hero_glitch_speed = $item.find('.field-hero-glitch-speed').val();
                items[index].hero_outer_vignette = $item.find('.field-hero-outer-vignette').is(':checked') ? 'yes' : 'no';
                items[index].hero_center_vignette = $item.find('.field-hero-center-vignette').is(':checked') ? 'yes' : 'no';
                // beams specific
                items[index].hero_beams_light_color = $item.find('.field-hero-beams-light-color').val();
                items[index].hero_beams_number = $item.find('.field-hero-beams-number').val();
                items[index].hero_beams_speed = $item.find('.field-hero-beams-speed').val();
                items[index].hero_beams_noise = $item.find('.field-hero-beams-noise').val();
                items[index].hero_beams_scale = $item.find('.field-hero-beams-scale').val();
                items[index].hero_beams_rotation = $item.find('.field-hero-beams-rotation').val();
                items[index].hero_beams_width = $item.find('.field-hero-beams-width').val();
                items[index].hero_beams_height = $item.find('.field-hero-beams-height').val();
              } else if (items[index].type === 'card_swap') {
                items[index].cs_title = $item.find('.field-cs-title').val();
                items[index].cs_subtitle = $item.find('.field-cs-subtitle').val();
                items[index].cs_btn_text = $item.find('.field-cs-btn-text').val();
                items[index].cs_btn_link = $item.find('.field-cs-btn-link').val();
                items[index].cs_width_mode = $item.find('.field-cs-width-mode').val();
                items[index].cs_align = $item.find('.field-cs-align').val();
                items[index].cs_height = $item.find('.field-cs-height').val();
                items[index].cs_bg_color = $item.find('.field-cs-bg-color').val();
                items[index].cs_text_color = $item.find('.field-cs-text-color').val();
                items[index].cs_card_bar_bg = $item.find('.field-cs-card-bar-bg').val();
                items[index].cs_card_bar_text = $item.find('.field-cs-card-bar-text').val();
                items[index].cs_card_distance = $item.find('.field-cs-card-distance').val();
                items[index].cs_vertical_distance = $item.find('.field-cs-vertical-distance').val();
                items[index].cs_delay = $item.find('.field-cs-delay').val();
                items[index].cs_skew = $item.find('.field-cs-skew').val();
                items[index].cs_easing = $item.find('.field-cs-easing').val();
                items[index].cs_pause_on_hover = $item.find('.field-cs-pause-on-hover').is(':checked') ? 'yes' : 'no';
                items[index].cs_cards = [];
                $item.find('.cs-card-item').each(function () {
                  const $c = $(this);
                  items[index].cs_cards.push({
                    image: $c.find('.field-cs-card-image').val(),
                    icon: $c.find('.field-cs-card-icon').val(),
                    title: $c.find('.field-cs-card-title').val(),
                    link: $c.find('.field-cs-card-link').val()
                  });
                });
              } else if (items[index].type === 'bento_features') {
                items[index].bf_title = $item.find('.field-bf-title').val();
                items[index].bf_subtitle = $item.find('.field-bf-subtitle').val();
                items[index].bf_title_color = $item.find('.field-bf-title-color').val();
                items[index].bf_subtitle_color = $item.find('.field-bf-subtitle-color').val();
                items[index].bf_width_mode = $item.find('.field-bf-width-mode').val();
                items[index].bf_glow_color = $item.find('.field-bf-glow-color').val();
                items[index].bf_spotlight_radius = $item.find('.field-bf-spotlight-radius').val();
                items[index].bf_particle_count = $item.find('.field-bf-particle-count').val();
                items[index].bf_text_auto_hide = $item.find('.field-bf-text-auto-hide').is(':checked') ? 'yes' : 'no';
                items[index].bf_enable_stars = $item.find('.field-bf-enable-stars').is(':checked') ? 'yes' : 'no';
                items[index].bf_enable_spotlight = $item.find('.field-bf-enable-spotlight').is(':checked') ? 'yes' : 'no';
                items[index].bf_enable_border_glow = $item.find('.field-bf-enable-border-glow').is(':checked') ? 'yes' : 'no';
                items[index].bf_enable_tilt = $item.find('.field-bf-enable-tilt').is(':checked') ? 'yes' : 'no';
                items[index].bf_enable_magnetism = $item.find('.field-bf-enable-magnetism').is(':checked') ? 'yes' : 'no';
                items[index].bf_click_effect = $item.find('.field-bf-click-effect').is(':checked') ? 'yes' : 'no';
                items[index].bf_disable_animations = $item.find('.field-bf-disable-animations').is(':checked') ? 'yes' : 'no';
                items[index].bf_items = [];
                $item.find('.bf-item').each(function () {
                  const $b = $(this);
                  items[index].bf_items.push({
                    label: $b.find('.field-bf-item-label').val(),
                    icon: $b.find('.field-bf-item-icon').val(),
                    title: $b.find('.field-bf-item-title').val(),
                    description: $b.find('.field-bf-item-desc').val(),
                    color: $b.find('.field-bf-item-color').val(),
                    image: $b.find('.field-bf-item-image').val(),
                    link: $b.find('.field-bf-item-link').val()
                  });
                });
              } else if (items[index].type === 'gold_banner') {
                items[index].gb_width_mode = $item.find('.field-gb-width-mode').val();
                items[index].gb_items = [];
                $item.find('.gb-item').each(function () {
                  const $b = $(this);
                  items[index].gb_items.push({
                    image: $b.find('.field-gb-item-image').val(),
                    title: $b.find('.field-gb-item-title').val(),
                    subtitle: $b.find('.field-gb-item-subtitle').val(),
                    link: $b.find('.field-gb-item-link').val()
                  });
                });
              } else if (items[index].type === 'gold_product_carousel') {
                items[index].gp_more_text = $item.find('.field-gp-more-text').val();
                items[index].gp_more_link = $item.find('.field-gp-more-link').val();
                items[index].gp_width_mode = $item.find('.field-gp-width-mode').val();
                items[index].gp_product_count = $item.find('.field-gp-product-count').val();
                items[index].gp_hide_out_of_stock = $item.find('.field-gp-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
                items[index].gp_tab_newest = $item.find('.field-gp-tab-newest').is(':checked') ? 'yes' : 'no';
                items[index].gp_tab_newest_label = $item.find('.field-gp-tab-newest-label').val();
                items[index].gp_tab_popular = $item.find('.field-gp-tab-popular').is(':checked') ? 'yes' : 'no';
                items[index].gp_tab_popular_label = $item.find('.field-gp-tab-popular-label').val();
                items[index].gp_tab_lowwage = $item.find('.field-gp-tab-lowwage').is(':checked') ? 'yes' : 'no';
                items[index].gp_tab_lowwage_label = $item.find('.field-gp-tab-lowwage-label').val();
                items[index].product_cats = [];
                $item.find('.field-product-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].product_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
              } else if (items[index].type === 'gold_categories') {
                items[index].gc_width_mode = $item.find('.field-gc-width-mode').val();
                items[index].gc_cta_text = $item.find('.field-gc-cta-text').val();
                items[index].gc_items = [];
                $item.find('.gc-item').each(function () {
                  const $b = $(this);
                  items[index].gc_items.push({
                    image: $b.find('.field-gc-item-image').val(),
                    title: $b.find('.field-gc-item-title').val(),
                    link: $b.find('.field-gc-item-link').val()
                  });
                });
              } else if (items[index].type === 'category_nav') {
                items[index].cn_title = $item.find('.field-cn-title').val();
                items[index].cn_width_mode = $item.find('.field-cn-width-mode').val();
                items[index].cn_accent_color = $item.find('.field-cn-accent-color').val();
                items[index].cn_categories = [];
                $item.find('.cn-cat-item').each(function () {
                  const $cat = $(this);
                  const children = [];
                  $cat.find('.cn-child-item').each(function () {
                    children.push(window.__cnReadChild($(this)));
                  });
                  items[index].cn_categories.push({
                    name: $cat.find('.field-cn-cat-name').val(),
                    image: $cat.find('.field-cn-cat-image').val(),
                    children: children
                  });
                });
              } else if (items[index].type === 'special_sale_carousel') {
                items[index].ssc_title = $item.find('.field-ssc-title').val();
                items[index].ssc_view_all_text = $item.find('.field-ssc-view-all-text').val();
                items[index].ssc_view_all_link = $item.find('.field-ssc-view-all-link').val();
                items[index].ssc_bg1 = $item.find('.field-ssc-bg1').val();
                items[index].ssc_bg2 = $item.find('.field-ssc-bg2').val();
                items[index].ssc_bg3 = $item.find('.field-ssc-bg3').val();
                items[index].ssc_accent = $item.find('.field-ssc-accent').val();
                items[index].ssc_title_color = $item.find('.field-ssc-title-color').val();
                items[index].ssc_icon = $item.find('.field-ssc-icon').val();
                items[index].ssc_width_mode = $item.find('.field-ssc-width-mode').val();
                items[index].ssc_show_countdown = $item.find('.field-ssc-show-countdown').is(':checked') ? 'yes' : 'no';
                items[index].ssc_deadline = $item.find('.field-ssc-deadline').val();
                items[index].product_count = $item.find('.field-product-count').val();
                items[index].product_sort = $item.find('.field-product-sort').val();
                items[index].hide_out_of_stock = $item.find('.field-hide-out-of-stock').is(':checked') ? 'yes' : 'no';
                items[index].product_cats = [];
                $item.find('.field-product-cats-list .cat-chip').each(function () {
                  let id = $(this).data('id');
                  if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                  items[index].product_cats.push({
                    id: id,
                    name: $(this).contents().get(0).nodeValue.trim()
                  });
                });
              } else if (items[index].type === 'recommended_panels') {
                items[index].rec_width_mode = $item.find('.field-rec-width-mode').val();
                items[index].rec_panels = [];
                $item.find('.rec-panel').each(function () {
                  const $panel = $(this);
                  const cats = [];
                  $panel.find('.field-rec-cat-list .cat-chip').each(function () {
                    let id = $(this).data('id');
                    if (typeof id === 'string' && /^\d+$/.test(id)) id = parseInt(id);
                    cats.push({ id: id, name: $(this).contents().get(0).nodeValue.trim() });
                  });
                  items[index].rec_panels.push({
                    title: $panel.find('.field-rec-title').val(),
                    subtitle: $panel.find('.field-rec-subtitle').val(),
                    btn_text: $panel.find('.field-rec-btn-text').val(),
                    btn_link: $panel.find('.field-rec-btn-link').val(),
                    accent: $panel.find('.field-rec-accent').val(),
                    product_count: $panel.find('.field-rec-count').val(),
                    sort: $panel.find('.field-rec-sort').val(),
                    product_cats: cats
                  });
                });
              } else if (items[index].type && window.ENG_SCHEMAS && window.ENG_SCHEMAS[items[index].type]) {
                window.__engSaveWidget(items[index], $item);
              } else if (typeof items[index].type === 'string' && items[index].type.indexOf('cw:') === 0) {
                // ───── ذخیره‌ی ویجت سفارشی ─────
                const cwDef = window.__cwFindWidget(items[index].type.slice(3));
                const data = {};
                if (cwDef) {
                  (cwDef.fields || []).forEach(function (f) {
                    if (!f || !f.key) return;

                    if (f.type === 'repeater') {
                      const rows = [];
                      $item.find('.cw-rep[data-key="' + f.key + '"]').first().children('.cw-rep-row').each(function () {
                        const $r = $(this);
                        const obj = {};
                        (f.subfields || []).forEach(function (sf) {
                          obj[sf.key] = $r.find('.cw-sub[data-sub="' + sf.key + '"]').val() || '';
                        });
                        rows.push(obj);
                      });
                      data[f.key] = rows;
                    } else if (f.type === 'checkbox') {
                      data[f.key] = $item.find('.cw-field[data-key="' + f.key + '"]').is(':checked') ? 'yes' : 'no';
                    } else {
                      data[f.key] = $item.find('.cw-field[data-key="' + f.key + '"]').val() || '';
                    }
                  });
                }
                items[index].cw_data = data;
              } else if (items[index].type === 'banner_slider') {
                items[index].banner_slider_title_first = $item.find('.field-banner-slider-title-first').val();
                items[index].banner_slider_title_second = $item.find('.field-banner-slider-title-second').val();
                items[index].banner_slider_title_color = $item.find('.field-banner-slider-title-color').val();
                items[index].banner_slider_count = $item.find('.field-banner-slider-count').val();
                items[index].banner_slider_slides = [];
                $item.find('.banner-slider-slide-item').each(function () {
                  const $bsSlideItem = $(this);
                  items[index].banner_slider_slides.push({
                    image: $bsSlideItem.find('.field-bs-slide-image').val(),
                    category: $bsSlideItem.find('.field-bs-slide-category').val(),
                    title: $bsSlideItem.find('.field-bs-slide-title').val(),
                    description: $bsSlideItem.find('.field-bs-slide-description').val(),
                    link: $bsSlideItem.find('.field-bs-slide-link').val()
                  });
                });
              }
            }
          }
        });
        } catch (err) {
          console.error('[Boom] خطا هنگام همگام‌سازی سکشن‌ها با فرم:', err);
        }
        $textarea.val(JSON.stringify(items));
      }


      $wrapper.on('click', '.button-upload', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        let $input;
        if (name === 'product_categories') {
          $input = $item.find('.field-icon');
        } else {
          $input = $item.find('.field-image');
        }
        let frame = wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $item.find('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-slide', function (e) {
        e.preventDefault();
        const $button = $(this);
        const type = $button.data('type');
        const slideIdx = $button.data('slide');
        const $slideItem = $button.closest('.slide-item');
        let $input;

        if (type === 'image') {
          $input = $slideItem.find('.field-slide-image');
        } else if (type === 'desktop') {
          $input = $slideItem.find('.field-slide-desktop-image');
        } else if (type === 'mobile') {
          $input = $slideItem.find('.field-slide-mobile-image');
        }

        let title = 'انتخاب تصویر';
        if (type === 'desktop') title = 'انتخاب تصویر دسکتاپ';
        else if (type === 'mobile') title = 'انتخاب تصویر موبایل';

        let frame = wp.media({ title: title, multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:40px;max-height:40px;margin-left:5px;vertical-align:middle;">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-banner', function (e) {
        e.preventDefault();
        const $button = $(this);
        const type = $button.data('type');
        const bannerIdx = $button.data('banner');
        const $bannerItem = $button.closest('.banner-item');
        let $input = $bannerItem.find(`.field-banner-${type}-image`);

        let frame = wp.media({ title: `انتخاب تصویر ${type === 'desktop' ? 'دسکتاپ' : 'موبایل'}`, multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:50px;max-height:50px;margin:2px;">`);
          $input.trigger('input');
        });
        frame.open();
      });


      $wrapper.on('click', '.button-upload-logo', function (e) {
        e.preventDefault();
        const $button = $(this);
        const logoIdx = $button.data('logo');
        const $logoItem = $button.closest('.logo-item');
        let $input = $logoItem.find('.field-logo-image');

        let frame = wp.media({ title: 'انتخاب لوگو', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);

          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:40px;max-height:40px;margin-left:5px;vertical-align:middle;">`);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود تصویر شاخص استوری
      $wrapper.on('click', '.button-upload-story-thumbnail', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const $input = $item.find('.field-story-thumbnail');
        let frame = wp.media({ title: 'انتخاب تصویر شاخص استوری', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $item.find('.field-image-preview').remove();
          $input.closest('div').find('.field-image-preview').remove();
          $input.closest('div').append(`<div style="margin-top:10px;"><img src="${attachment.url}" class="field-image-preview" style="width:100px;height:100px;object-fit:cover;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.15);"></div>`);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود محتوای استوری (تصویر/ویدیو)
      $wrapper.on('click', '.button-upload-story-image', function (e) {
        e.preventDefault();
        const $button = $(this);
        const imgIdx = $button.data('img-idx');
        const $imageItem = $button.closest('.story-image-item');
        const $input = $imageItem.find('.field-story-image-url');
        const $typeSelect = $imageItem.find('.field-story-image-type');
        const mediaType = $typeSelect.val();

        let frameOptions = {
          title: mediaType === 'video' ? 'انتخاب ویدیو' : 'انتخاب تصویر',
          multiple: false
        };

        if (mediaType === 'video') {
          frameOptions.library = { type: 'video' };
        } else {
          frameOptions.library = { type: 'image' };
        }

        let frame = wp.media(frameOptions);
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.nextAll('.field-image-preview').remove();
          $input.parent().find('.field-image-preview').remove();

          if (mediaType === 'video') {
            $input.parent().append(`<div style="margin-top:10px;"><video src="${attachment.url}" controls style="max-width:200px;max-height:150px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></video></div>`);
          } else {
            $input.parent().append(`<div style="margin-top:10px;"><img src="${attachment.url}" class="field-image-preview" style="max-width:200px;max-height:150px;object-fit:cover;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`);
          }
          $input.trigger('input');
        });
        frame.open();
      });

      // تغییر نوع محتوای استوری
      $wrapper.on('change', '.field-story-image-type', function () {
        save();
        render();
      });

      // تغییر منبع قیمت ارز (دستی / متغیر)
      $wrapper.on('change', '.field-currency-price-source', function () {
        const $item = $(this).closest('.custom-list-item');
        const val = $(this).val();
        const $manualField = $item.find('.manual-price-field');
        const $dynamicSelect = $item.find('.dynamic-currency-select');
        if (val === 'dynamic') {
          $manualField.css({ opacity: 0.5, pointerEvents: 'none' });
          $manualField.find('input').attr('readonly', true).attr('placeholder', 'خودکار از سیستم ارز');
          $dynamicSelect.slideDown(200);
        } else {
          $manualField.css({ opacity: 1, pointerEvents: 'auto' });
          $manualField.find('input').removeAttr('readonly').attr('placeholder', 'مثال: 406940');
          $dynamicSelect.slideUp(200);
        }
      });

      // افزودن محتوای جدید به استوری
      $wrapper.on('click', '.add-story-image-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          if (!items[index].images) items[index].images = [];
          if (items[index].images.length < 10) {
            items[index].images.push({ url: '', caption: '', type: 'image' });
            $textarea.val(JSON.stringify(items));
            render();
          }
        }
      });

      // حذف محتوای استوری
      $wrapper.on('click', '.remove-story-image-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();

        const $item = $(this).closest('.custom-list-item');
        const imgIdx = $(this).data('img-idx');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1 && items[index].images) {
          items[index].images.splice(imgIdx, 1);
          if (items[index].images.length === 0) {
            items[index].images = [{ url: '', caption: '', type: 'image' }];
          }
          $textarea.val(JSON.stringify(items));
          render();
        }
      });

      // تغییر تعداد محتوا در استوری
      $wrapper.on('input change keyup', '.field-story-images-count', function (e) {
        e.stopPropagation(); // جلوگیری از trigger شدن event های دیگر

        const $input = $(this);
        const $item = $input.closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);

        if (index !== -1) {
          const newCount = parseInt($input.val()) || 1;
          const validCount = Math.min(Math.max(newCount, 1), 10); // محدود کردن بین 1 تا 10

          if (newCount !== validCount) {
            $input.val(validCount);
          }

          if (!items[index].images) {
            items[index].images = [];
          }

          let currentImages = items[index].images;

          if (validCount > currentImages.length) {
            // اضافه کردن محتوای جدید
            for (let i = currentImages.length; i < validCount; i++) {
              currentImages.push({ url: '', caption: '', type: 'image' });
            }
            items[index].images = currentImages;
            $textarea.val(JSON.stringify(items));
            render();
          } else if (validCount < currentImages.length) {
            // کم کردن محتوا
            items[index].images = currentImages.slice(0, validCount);
            $textarea.val(JSON.stringify(items));
            render();
          }
        }
      });


      $wrapper.on('input change', 'input:not(.field-story-images-count), textarea, select', function () {
        save();
      });


      $wrapper.on('change', '.field-section-type', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newType = $(this).val();
          items[index].type = newType;


          if (newType === 'banners') {
            items[index].banner_count = 1;
            items[index].banners = [{ desktop_image: '', mobile_image: '', alt: '', link: '', new_tab: 'no' }];
          } else if (newType === 'slider') {
            items[index].slider_style = 'style1';
            items[index].slider_count = 1;
            items[index].slides = [{ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' }];
          } else if (newType === 'banner_slider') {
            items[index].banner_slider_title_first = '';
            items[index].banner_slider_title_second = '';
            items[index].banner_slider_title_color = '#000000';
            items[index].banner_slider_count = 1;
            items[index].banner_slider_slides = [{ image: '', category: '', title: '', description: '', link: '' }];
          } else if (newType === 'currency_price') {
            items[index].currency_title = '';
            items[index].currency_subtitle = '';
            items[index].currency_name = '';
            items[index].currency_unit = '';
            items[index].price_source = 'manual';
            items[index].dynamic_currency = '';
            items[index].price_per_unit = '';
            items[index].price_label = '';
            items[index].buy_label = '';
            items[index].sell_label = '';
            items[index].input_placeholder = '';
            items[index].weight_placeholder = '';
            items[index].amount_unit = '';
            items[index].button_text = '';
            items[index].bg_color = '#dce9f5';
            items[index].accent_color = '#1a6fd4';
          } else if (newType === 'hero') {
            items[index].hero_title = '';
            items[index].hero_subtitle = '';
            items[index].hero_btn_text = '';
            items[index].hero_btn_link = '';
            items[index].hero_btn2_text = '';
            items[index].hero_btn2_link = '';
            items[index].hero_bg_style = 'letter_glitch';
            items[index].hero_align = 'center';
            items[index].hero_width_mode = 'container';
            items[index].hero_height = 60;
            items[index].hero_text_color = '#ffffff';
            items[index].hero_overlay_opacity = 40;
            items[index].hero_glitch_colors = ['#2b4539', '#61dca3', '#61b3dc'];
            items[index].hero_glitch_speed = 50;
            items[index].hero_outer_vignette = 'yes';
            items[index].hero_center_vignette = 'no';
            items[index].hero_beams_light_color = '#ffffff';
            items[index].hero_beams_number = 12;
            items[index].hero_beams_speed = 2;
            items[index].hero_beams_noise = 1.75;
            items[index].hero_beams_scale = 0.2;
            items[index].hero_beams_rotation = 0;
            items[index].hero_beams_width = 2;
            items[index].hero_beams_height = 15;
          } else if (newType === 'card_swap') {
            items[index].cs_title = '';
            items[index].cs_subtitle = '';
            items[index].cs_btn_text = '';
            items[index].cs_btn_link = '';
            items[index].cs_width_mode = 'container';
            items[index].cs_align = 'right';
            items[index].cs_height = 600;
            items[index].cs_bg_color = '#0f172a';
            items[index].cs_text_color = '#ffffff';
            items[index].cs_card_bar_bg = '#000000';
            items[index].cs_card_bar_text = '#ffffff';
            items[index].cs_card_distance = 60;
            items[index].cs_vertical_distance = 70;
            items[index].cs_delay = 5000;
            items[index].cs_skew = 6;
            items[index].cs_easing = 'elastic';
            items[index].cs_pause_on_hover = 'no';
            items[index].cs_cards = [
              { image: '', icon: '', title: 'کارت ۱', link: '' },
              { image: '', icon: '', title: 'کارت ۲', link: '' },
              { image: '', icon: '', title: 'کارت ۳', link: '' }
            ];
          } else if (newType === 'bento_features') {
            items[index].bf_title = '';
            items[index].bf_subtitle = '';
            items[index].bf_title_color = '#ffffff';
            items[index].bf_subtitle_color = '#a1a1aa';
            items[index].bf_width_mode = 'container';
            items[index].bf_glow_color = '132, 0, 255';
            items[index].bf_spotlight_radius = 400;
            items[index].bf_particle_count = 12;
            items[index].bf_text_auto_hide = 'yes';
            items[index].bf_enable_stars = 'yes';
            items[index].bf_enable_spotlight = 'yes';
            items[index].bf_enable_border_glow = 'yes';
            items[index].bf_enable_tilt = 'no';
            items[index].bf_enable_magnetism = 'no';
            items[index].bf_click_effect = 'yes';
            items[index].bf_disable_animations = 'no';
            items[index].bf_items = [
              { label: 'Analytics', title: 'تحلیل پیشرفته', description: 'رفتار کاربر را زیر نظر بگیرید', icon: '📊', color: '#120F17', image: '', link: '' },
              { label: 'Dashboard', title: 'داشبورد یکپارچه', description: 'نمای متمرکز داده‌ها', icon: '🧭', color: '#120F17', image: '', link: '' },
              { label: 'Collaboration', title: 'همکاری تیمی', description: 'با هم بی‌وقفه کار کنید', icon: '🤝', color: '#120F17', image: '', link: '' },
              { label: 'Automation', title: 'اتوماسیون', description: 'فرآیندها را خودکار کنید', icon: '⚡', color: '#120F17', image: '', link: '' },
              { label: 'Integration', title: 'یکپارچه‌سازی', description: 'به ابزارهای محبوب وصل شوید', icon: '🔌', color: '#120F17', image: '', link: '' },
              { label: 'Security', title: 'امنیت سازمانی', description: 'محافظت در سطح Enterprise', icon: '🔒', color: '#120F17', image: '', link: '' }
            ];
          } else if (newType === 'category_nav') {
            items[index].cn_title = '';
            items[index].cn_width_mode = 'container';
            items[index].cn_accent_color = '#ff6a3d';
            items[index].cn_categories = [
              { name: 'دسته ۱', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] },
              { name: 'دسته ۲', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] }
            ];
          } else if (newType === 'gold_banner') {
            items[index].gb_width_mode = 'container';
            items[index].gb_items = [
              { image: '', title: 'کمتر از ۲۰ میلیون تومان', subtitle: 'محصولات مینیمال', link: '' },
              { image: '', title: '۲۰ تا ۶۰ میلیون تومان', subtitle: 'محصولات روزانه', link: '' },
              { image: '', title: '۶۰ تا ۱۰۰ میلیون تومان', subtitle: 'محصولات ویژه', link: '' },
              { image: '', title: 'بالاتر از ۱۰۰ میلیون تومان', subtitle: 'محصولات لوکس', link: '' }
            ];
          } else if (newType === 'gold_product_carousel') {
            items[index].gp_more_text = 'مشاهده بیشتر';
            items[index].gp_more_link = '';
            items[index].gp_width_mode = 'container';
            items[index].gp_product_count = 10;
            items[index].gp_hide_out_of_stock = 'no';
            items[index].gp_tab_newest = 'yes';
            items[index].gp_tab_newest_label = 'جدیدترین‌ها';
            items[index].gp_tab_popular = 'yes';
            items[index].gp_tab_popular_label = 'محبوب‌ترین‌ها';
            items[index].gp_tab_lowwage = 'yes';
            items[index].gp_tab_lowwage_label = 'کم‌اجرت‌ها';
            items[index].product_cats = [];
          } else if (newType === 'gold_categories') {
            items[index].gc_width_mode = 'container';
            items[index].gc_cta_text = 'مشاهده';
            items[index].gc_items = [
              { image: '', title: 'گوشواره', link: '' },
              { image: '', title: 'انگشتر', link: '' },
              { image: '', title: 'سرویس', link: '' },
              { image: '', title: 'دستبند', link: '' },
              { image: '', title: 'گردنبند', link: '' }
            ];
          } else if (newType === 'special_sale_carousel') {
            items[index].ssc_title = 'فروش ویژه';
            items[index].ssc_view_all_text = 'مشاهده همه';
            items[index].ssc_view_all_link = '';
            items[index].ssc_bg1 = '#ee7c2c';
            items[index].ssc_bg2 = '#f0873c';
            items[index].ssc_bg3 = '#f6a86e';
            items[index].ssc_accent = '#e8620e';
            items[index].ssc_title_color = '#ffffff';
            items[index].ssc_icon = '';
            items[index].ssc_width_mode = 'container';
            items[index].ssc_show_countdown = 'yes';
            items[index].ssc_deadline = '';
            items[index].product_cats = [];
            items[index].product_count = 10;
            items[index].product_sort = 'latest';
            items[index].hide_out_of_stock = 'no';
          } else if (newType === 'recommended_panels') {
            items[index].rec_width_mode = 'container';
            items[index].rec_panels = [
              { title: 'لوازم مکانیکی', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' },
              { title: 'روغن موتور', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' },
              { title: 'چراغ خودرو', subtitle: 'محصولات پیشنهادی از دسته', btn_text: 'بیشتر', btn_link: '', accent: '#1d5eff', product_cats: [], product_count: 4, sort: 'latest' }
            ];
          } else if (window.ENG_SCHEMAS && window.ENG_SCHEMAS[newType]) {
            Object.assign(items[index], window.__engDefaults(newType));
          } else if (typeof newType === 'string' && newType.indexOf('cw:') === 0) {
            // مقادیر پیش‌فرض ویجت سفارشی
            items[index].cw_data = window.__cwDefaults(window.__cwFindWidget(newType.slice(3)));
          }

          save();
          render();
        }
      });


      // ───── هندلرهای ویجت سفارشی (ردیف‌های تکرارشونده و آپلود تصویر) ─────

      // افزودن ردیف به فیلد تکرارشونده
      $wrapper.on('click', '.cw-rep-add', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const $item = $btn.closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;

        const cwDef = window.__cwFindWidget(String(items[index].type || '').slice(3));
        if (!cwDef) return;
        const fieldKey = $btn.data('key');
        const field = (cwDef.fields || []).find(function (f) { return f.key === fieldKey; });
        if (!field) return;

        const $container = $item.find('.cw-rep[data-key="' + fieldKey + '"]').first();
        const nextIdx = $container.children('.cw-rep-row').length;
        $container.append(window.__cwRepRowHtml(field, {}, nextIdx));

        save();
      });

      // حذف ردیف از فیلد تکرارشونده
      $wrapper.on('click', '.cw-rep-del', function (e) {
        e.preventDefault();
        const $row = $(this).closest('.cw-rep-row');
        const $container = $row.parent();
        $row.remove();
        // شماره‌گذاری مجدد عنوان ردیف‌ها
        $container.children('.cw-rep-row').each(function (i) {
          $(this).find('span').first().text('ردیف ' + (i + 1));
        });
        save();
      });

      // آپلود تصویر برای فیلد ساده‌ی ویجت سفارشی
      $wrapper.on('click', '.button-upload-cw', function (e) {
        e.preventDefault();
        const $input = $(this).siblings('.cw-field').first();
        const frame = wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          const att = frame.state().get('selection').first().toJSON();
          $input.val(att.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود تصویر برای زیرفیلد تکرارشونده
      $wrapper.on('click', '.button-upload-cw-sub', function (e) {
        e.preventDefault();
        const $input = $(this).siblings('.cw-sub').first();
        const frame = wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          const att = frame.state().get('selection').first().toJSON();
          $input.val(att.url);
          $input.trigger('input');
        });
        frame.open();
      });


      // تغییر تعداد کارت‌های CardSwap (بدون render کلی تا focus حفظ شود)
      $wrapper.on('input change', '.field-cs-card-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index === -1) return;
        const raw = parseInt($(this).val());
        if (isNaN(raw)) return; // بذار کاربر input رو پاک کنه بدون reset
        const newCount = Math.max(2, Math.min(10, raw));

        // اول کارت‌های فعلی رو از DOM به items سینک کن (تا چیزی که کاربر نوشته از دست نره)
        const currentCards = [];
        $item.find('.cs-card-item').each(function () {
          const $c = $(this);
          currentCards.push({
            image: $c.find('.field-cs-card-image').val(),
            icon: $c.find('.field-cs-card-icon').val(),
            title: $c.find('.field-cs-card-title').val(),
            desc: $c.find('.field-cs-card-desc').val(),
            link: $c.find('.field-cs-card-link').val()
          });
        });

        let cards = currentCards;
        if (newCount > cards.length) {
          for (let i = cards.length; i < newCount; i++) cards.push({ image: '', icon: '', title: 'کارت ' + (i + 1), link: '' });
        } else if (newCount < cards.length) {
          cards = cards.slice(0, newCount);
        }
        items[index].cs_cards = cards;

        // فقط container کارت‌ها رو rebuild کن (نه کل فرم)
        const $cardsContainer = $item.find('.cs-cards-container');
        $cardsContainer.empty();
        cards.forEach((card, ci) => {
          $cardsContainer.append(`
            <div class="cs-card-item" data-idx="${ci}" style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;border:1px solid #4338ca;">
              <div style="font-size:12px;font-weight:600;color:#a5b4fc;margin-bottom:10px;">کارت ${ci + 1}</div>
              <div style="display:grid;grid-template-columns:200px 100px 1fr 1fr 1fr;gap:10px;align-items:start;">
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">تصویر:</label>
                  <input type="text" class="field-cs-card-image" value="${card.image || ''}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;margin-bottom:6px;">
                  <button type="button" class="button button-upload-cs-card" data-idx="${ci}" style="font-size:11px;">📷 انتخاب تصویر</button>
                  ${card.image ? `<img src="${card.image}" style="max-width:100%;max-height:60px;margin-top:6px;border-radius:4px;display:block;">` : ''}
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">آیکون:</label>
                  <textarea class="field-cs-card-icon" placeholder="emoji یا SVG" style="width:100%;min-height:60px;padding:6px 8px;border:1px solid #4338ca;border-radius:6px;font-size:11px;background:#0f172a;color:#f8fafc;font-family:monospace;resize:none;">${card.icon || ''}</textarea>
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">عنوان کارت:</label>
                  <input type="text" class="field-cs-card-title" value="${card.title || ''}" placeholder="عنوان" style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">توضیح کوتاه:</label>
                  <input type="text" class="field-cs-card-desc" value="${card.desc || ''}" placeholder="توضیح" style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#cbd5e1;">لینک (اختیاری):</label>
                  <input type="text" class="field-cs-card-link" value="${card.link || ''}" placeholder="/product/..." style="width:100%;padding:7px 10px;border:1px solid #4338ca;border-radius:6px;font-size:12px;background:#0f172a;color:#f8fafc;">
                </div>
              </div>
            </div>
          `);
        });

        // sync با textarea بدون اینکه global save() مقدارهای فعلی DOM رو پاک کنه
        $textarea.val(JSON.stringify(items));
      });

      // تغییر تعداد سل‌های Bento (rebuild فقط container آیتم‌ها)
      $wrapper.on('input change', '.field-bf-item-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index === -1) return;
        const raw = parseInt($(this).val());
        if (isNaN(raw)) return;
        const newCount = Math.max(3, Math.min(12, raw));

        // سینک آیتم‌های فعلی از DOM
        const current = [];
        $item.find('.bf-item').each(function () {
          const $b = $(this);
          current.push({
            label: $b.find('.field-bf-item-label').val(),
            icon: $b.find('.field-bf-item-icon').val(),
            title: $b.find('.field-bf-item-title').val(),
            description: $b.find('.field-bf-item-desc').val(),
            color: $b.find('.field-bf-item-color').val(),
            image: $b.find('.field-bf-item-image').val(),
            link: $b.find('.field-bf-item-link').val()
          });
        });

        let arr = current;
        if (newCount > arr.length) {
          for (let i = arr.length; i < newCount; i++) {
            arr.push({ label: 'Feature', title: 'کارت ' + (i + 1), description: 'توضیح کوتاه', icon: '★', color: '#120F17', image: '', link: '' });
          }
        } else if (newCount < arr.length) {
          arr = arr.slice(0, newCount);
        }
        items[index].bf_items = arr;

        const $c = $item.find('.bf-items-container');
        $c.empty();
        arr.forEach((it, bi) => {
          $c.append(`
            <div class="bf-item" data-idx="${bi}" style="background:rgba(255,255,255,0.06);padding:12px;border-radius:8px;border:1px solid #a21caf;">
              <div style="font-size:12px;font-weight:600;color:#f9a8d4;margin-bottom:10px;">کارت ${bi + 1}</div>
              <div style="display:grid;grid-template-columns:100px 100px 1fr 1fr 80px 1fr;gap:10px;align-items:start;">
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">برچسب (Label):</label>
                  <input type="text" class="field-bf-item-label" value="${it.label || ''}" placeholder="Label" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">آیکون:</label>
                  <textarea class="field-bf-item-icon" placeholder="emoji یا SVG" style="width:100%;min-height:60px;padding:6px 8px;border:1px solid #a21caf;border-radius:6px;font-size:11px;background:#1e1b4b;color:#fdf2f8;font-family:monospace;resize:none;">${it.icon || ''}</textarea>
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">عنوان:</label>
                  <input type="text" class="field-bf-item-title" value="${it.title || ''}" placeholder="عنوان" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;margin-bottom:6px;">
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">لینک (اختیاری):</label>
                  <input type="text" class="field-bf-item-link" value="${it.link || ''}" placeholder="/..." style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;">
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">توضیح:</label>
                  <textarea class="field-bf-item-desc" placeholder="توضیح کوتاه" style="width:100%;min-height:60px;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:12px;background:#1e1b4b;color:#fdf2f8;resize:none;">${it.description || ''}</textarea>
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">رنگ پس‌زمینه:</label>
                  <input type="color" class="field-bf-item-color" value="${it.color || '#120F17'}" style="width:100%;height:32px;padding:2px;border:1px solid #a21caf;border-radius:6px;cursor:pointer;background:#1e1b4b;">
                </div>
                <div>
                  <label style="display:block;margin-bottom:6px;font-size:11px;color:#fbcfe8;">تصویر (اختیاری):</label>
                  <input type="text" class="field-bf-item-image" value="${it.image || ''}" placeholder="آدرس تصویر" style="width:100%;padding:7px 10px;border:1px solid #a21caf;border-radius:6px;font-size:11px;background:#1e1b4b;color:#fdf2f8;margin-bottom:6px;">
                  <button type="button" class="button button-upload-bf" data-idx="${bi}" style="font-size:11px;">📷 انتخاب</button>
                  ${it.image ? `<img src="${it.image}" style="max-width:100%;max-height:50px;margin-top:6px;border-radius:4px;display:block;">` : ''}
                </div>
              </div>
            </div>
          `);
        });

        $textarea.val(JSON.stringify(items));
      });

      // تبدیل color picker glow به فرمت "R, G, B" در فیلد مخفی
      $wrapper.on('input change', '.field-bf-glow-picker', function () {
        const hex = ($(this).val() || '').toString().replace('#', '');
        if (hex.length !== 6) return;
        const r = parseInt(hex.slice(0, 2), 16);
        const g = parseInt(hex.slice(2, 4), 16);
        const b = parseInt(hex.slice(4, 6), 16);
        const rgb = r + ', ' + g + ', ' + b;
        const $hidden = $(this).siblings('.field-bf-glow-color');
        $hidden.val(rgb).trigger('input');
      });

      // آپلود تصویر برای سل Bento
      $wrapper.on('click', '.button-upload-bf', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const $bfItem = $btn.closest('.bf-item');
        const $input = $bfItem.find('.field-bf-item-image');
        const frame = wp.media({ title: 'انتخاب تصویر سل', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود تصویر برای کارت‌های CardSwap
      $wrapper.on('click', '.button-upload-cs-card', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const $cardItem = $btn.closest('.cs-card-item');
        const $input = $cardItem.find('.field-cs-card-image');
        const frame = wp.media({ title: 'انتخاب تصویر کارت', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // ───── هندلرهای ویجت‌های طلا و جواهر ─────
      // تغییر تعداد کارت‌های بنر طلا (فقط container را rebuild می‌کند)
      $wrapper.on('input change', '.field-gb-item-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const raw = parseInt($(this).val());
        if (isNaN(raw)) return;
        const newCount = Math.max(2, Math.min(8, raw));

        const current = [];
        $item.find('.gb-item').each(function () {
          const $b = $(this);
          current.push({
            image: $b.find('.field-gb-item-image').val(),
            title: $b.find('.field-gb-item-title').val(),
            subtitle: $b.find('.field-gb-item-subtitle').val(),
            link: $b.find('.field-gb-item-link').val()
          });
        });

        let arr = current;
        if (newCount > arr.length) {
          for (let i = arr.length; i < newCount; i++) arr.push({ image: '', title: 'کارت ' + (i + 1), subtitle: '', link: '' });
        } else if (newCount < arr.length) {
          arr = arr.slice(0, newCount);
        }
        items[index].gb_items = arr;

        const $c = $item.find('.gb-items-container');
        $c.empty();
        arr.forEach((it, gi) => $c.append(window.__gbRenderItem(it, gi)));
        $textarea.val(JSON.stringify(items));
      });

      // تغییر تعداد دسته‌های طلا
      $wrapper.on('input change', '.field-gc-item-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const raw = parseInt($(this).val());
        if (isNaN(raw)) return;
        const newCount = Math.max(2, Math.min(10, raw));

        const current = [];
        $item.find('.gc-item').each(function () {
          const $b = $(this);
          current.push({
            image: $b.find('.field-gc-item-image').val(),
            title: $b.find('.field-gc-item-title').val(),
            link: $b.find('.field-gc-item-link').val()
          });
        });

        let arr = current;
        if (newCount > arr.length) {
          for (let i = arr.length; i < newCount; i++) arr.push({ image: '', title: 'دسته ' + (i + 1), link: '' });
        } else if (newCount < arr.length) {
          arr = arr.slice(0, newCount);
        }
        items[index].gc_items = arr;

        const $c = $item.find('.gc-items-container');
        $c.empty();
        arr.forEach((it, gi) => $c.append(window.__gcRenderItem(it, gi)));
        $textarea.val(JSON.stringify(items));
      });

      // آپلود تصویر کارت بنر طلا
      $wrapper.on('click', '.button-upload-gb', function (e) {
        e.preventDefault();
        const $input = $(this).closest('.gb-item').find('.field-gb-item-image');
        const frame = wp.media({ title: 'انتخاب تصویر بنر', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // آپلود تصویر دسته طلا
      $wrapper.on('click', '.button-upload-gc', function (e) {
        e.preventDefault();
        const $input = $(this).closest('.gc-item').find('.field-gc-item-image');
        const frame = wp.media({ title: 'انتخاب تصویر دسته', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // ───── هندلرهای ویجت ناوبری دسته‌بندی (category_nav) ─────
      // سینک DOM → items[index].cn_categories (تا تایپ‌های ذخیره‌نشده از بین نرود)
      function cnSyncFromDom($item, index) {
        const cats = [];
        $item.find('.cn-cat-item').each(function () {
          const $cat = $(this);
          const children = [];
          $cat.find('.cn-child-item').each(function () {
            children.push(window.__cnReadChild($(this)));
          });
          cats.push({
            name: $cat.find('.field-cn-cat-name').val(),
            image: $cat.find('.field-cn-cat-image').val(),
            children: children
          });
        });
        items[index].cn_categories = cats;
        return cats;
      }

      function cnRebuild($item, index) {
        const $c = $item.find('.cn-cats-container');
        $c.empty();
        (items[index].cn_categories || []).forEach((cat, ci) => $c.append(window.__cnRenderCat(cat, ci)));
        $textarea.val(JSON.stringify(items));
      }

      // افزودن دسته سطح ۱
      $wrapper.on('click', '.cn-add-cat', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const cats = cnSyncFromDom($item, index);
        cats.push({ name: 'دسته جدید', image: '', children: [{ name: 'زیرشاخه ۱', link: '' }] });
        cnRebuild($item, index);
      });

      // حذف دسته سطح ۱
      $wrapper.on('click', '.cn-remove-cat', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const ci = $(this).closest('.cn-cat-item').data('idx');
        const cats = cnSyncFromDom($item, index);
        cats.splice(ci, 1);
        cnRebuild($item, index);
      });

      // افزودن زیرشاخه سطح ۲
      $wrapper.on('click', '.cn-add-child', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const ci = $(this).closest('.cn-cat-item').data('idx');
        const cats = cnSyncFromDom($item, index);
        if (!cats[ci]) return;
        if (!Array.isArray(cats[ci].children)) cats[ci].children = [];
        cats[ci].children.push({ name: 'زیرشاخه جدید', link: '' });
        cnRebuild($item, index);
      });

      // حذف زیرشاخه سطح ۲
      $wrapper.on('click', '.cn-remove-child', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = items.findIndex(i => i._uuid === $item.data('id'));
        if (index === -1) return;
        const $childRow = $(this).closest('.cn-child-item');
        const ci = $childRow.data('cat');
        const chi = $childRow.data('child');
        const cats = cnSyncFromDom($item, index);
        if (cats[ci] && Array.isArray(cats[ci].children)) cats[ci].children.splice(chi, 1);
        cnRebuild($item, index);
      });

      // آپلود تصویر برای دسته سطح ۱
      $wrapper.on('click', '.button-upload-cn', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const $catItem = $btn.closest('.cn-cat-item');
        const $input = $catItem.find('.field-cn-cat-image');
        const frame = wp.media({ title: 'انتخاب تصویر دسته', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // نمایش/مخفی‌کردن انتخابگر دسته‌بندی هنگام تغییر چک‌باکس «نمایش محصولات»
      $wrapper.on('change', '.field-cn-child-show-products', function () {
        const $picker = $(this).closest('.cn-child-item').find('.cn-child-cat-picker');
        if (this.checked) $picker.slideDown(150);
        else $picker.slideUp(150);
      });

      // جستجوی دسته‌بندی محصول (اسکوپ‌شده به هر زیرشاخه)
      $wrapper.on('input', '.field-cn-child-cat-search', function () {
        const $child = $(this).closest('.cn-child-item');
        const q = $(this).val();
        const $results = $child.find('.cn-child-cat-results');
        $results.empty();
        if (q.length < 2) return;

        let siteUrl = window.location.origin;
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $results.addClass('cat-dropdown').html('<div class="cat-loading">در حال جستجو...</div>');
        $.get(siteUrl + '/wp-json/theme-settings/v1/product-categories', { search: q }, function (data) {
          $results.empty();
          if (Array.isArray(data) && data.length) {
            data.forEach(cat => {
              $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${(cat.name || '').replace(/"/g, '&quot;')}">${cat.name}</div>`);
            });
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
      });

      // انتخاب یک دسته‌بندی از نتایج
      $wrapper.on('click', '.cn-child-cat-results .cat-result', function () {
        const $child = $(this).closest('.cn-child-item');
        const id = $(this).data('id');
        const name = $(this).data('name');
        $child.find('.field-cn-child-cat-id').val(id);
        $child.find('.field-cn-child-cat-name').val(name);
        $child.find('.cn-child-cat-selected').html(
          `<span class="cat-chip" data-id="${id}" style="display:inline-flex;align-items:center;gap:6px;">${name} <b style="cursor:pointer;" class="cn-child-cat-remove">&times;</b></span>`
        );
        $child.find('.cn-child-cat-results').empty();
        $child.find('.field-cn-child-cat-search').val('');
        save();
      });

      // حذف دسته‌بندی انتخاب‌شده
      $wrapper.on('click', '.cn-child-cat-remove', function () {
        const $child = $(this).closest('.cn-child-item');
        $child.find('.field-cn-child-cat-id').val('');
        $child.find('.field-cn-child-cat-name').val('');
        $child.find('.cn-child-cat-selected').empty();
        save();
      });

      // ───── هندلرهای فریم‌ورک ویجت‌های مهندسان (eng_*) ─────
      function engIndex($item) { return items.findIndex(i => i._uuid === $item.data('id')); }
      function engReplaceWidget($item, index) {
        const $w = window.__engRenderWidget(items[index]);
        $item.find('.eng-widget').replaceWith($w);
        $textarea.val(JSON.stringify(items));
      }
      function engSchemaList(type, listKey) {
        const sc = window.ENG_SCHEMAS[type];
        return sc && sc.lists.find(l => l.k === listKey);
      }

      // افزودن سطر به یک لیست
      $wrapper.on('click', '.eng-add-row', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = engIndex($item);
        if (index === -1) return;
        window.__engSaveWidget(items[index], $item);
        const listKey = $(this).data('list-key');
        const list = engSchemaList(items[index].type, listKey);
        if (!list) return;
        if (!Array.isArray(items[index][listKey])) items[index][listKey] = [];
        items[index][listKey].push(window.__engBlankRow(list));
        engReplaceWidget($item, index);
      });

      // حذف سطر
      $wrapper.on('click', '.eng-remove-row', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = engIndex($item);
        if (index === -1) return;
        window.__engSaveWidget(items[index], $item);
        const listKey = $(this).closest('.eng-list').data('list-key');
        const ri = $(this).closest('.eng-row').data('idx');
        if (Array.isArray(items[index][listKey])) items[index][listKey].splice(ri, 1);
        engReplaceWidget($item, index);
      });

      // افزودن زیرسطر
      $wrapper.on('click', '.eng-add-subrow', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = engIndex($item);
        if (index === -1) return;
        window.__engSaveWidget(items[index], $item);
        const listKey = $(this).closest('.eng-list').data('list-key');
        const ri = $(this).closest('.eng-row').data('idx');
        const subKey = $(this).data('sub-key');
        const list = engSchemaList(items[index].type, listKey);
        const subField = list && list.item.find(f => f.k === subKey && f.sub);
        if (!subField) return;
        const row = items[index][listKey][ri];
        if (!Array.isArray(row[subKey])) row[subKey] = [];
        row[subKey].push(window.__engBlankSubRow(subField));
        engReplaceWidget($item, index);
      });

      // حذف زیرسطر
      $wrapper.on('click', '.eng-remove-subrow', function (e) {
        e.preventDefault();
        const $item = $(this).closest('.custom-list-item');
        const index = engIndex($item);
        if (index === -1) return;
        window.__engSaveWidget(items[index], $item);
        const listKey = $(this).closest('.eng-list').data('list-key');
        const ri = $(this).closest('.eng-row').data('idx');
        const subKey = $(this).closest('.eng-sublist').data('sub-key');
        const si = $(this).closest('.eng-subrow').data('idx');
        const row = items[index][listKey][ri];
        if (row && Array.isArray(row[subKey])) row[subKey].splice(si, 1);
        engReplaceWidget($item, index);
      });

      // آپلود تصویر در فیلدهای eng (نوع image)
      $wrapper.on('click', '.eng-upload', function (e) {
        e.preventDefault();
        const $btn = $(this);
        const $input = $btn.prevAll('input[type="text"]').first();
        const frame = wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          const attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.trigger('input');
        });
        frame.open();
      });

      // ───── زیرمنوهای navbar (دراپ‌داون دو لایه) ─────
      $wrapper.on('click', '.nav-add-child', function (e) {
        e.preventDefault();
        const $cont = $(this).closest('.nav-sub-wrap').find('.nav-children-cont');
        $cont.append(window.__navRenderChild({}));
        $cont.find('.nav-child-name').last().focus();
        save();
      });

      $wrapper.on('click', '.nav-remove-child', function (e) {
        e.preventDefault();
        $(this).closest('.nav-child').remove();
        save();
      });

      $wrapper.on('input change', '.field-banner-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          let currentBanners = items[index].banners || [];


          // ابتدا مقادیر فعلی را از DOM بخوان تا چیزی که کاربر تایپ کرده از دست نرود
          const domBanners = [];
          $item.find('.banner-item').each(function () {
            const $b = $(this);
            domBanners.push({
              desktop_image: $b.find('.field-banner-desktop-image').val(),
              mobile_image: $b.find('.field-banner-mobile-image').val(),
              alt: $b.find('.field-banner-alt').val() || '',
              link: $b.find('.field-banner-link').val(),
              new_tab: $b.find('.field-banner-new-tab-single').is(':checked') ? 'yes' : 'no'
            });
          });
          if (domBanners.length) {
            currentBanners = domBanners;
          }

          if (newCount > currentBanners.length) {

            for (let i = currentBanners.length; i < newCount; i++) {
              currentBanners.push({ desktop_image: '', mobile_image: '', alt: '', link: '', new_tab: 'no' });
            }
          } else if (newCount < currentBanners.length) {

            currentBanners = currentBanners.slice(0, newCount);
          }

          items[index].banner_count = newCount;
          items[index].banners = currentBanners;


          const $bannersContainer = $item.find('.banners-container');
          $bannersContainer.empty();

          currentBanners.forEach((banner, bannerIdx) => {
            const $bannerItem = $('<div class="banner-item" style="background:linear-gradient(135deg, #e0fae2 0%, #e0fae2 100%);padding:16px;margin:10px 0;border-radius:12px;border:2px solid #e1e8ed;box-shadow:0 2px 8px rgba(0,0,0,0.08);transition:all 0.3s ease;"></div>');

            // Header بنر با آیکون
            $bannerItem.append(`<div style="display:flex;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid rgba(255,255,255,0.6);">
              <span style="font-size:20px;margin-left:8px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><!-- Icon from Huge Icons by Hugeicons - undefined --><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 8c0-2.828 0-4.243 1.004-5.121S7.624 2 10.857 2h2.286c3.232 0 4.849 0 5.853.879C20 3.757 20 5.172 20 8v9H4z" /><path stroke-linecap="round" d="M3 17h18" /><path stroke-linecap="round" stroke-linejoin="round" d="M10.699 5.566c1.23-.176 3.268-.106 1.581 1.587c-2.108 2.115-5.272 6.876-1.581 5.29c3.69-1.588 5.272-.53 3.69 1.057" /><path stroke-linecap="round" d="M12 17v4m-7 1l3-5m11 5l-3-5" /></g></svg></span>
              <h4 style="margin:0;color:#2c3e50;font-size:15px;font-weight:600;">بنر شماره ${bannerIdx + 1}</h4>
            </div>`);

            // بخش تصویر دسکتاپ
            const desktopPreview = banner.desktop_image
              ? `<div style="margin-top:8px;"><img src="${banner.desktop_image}" class="field-image-preview" style="max-width:120px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
              : '';
            $bannerItem.append(`
              <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20.5 16.5v-8c0-2.357 0-3.536-.732-4.268C19.035 3.5 17.857 3.5 15.5 3.5h-7c-2.357 0-3.536 0-4.268.732S3.5 6.143 3.5 8.5v8m18.484 4H2.016c-.383 0-.632-.391-.461-.724L3.5 16.5h17l1.945 3.276a.5.5 0 0 1-.46.724" /></svg></span>
                  تصویر دسکتاپ:
                </label>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر دسکتاپ" class="field-banner-desktop-image" value="${banner.desktop_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-banner" data-type="desktop" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                    <span style="margin-left:4px;">📁</span> انتخاب تصویر
                  </button>
                </div>
                ${desktopPreview}
              </div>
            `);

            // بخش تصویر موبایل
            const mobilePreview = banner.mobile_image
              ? `<div style="margin-top:8px;"><img src="${banner.mobile_image}" class="field-image-preview" style="max-width:80px;max-height:80px;border-radius:8px;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.1);"></div>`
              : '';
            $bannerItem.append(`
              <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M13.5 2h-3c-2.357 0-3.536 0-4.268.732S5.5 4.643 5.5 7v10c0 2.357 0 3.535.732 4.268S8.143 22 10.5 22h3c2.357 0 3.535 0 4.268-.732c.732-.733.732-1.911.732-4.268V7c0-2.357 0-3.536-.732-4.268C17.035 2 15.857 2 13.5 2" /><path d="M14 2h-4l.5 1h3z" /></g></svg></span>
                  تصویر موبایل:
                </label>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                  <input type="text" placeholder="آدرس تصویر موبایل" class="field-banner-mobile-image" value="${banner.mobile_image || ''}" style="flex:1;min-width:200px;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                  <button type="button" class="button button-primary button-upload-banner" data-type="mobile" data-banner="${bannerIdx}" style="padding:8px 16px;font-size:13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                    <span style="margin-left:4px;">📁</span> انتخاب تصویر
                  </button>
                </div>
                ${mobilePreview}
              </div>
            `);

            // بخش متن جایگزین (alt) — اختیاری
            $bannerItem.append(`
              <div style="margin-bottom:14px;background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 5h16M4 12h10M4 19h7" /></svg></span>
                  متن جایگزین تصویر (alt) — اختیاری:
                </label>
                <input type="text" placeholder="مثلاً: بنر تخفیف لوازم جانبی" class="field-banner-alt" value="${(banner.alt || '').replace(/"/g, '&quot;')}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                <p style="margin:6px 0 0;font-size:11px;color:#7f8c8d;">برای سئو و دسترس‌پذیری. اگر خالی بماند مشکلی ایجاد نمی‌شود.</p>
              </div>
            `);

            // بخش لینک
            $bannerItem.append(`
              <div style="background:rgba(255,255,255,0.7);padding:12px;border-radius:8px;">
                <label style="display:flex;align-items:center;margin-bottom:8px;font-size:13px;font-weight:600;color:#34495e;">
                  <span style="font-size:16px;margin-left:6px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.823 12L4.28 10.456a4.367 4.367 0 1 1 6.177-6.177l9.265 9.265a4.368 4.368 0 0 1-6.177 6.177l-3.474-3.475a2.73 2.73 0 0 1 3.86-3.86l1.93 1.93" /></svg></span>
                  لینک بنر:
                </label>
                <input type="text" placeholder="https://example.com" class="field-banner-link" value="${(banner.link || '').replace(/"/g, '&quot;')}" style="width:100%;padding:8px 12px;border:1px solid #d1d8e0;border-radius:6px;font-size:13px;background:#fff;">
                <label style="display:inline-flex;align-items:center;gap:8px;margin-top:10px;font-size:12px;cursor:pointer;color:#34495e;">
                  <input type="checkbox" class="field-banner-new-tab-single" ${banner.new_tab === 'yes' ? 'checked' : ''} style="width:16px;height:16px;">
                  این لینک در تب جدید باز شود
                </label>
                <p style="margin:6px 0 0;font-size:11px;color:#7f8c8d;">اگر خاموش باشد و لینک داخلی باشد، بدون بارگذاری مجدد (SPA) باز می‌شود.</p>
              </div>
            `);

            $bannersContainer.append($bannerItem);
          });

          // DOM با items همگام شد؛ حالا مستقیماً textarea را sync کن
          // (save() نباید قبل از rebuild صدا زده شود چون از DOM قدیمی می‌خواند)
          $textarea.val(JSON.stringify(items));
        }
      });


      $wrapper.on('change', '.field-slider-style', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newStyle = $(this).val();
          const slideCount = parseInt(items[index].slider_count) || 1;
          items[index].slider_style = newStyle;


          items[index].slides = [];
          for (let i = 0; i < slideCount; i++) {
            if (newStyle === 'style1') {
              items[index].slides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
            } else if (newStyle === 'style2') {
              items[index].slides.push({ small_text: '', title: '', image: '', link: '' });
            } else if (newStyle === 'style3') {
              items[index].slides.push({ desktop_image: '', mobile_image: '', link: '' });
            } else if (newStyle === 'style4') {
              items[index].slides.push({ desktop_image: '', mobile_image: '', link: '' });
            } else if (newStyle === 'style5') {
              items[index].slides.push({ desktop_image: '', mobile_image: '', link: '' });
            }
          }

          save();
          render();
        }
      });


      $wrapper.on('input change', '.field-slider-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          const currentStyle = items[index].slider_style || 'style1';
          let currentSlides = items[index].slides || [];


          if (newCount > currentSlides.length) {

            for (let i = currentSlides.length; i < newCount; i++) {
              if (currentStyle === 'style1') {
                currentSlides.push({ discount_title: '', date_fa: '', time: '', title: '', image: '', small_text: '', link: '' });
              } else if (currentStyle === 'style2') {
                currentSlides.push({ small_text: '', title: '', image: '', link: '' });
              } else if (currentStyle === 'style3' || currentStyle === 'style4' || currentStyle === 'style5') {
                currentSlides.push({ desktop_image: '', mobile_image: '', link: '' });
              }
            }
          } else if (newCount < currentSlides.length) {

            currentSlides = currentSlides.slice(0, newCount);
          }

          items[index].slider_count = newCount;
          items[index].slides = currentSlides;
          save();
          render();
        }
      });

      $wrapper.on('input change', '.field-banner-slider-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          let currentSlides = items[index].banner_slider_slides || [];

          if (newCount > currentSlides.length) {
            for (let i = currentSlides.length; i < newCount; i++) {
              currentSlides.push({ image: '', category: '', title: '', description: '', link: '' });
            }
          } else if (newCount < currentSlides.length) {
            currentSlides = currentSlides.slice(0, newCount);
          }

          items[index].banner_slider_count = newCount;
          items[index].banner_slider_slides = currentSlides;
          save();
          render();
        }
      });

      $wrapper.on('click', '.button-upload-banner-slider', function (e) {
        e.preventDefault();
        const $button = $(this);
        const $bsSlideItem = $button.closest('.banner-slider-slide-item');
        let $input = $bsSlideItem.find('.field-bs-slide-image');

        let frame = wp.media({ title: 'انتخاب تصویر اسلاید', multiple: false });
        frame.on('select', function () {
          let attachment = frame.state().get('selection').first().toJSON();
          $input.val(attachment.url);
          $input.nextAll('.field-image-preview').remove();
          $input.after(`<img src="${attachment.url}" class="field-image-preview" style="max-width:40px;max-height:40px;margin-left:5px;vertical-align:middle;">`);
          $input.trigger('input');
        });
        frame.open();
      });

      $wrapper.on('input change', '.field-logo-count', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $item.data('id');
        const index = items.findIndex(i => i._uuid === id);
        if (index !== -1) {
          const newCount = parseInt($(this).val()) || 1;
          let currentLogos = items[index].logos || [];


          if (newCount > currentLogos.length) {

            for (let i = currentLogos.length; i < newCount; i++) {
              currentLogos.push({ image: '', link: '', alt: '' });
            }
          } else if (newCount < currentLogos.length) {

            currentLogos = currentLogos.slice(0, newCount);
          }

          items[index].logo_count = newCount;
          items[index].logos = currentLogos;
          save();
          render();
        }
      });


      setTimeout(function () {
        // پلاگین تقویم شمسی در همهٔ صفحات ادمین بارگذاری نمی‌شود (مثلاً ویرایشگر برگه).
        // بدون این بررسی، فراخوانی روی متدِ موجودنبودن خطا می‌دهد — حتی اگر سلکتور
        // هیچ عنصری پیدا نکند — و اجرای ادامهٔ اسکریپت را قطع می‌کند.
        if (!$.fn.persianDatepicker) return;

        const dpOptions = {
          format: 'YYYY/MM/DD',
          autoClose: true,
          initialValue: false,
          calendar: { persian: { locale: 'fa' } }
        };

        $('.custom-list-wrap[data-name="slider"] .field-date').persianDatepicker(dpOptions);
        $('.slide-item .field-slide-date').persianDatepicker(dpOptions);
      }, 500);

      render();


      $wrapper.on('input', '.field-product-cat-search', function () {
        const $item = $(this).closest('.custom-list-item');
        const q = $(this).val();
        const $results = $item.find('.product-cat-search-results');
        $results.empty();
        if (q.length < 2) return;
        let siteUrl = window.location.origin;

        $results.html('<div class="cat-loading">در حال جستجو...</div>');
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $.get(siteUrl + '/wp-json/theme-settings/v1/product-categories', { search: q }, function (data) {
          $results.empty();
          if (Array.isArray(data)) {

            let selected = [];
            $item.find('.field-product-cats-list .cat-chip').each(function () {
              selected.push($(this).data('id'));
            });
            let hasResult = false;
            data.forEach(cat => {
              if (!selected.includes(cat.id)) {
                $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${cat.name}">${cat.name}</div>`);
                hasResult = true;
              }
            });
            if (!hasResult) $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
        $results.addClass('cat-dropdown');
      });
      $wrapper.on('click', '.product-cat-search-results .cat-result', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $(this).data('id');
        const name = $(this).data('name');

        const $catList = $item.find('.field-product-cats-list');
        if ($catList.find(`[data-id='${id}']`).length) return;
        $catList.append(`<span class="cat-chip" data-id="${id}">${name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
        $item.find('.product-cat-search-results').empty();
        save();
      });
      $wrapper.on('click', '.field-product-cats-list .remove-cat', function () {
        const $chip = $(this).closest('.cat-chip');
        $chip.remove();
        save();
      });

      // ───── جستجو/انتخاب دسته اسکوپ‌شده برای هر پنل ویجت سه‌پنلی ─────
      $wrapper.on('input', '.field-rec-cat-search', function () {
        const $panel = $(this).closest('.rec-panel');
        const q = $(this).val();
        const $results = $panel.find('.rec-cat-results');
        $results.empty();
        if (q.length < 2) return;
        let siteUrl = window.location.origin;
        $results.html('<div class="cat-loading">در حال جستجو...</div>');
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $.get(siteUrl + '/wp-json/theme-settings/v1/product-categories', { search: q }, function (data) {
          $results.empty();
          if (Array.isArray(data)) {
            let selected = [];
            $panel.find('.field-rec-cat-list .cat-chip').each(function () {
              selected.push($(this).data('id'));
            });
            let hasResult = false;
            data.forEach(cat => {
              if (!selected.includes(cat.id)) {
                $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${cat.name}">${cat.name}</div>`);
                hasResult = true;
              }
            });
            if (!hasResult) $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
        $results.addClass('cat-dropdown');
      });
      $wrapper.on('click', '.rec-cat-results .cat-result', function () {
        const $panel = $(this).closest('.rec-panel');
        const id = $(this).data('id');
        const name = $(this).data('name');
        const $catList = $panel.find('.field-rec-cat-list');
        if ($catList.find(`[data-id='${id}']`).length) return;
        $catList.append(`<span class="cat-chip" data-id="${id}">${name} <b style='cursor:pointer;' class='rec-remove-cat'>&times;</b></span>`);
        $panel.find('.rec-cat-results').empty();
        save();
      });
      $wrapper.on('click', '.rec-panel .rec-remove-cat', function () {
        $(this).closest('.cat-chip').remove();
        save();
      });

      $wrapper.on('input', '.field-blog-cat-search', function () {
        const $item = $(this).closest('.custom-list-item');
        const q = $(this).val();
        const $results = $item.find('.blog-cat-search-results');
        $results.empty();
        if (q.length < 2) return;
        $results.html('<div class="cat-loading">در حال جستجو...</div>');
        let siteUrl = window.location.origin;
        if (window.ajaxurl) {
          const parser = document.createElement('a');
          parser.href = window.ajaxurl;
          siteUrl = parser.origin + parser.pathname.replace(/\/wp-admin.*/, '');
        }
        $.get(siteUrl + '/wp-json/wp/v2/categories', { search: q, per_page: 10 }, function (data) {
          $results.empty();
          if (Array.isArray(data)) {

            let selected = [];
            $item.find('.field-blog-cats-list .cat-chip').each(function () {
              selected.push($(this).data('id'));
            });
            let hasResult = false;
            data.forEach(cat => {
              if (!selected.includes(cat.id)) {
                $results.append(`<div class="cat-result" data-id="${cat.id}" data-name="${cat.name}">${cat.name}</div>`);
                hasResult = true;
              }
            });
            if (!hasResult) $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          } else {
            $results.append('<div class="cat-no-result">نتیجه‌ای یافت نشد</div>');
          }
        });
        $results.addClass('cat-dropdown');
      });
      $wrapper.on('click', '.blog-cat-search-results .cat-result', function () {
        const $item = $(this).closest('.custom-list-item');
        const id = $(this).data('id');
        const name = $(this).data('name');
        const $catList = $item.find('.field-blog-cats-list');
        if ($catList.find(`[data-id='${id}']`).length) return;
        $catList.append(`<span class="cat-chip" data-id="${id}">${name} <b style='cursor:pointer;' class='remove-cat'>&times;</b></span>`);
        $item.find('.blog-cat-search-results').empty();
        save();
      });
      $wrapper.on('click', '.field-blog-cats-list .remove-cat', function () {
        const $chip = $(this).closest('.cat-chip');
        $chip.remove();
        save();
      });

      if (!document.getElementById('cat-chip-style')) {
        const chipCss = `
        .cat-chip { display:inline-flex;align-items:center;background:var(--brand-bg);color:var(--brand);border-radius:20px;padding:3px 10px 3px 6px;margin:2px 4px 2px 0;font-size:12.5px;font-weight:500;transition:all .2s; border:1px solid rgba(9,143,129,0.15); }
        .cat-chip b.remove-cat {margin-right:4px;font-size:15px;line-height:1;color:var(--brand);opacity:0.6;transition:opacity .2s;}
        .cat-chip b.remove-cat:hover {opacity:1;}
        .cat-chip:hover {background:rgba(9,143,129,0.12);border-color:rgba(9,143,129,0.25);}
        .cat-dropdown {position:absolute;right:0;left:0;top:100%;background:#fff;border:1.5px solid var(--border);border-radius:0 0 var(--radius-md) var(--radius-md);box-shadow:var(--shadow-lg);z-index:1001;max-height:220px;overflow:auto;margin-top:2px;}
        .cat-result {padding:9px 14px;cursor:pointer;transition:background .15s;font-size:13px;color:var(--text-primary);}
        .cat-result:hover {background:var(--brand-bg);color:var(--brand);}
        .cat-loading {padding:9px 14px;color:var(--brand);font-size:13px;}
        .cat-no-result {padding:9px 14px;color:var(--text-muted);font-size:13px;}
        .banners-container {width:100%;margin-top:10px;}
        .banner-item {transition:all 0.25s ease!important;}
        .banner-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .banner-item input[type="text"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .banner-item .button-upload-banner:hover {background:var(--brand-dark)!important;}
        .banner-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .banner-item .field-image-preview:hover {transform:scale(1.4)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .slides-container {width:100%;margin-top:10px;}
        .slide-item {transition:all 0.25s ease!important;}
        .slide-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .slide-item input[type="text"]:focus, .slide-item input[type="time"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .slide-item .button-upload-slide:hover {background:var(--brand-dark)!important;}
        .slide-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .slide-item .field-image-preview:hover {transform:scale(1.4)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .logos-container {width:100%;margin-top:10px;}
        .logo-item {transition:all 0.25s ease!important;}
        .logo-item:hover {border-color:rgba(9,143,129,0.25)!important;box-shadow:var(--shadow-sm)!important;}
        .logo-item input[type="text"]:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        .logo-item .button-upload-logo:hover {background:var(--brand-dark)!important;}
        .logo-item .field-image-preview {transition:transform 0.2s ease!important;border-radius:var(--radius-sm)!important;}
        .logo-item .field-image-preview:hover {transform:scale(1.3)!important;z-index:100!important;position:relative!important;cursor:zoom-in!important;}
        .field-product-cat-search:focus, .field-blog-cat-search:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        select.field-product-sort:focus {outline:none!important;border-color:var(--brand)!important;box-shadow:0 0 0 3px rgba(9,143,129,0.1)!important;}
        `;
        $('<style id="cat-chip-style">' + chipCss + '</style>').appendTo('head');
      }
      } catch (err) {
        console.error('[Boom] خطا در ساخت لیست "' + $(this).data('name') + '":', err);
      }
    });
    };

    // اجرای اولیه
    window.__boomInitCustomLists();


    const $mainTab = $('#tab-content-main');
    const $homeSectionsWrap = $('.custom-list-wrap[data-name="home_sections"]').parent();
    const $homeSectionsCount = $("input[name='custom_theme_options[home_sections_count]']").closest('tr, p, div');
    if ($mainTab.length) {

      $mainTab.append($homeSectionsCount);
      $mainTab.append($homeSectionsWrap);
    }

    $homeSectionsWrap.hide();
    $homeSectionsCount.hide();


    const $styleTab = $('#tab-content-style');
    const styleFields = [
      'product_carousel_style',
      'header_style',
      'footer_style',
      'category_card_style',
      'product_page_style',
      'product_archive_style',
      'container_style',
      'category_page_style',
      'category_page_style_mobile',
      'variation_style',
      'megamenu_layers',
      // استایل‌های سفارشی ساخته‌شده در «استودیوی توسعه»
      'boom_cstyle_product_carousel',
      'boom_cstyle_category_card',
      'boom_cstyle_header',
      'boom_cstyle_footer',
      'boom_cstyle_banner',
    ];

    const $styleFieldElements = [];
    const $customStyleRows = [];

    styleFields.forEach(function (fieldName) {
      const $field = $("select[name='custom_theme_options[" + fieldName + "]']").closest('tr');
      if (!$field.length) return;

      // ردیف‌های «استایل سفارشی» جدا نگه داشته می‌شوند تا داخل پنل بازشونده بروند
      if (fieldName.indexOf('boom_cstyle_') === 0) {
        $customStyleRows.push($field);
      } else {
        $styleFieldElements.push($field);
      }
    });

    // چک‌باکس «نمایش همبرگر منو در موبایل» (input است نه select) را هم به تب استایل منتقل کن
    const $hamburgerField = $("input[name='custom_theme_options[mobile_hamburger_enabled]']").closest('tr');
    if ($hamburgerField.length) {
      $styleFieldElements.push($hamburgerField);
    }

    if ($styleTab.length && $styleFieldElements.length) {

      $styleFieldElements.forEach(function ($field) {
        $styleTab.append($field);
        $field.hide();
      });
    }

    // ============================================================
    // پنل بازشونده‌ی «استایل‌های سفارشی» در تب تنظیمات استایل
    // ============================================================
    if ($styleTab.length && $customStyleRows.length) {
      const $panel = $(
        '<div class="boom-cstyle-panel">' +
          '<button type="button" class="boom-cstyle-toggle">' +
            '<span class="boom-cstyle-toggle-text">نمایش استایل‌های سفارشی</span>' +
            '<span class="boom-cstyle-caret"></span>' +
          '</button>' +
          '<div class="boom-cstyle-body">' +
            '<div class="boom-cstyle-intro">' +
              '<strong>استایل‌های سفارشی چیست؟</strong>' +
              '<p>با «استایل سفارشی» می‌توانید ظاهر یک بخش از قالب (مثل کارسل محصولات، کارت دسته‌بندی، هدر، فوتر یا بنرها) ' +
              'را به‌طور کامل با طراحی خودتان جایگزین کنید؛ بدون اینکه فایل‌های قالب را ویرایش کنید.</p>' +
              '<p>برای ساخت یک استایل جدید به مسیر ' +
              '<a href="admin.php?page=boom-dev-styles" target="_blank"><strong>توسعه‌دهندگان ← استایل‌های سفارشی</strong></a>' +
              ' بروید، بخش هدف را انتخاب کنید و تمپلیت خود را بنویسید. متغیرهای هر بخش همان‌جا نمایش داده می‌شود.</p>' +
              '<p>پس از ساخت، استایل ساخته‌شده در فهرست‌های زیر ظاهر می‌شود و با انتخاب آن فعال می‌گردد.</p>' +
            '</div>' +
            '<table class="form-table boom-cstyle-table"><tbody></tbody></table>' +
          '</div>' +
        '</div>'
      );

      const $tbody = $panel.find('.boom-cstyle-table tbody');
      $customStyleRows.forEach(function ($row) {
        $tbody.append($row);
        $row.show(); // داخل پنل همیشه نمایان است؛ باز/بسته شدن با خود پنل کنترل می‌شود
      });

      $styleTab.append($panel);
      $panel.hide();
      // پنل هم مثل بقیه‌ی فیلدهای استایل، با تعویض تب نمایش/مخفی می‌شود
      $styleFieldElements.push($panel);

      $panel.on('click', '.boom-cstyle-toggle', function () {
        const $btn = $(this);
        const $body = $panel.find('.boom-cstyle-body');
        const open = $panel.hasClass('is-open');
        $panel.toggleClass('is-open', !open);
        $body.slideToggle(180);
        $btn.find('.boom-cstyle-toggle-text')
          .text(open ? 'نمایش استایل‌های سفارشی' : 'بستن استایل‌های سفارشی');
      });
    }


    // ============================================================
    // تب تنظیمات فونت (انتقال کل سکشن فونت + فونت‌های سفارشی به تب)
    // ============================================================
    (function setupFontTab() {
      const $fontTab = $('#tab-content-font');
      if (!$fontTab.length) return;

      const $fontField = $("select[name='custom_theme_options[site_font]']");
      const $fontTable = $fontField.closest('table.form-table');
      if ($fontTable.length) {
        const $heading = $fontTable.prevAll('h2').first();
        $fontTab.find('p').remove(); // حذف متن جایگزین پیش‌فرض
        if ($heading.length) $fontTab.append($heading);
        $fontTab.append($fontTable);
      }
    })();


    // ============================================================
    // تب تنظیمات امنیتی (انتقال کل سکشن امنیتی به تب خودش)
    // ============================================================
    (function setupSecurityTab() {
      const $tab = $('#tab-content-security');
      if (!$tab.length) return;

      // یک فیلد شناخته‌شده از سکشن امنیتی برای یافتن جدول همان سکشن
      const $anchor = $("input[name='custom_theme_options[login_method_mobile]']");
      const $table = $anchor.closest('table.form-table');
      if ($table.length) {
        const $heading = $table.prevAll('h2').first();
        $tab.find('p').remove();
        if ($heading.length) $tab.append($heading);
        $tab.append($table);
      }
    })();


    // ============================================================
    // تب سفارشی‌سازی (انتقال کل سکشن CSS/JS/کد هدر/کد فوتر به تب خودش)
    // ============================================================
    (function setupCustomizationTab() {
      const $tab = $('#tab-content-customization');
      if (!$tab.length) return;

      const $anchor = $("textarea[name='custom_theme_options[custom_css]']");
      const $table = $anchor.closest('table.form-table');
      if ($table.length) {
        const $heading = $table.prevAll('h2').first();
        $tab.find('p').remove();
        if ($heading.length) $tab.append($heading);
        $tab.append($table);
      }
    })();


    $(document).on('click', '.custom-tab-btn', function () {
      const tabName = $(this).data('tab');


      if (tabName === 'main') {
        $homeSectionsWrap.show();
        $homeSectionsCount.show();
      } else {
        $homeSectionsWrap.hide();
        $homeSectionsCount.hide();
      }


      if (tabName === 'style') {
        $styleFieldElements.forEach(function ($field) {
          $field.show();
        });
      } else {
        $styleFieldElements.forEach(function ($field) {
          $field.hide();
        });
      }
    });

    // ============================================================
    // 🛒 تب آیتم‌های اضافه خرید
    // ============================================================
    (function setupPurchaseAddons() {
      const $paTab = $('#tab-content-purchase-addons');
      if (!$paTab.length) return;

      // انتقال سکشن «آیتم‌های اضافه خرید» (h2 + جدول) به داخل تب
      const $servicesField = $('textarea[name="custom_theme_options[purchase_addon_services]"]');
      const $paTable = $servicesField.closest('table.form-table');
      if ($paTable.length) {
        const $paHeading = $paTable.prevAll('h2').first();
        if ($paHeading.length) $paTab.append($paHeading);
        $paTab.append($paTable);
      }

      // استایل اختصاصی تب
      if (!document.getElementById('boom-pa-style')) {
        const paCss = `
          .boom-pa-switch{display:flex;gap:10px;align-items:flex-start;line-height:1.7;}
          .boom-pa-switch input{margin-top:4px;}
          .boom-pa-services{display:flex;flex-direction:column;gap:14px;margin-top:8px;}
          .boom-pa-service{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;position:relative;box-shadow:0 1px 3px rgba(0,0,0,0.04);}
          .boom-pa-service .row{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;}
          .boom-pa-service .col{display:flex;flex-direction:column;gap:4px;}
          .boom-pa-service label{font-size:12px;color:#475569;font-weight:600;}
          .boom-pa-service input[type=text],.boom-pa-service input[type=number],.boom-pa-service select,.boom-pa-service textarea{border:1px solid #cbd5e1;border-radius:8px;padding:8px 10px;font-size:13px;min-width:160px;}
          .boom-pa-service textarea{width:100%;min-height:50px;}
          .boom-pa-service .icon-col{flex:1;min-width:220px;}
          .boom-pa-service .icon-col textarea{min-height:38px;font-family:monospace;}
          .boom-pa-service .pa-remove{position:absolute;top:12px;left:12px;background:#fee2e2;color:#dc2626;border:none;border-radius:8px;width:32px;height:32px;cursor:pointer;font-size:16px;line-height:1;}
          .boom-pa-service .pa-remove:hover{background:#fecaca;}
          .boom-pa-service .pa-check{display:flex;gap:6px;align-items:center;font-size:13px;color:#334155;}
          .boom-pa-add{background:linear-gradient(135deg,#098f81,#0ea5a0);color:#fff;border:none;border-radius:10px;padding:10px 18px;cursor:pointer;font-size:13px;font-weight:600;margin-top:6px;align-self:flex-start;}
          .boom-pa-add:hover{box-shadow:0 4px 12px rgba(9,143,129,0.25);}
          .boom-pa-empty{color:#94a3b8;font-size:13px;padding:14px;text-align:center;border:1px dashed #cbd5e1;border-radius:10px;}
          .boom-pa-mode label{font-size:13px;color:#334155;}
          .boom-pa-mode-hint{margin-top:8px;font-size:12px;color:#0369a1;background:#e0f2fe;border-radius:8px;padding:10px 12px;}
          .boom-pa-price-wrap{display:flex;gap:6px;align-items:flex-end;}
          .boom-pa-price-wrap .pa-price{min-width:120px;}
          .boom-pa-price-wrap .pa-ptype{min-width:90px;}
          .boom-pa-opts{margin-top:14px;border-top:1px dashed #cbd5e1;padding-top:12px;display:flex;flex-direction:column;gap:8px;}
          .boom-pa-opts>label.opts-title{font-size:12px;color:#475569;font-weight:700;}
          .boom-pa-opt{display:flex;gap:8px;align-items:flex-end;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;position:relative;flex-wrap:wrap;}
          .boom-pa-opt .col{display:flex;flex-direction:column;gap:4px;}
          .boom-pa-opt .pa-opt-label{min-width:200px;}
          .boom-pa-opt .pa-opt-price{min-width:110px;}
          .boom-pa-opt .pa-opt-ptype{min-width:90px;}
          .boom-pa-opt .pa-opt-remove{background:#fee2e2;color:#dc2626;border:none;border-radius:8px;width:30px;height:30px;cursor:pointer;font-size:14px;line-height:1;align-self:center;}
          .boom-pa-opt .pa-opt-remove:hover{background:#fecaca;}
          .pa-opt-add{background:#eef2ff;color:#4338ca;border:none;border-radius:8px;padding:7px 14px;cursor:pointer;font-size:12px;font-weight:600;align-self:flex-start;}
          .pa-opt-add:hover{background:#e0e7ff;}
          .boom-pa-opts-empty{color:#94a3b8;font-size:12px;padding:8px;text-align:center;border:1px dashed #cbd5e1;border-radius:8px;}
        `;
        $('<style id="boom-pa-style">' + paCss + '</style>').appendTo('head');
      }

      // ---- ریپیتر خدمات ----
      const $wrap = $('.boom-pa-services-wrap');
      const $json = $('.boom-pa-services-json');
      if ($wrap.length && $json.length) {
        let services = [];
        try { services = JSON.parse($json.val()) || []; } catch (e) { services = []; }
        if (!Array.isArray(services)) services = [];

        function uid() { return 's' + Math.random().toString(36).substring(2, 9); }
        function oid() { return 'o' + Math.random().toString(36).substring(2, 9); }
        function esc(v) { return (v == null ? '' : String(v)).replace(/"/g, '&quot;'); }
        function isTrue(v) { return (v === true || v === 'yes' || v === 1 || v === '1'); }

        function save() {
          $json.val(JSON.stringify(services));
        }

        // ساخت select نوع قیمت (ثابت/درصدی)
        function priceTypeSelect(cls, val) {
          return '<select class="' + cls + '">' +
            '<option value="fixed"' + (val !== 'percent' ? ' selected' : '') + '>تومان (ثابت)</option>' +
            '<option value="percent"' + (val === 'percent' ? ' selected' : '') + '>٪ درصدی</option>' +
            '</select>';
        }

        function render() {
          $wrap.empty();
          const $list = $('<div class="boom-pa-services"></div>');

          if (!services.length) {
            $list.append('<div class="boom-pa-empty">هنوز خدمتی اضافه نشده است. روی «افزودن خدمت» بزنید.</div>');
          }

          services.forEach(function (svc, idx) {
            if (!svc.id) svc.id = uid();
            if (!svc.type) svc.type = 'single';
            if (svc.all_categories === undefined) svc.all_categories = true;
            const $item = $('<div class="boom-pa-service" data-idx="' + idx + '"></div>');
            $item.append('<button type="button" class="pa-remove" title="حذف">✕</button>');

            const $row1 = $('<div class="row"></div>');
            $row1.append('<div class="col"><label>عنوان خدمت</label><input type="text" class="pa-title" value="' + esc(svc.title) + '" placeholder="مثلاً بیمه یا نصب ویندوز"></div>');
            $row1.append('<div class="col"><label>نوع خدمت</label><select class="pa-type">' +
              '<option value="single"' + (svc.type !== 'options' ? ' selected' : '') + '>تک‌گزینه (قیمت واحد)</option>' +
              '<option value="options"' + (svc.type === 'options' ? ' selected' : '') + '>چندگزینه‌ای (انتخابی)</option>' +
              '</select></div>');
            // قیمت فقط برای حالت تک‌گزینه
            if (svc.type !== 'options') {
              $row1.append('<div class="col"><label>قیمت</label><div class="boom-pa-price-wrap">' +
                '<input type="number" class="pa-price" value="' + (svc.price || 0) + '" min="0" step="' + (svc.price_type === 'percent' ? '0.1' : '1000') + '">' +
                priceTypeSelect('pa-ptype', svc.price_type) +
                '</div></div>');
            }
            $row1.append('<div class="col"><label>محل نمایش</label><select class="pa-display">' +
              '<option value="both"' + (svc.display === 'both' || !svc.display ? ' selected' : '') + '>مودال و سبد خرید</option>' +
              '<option value="modal"' + (svc.display === 'modal' ? ' selected' : '') + '>فقط مودال</option>' +
              '<option value="cart"' + (svc.display === 'cart' ? ' selected' : '') + '>فقط سبد خرید</option>' +
              '</select></div>');
            $row1.append('<div class="col"><label>پیش‌فرض</label><label class="pa-check"><input type="checkbox" class="pa-auto"' + (isTrue(svc.auto_checked) ? ' checked' : '') + '> انتخاب خودکار</label></div>');
            $row1.append('<div class="col"><label>دامنه</label><label class="pa-check"><input type="checkbox" class="pa-allcats"' + (isTrue(svc.all_categories) ? ' checked' : '') + '> همه دسته‌ها</label></div>');
            $item.append($row1);

            const $row2 = $('<div class="row" style="margin-top:12px;"></div>');
            $row2.append('<div class="col" style="flex:1;min-width:240px;"><label>توضیح کوتاه</label><input type="text" class="pa-desc" style="width:100%;" value="' + esc(svc.description) + '" placeholder="مثلاً پوشش کامل خرابی"></div>');
            $item.append($row2);

            const $row3 = $('<div class="row icon-col" style="margin-top:12px;"></div>');
            $row3.append('<div class="col" style="width:100%;"><label>آیکون (کد SVG یا آدرس تصویر — اختیاری)</label><textarea class="pa-icon" placeholder="<svg ...></svg> یا https://...">' + (svc.icon || '') + '</textarea></div>');
            $item.append($row3);

            // گزینه‌های زیرمجموعه (حالت چندگزینه‌ای)
            if (svc.type === 'options') {
              if (!Array.isArray(svc.options)) svc.options = [];
              const $opts = $('<div class="boom-pa-opts"></div>');
              $opts.append('<label class="opts-title">گزینه‌های قابل انتخاب (هر کدام قیمت جدا)</label>');
              if (!svc.options.length) {
                $opts.append('<div class="boom-pa-opts-empty">هنوز گزینه‌ای اضافه نشده. مثلاً «اورجینال» و «غیراورجینال».</div>');
              }
              svc.options.forEach(function (opt, oidx) {
                if (!opt.id) opt.id = oid();
                const $opt = $('<div class="boom-pa-opt" data-oidx="' + oidx + '"></div>');
                $opt.append('<div class="col pa-opt-label"><label>عنوان گزینه</label><input type="text" class="pa-opt-label-in" value="' + esc(opt.label) + '" placeholder="مثلاً ویندوز اورجینال"></div>');
                $opt.append('<div class="col pa-opt-price"><label>قیمت</label><input type="number" class="pa-opt-price-in" value="' + (opt.price || 0) + '" min="0" step="' + (opt.price_type === 'percent' ? '0.1' : '1000') + '"></div>');
                $opt.append('<div class="col pa-opt-ptype">' + priceTypeSelect('pa-opt-ptype-in', opt.price_type) + '</div>');
                $opt.append('<button type="button" class="pa-opt-remove" title="حذف گزینه">✕</button>');
                $opts.append($opt);
              });
              $opts.append('<button type="button" class="pa-opt-add">+ افزودن گزینه</button>');
              $item.append($opts);
            }

            $list.append($item);
          });

          $wrap.append($list);
          $wrap.append('<button type="button" class="boom-pa-add">+ افزودن خدمت</button>');
        }

        // افزودن خدمت
        $wrap.on('click', '.boom-pa-add', function () {
          services.push({ id: uid(), title: '', price: 0, price_type: 'fixed', display: 'both', auto_checked: false, all_categories: true, description: '', icon: '', type: 'single', options: [] });
          save();
          render();
        });

        // حذف خدمت
        $wrap.on('click', '.pa-remove', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          services.splice(idx, 1);
          save();
          render();
        });

        // افزودن گزینه
        $wrap.on('click', '.pa-opt-add', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          if (services[idx] === undefined) return;
          if (!Array.isArray(services[idx].options)) services[idx].options = [];
          services[idx].options.push({ id: oid(), label: '', price: 0, price_type: 'fixed' });
          save();
          render();
        });

        // حذف گزینه
        $wrap.on('click', '.pa-opt-remove', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          const oidx = $(this).closest('.boom-pa-opt').data('oidx');
          if (services[idx] && Array.isArray(services[idx].options)) {
            services[idx].options.splice(oidx, 1);
            save();
            render();
          }
        });

        // تغییر نوع خدمت → نیاز به رندر مجدد (تعویض UI قیمت/گزینه‌ها)
        $wrap.on('change', '.pa-type', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          if (services[idx] === undefined) return;
          services[idx].type = $(this).val();
          if (services[idx].type === 'options' && !Array.isArray(services[idx].options)) services[idx].options = [];
          save();
          render();
        });

        // تغییر نوع قیمت (ثابت/درصدی) → رندر مجدد برای تنظیم step
        $wrap.on('change', '.pa-ptype', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          if (services[idx] === undefined) return;
          services[idx].price_type = $(this).val();
          save();
          render();
        });
        $wrap.on('change', '.pa-opt-ptype-in', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          const oidx = $(this).closest('.boom-pa-opt').data('oidx');
          if (services[idx] && services[idx].options && services[idx].options[oidx]) {
            services[idx].options[oidx].price_type = $(this).val();
            save();
            render();
          }
        });

        // تغییر فیلدهای متنی/عددی (بدون رندر مجدد تا فوکوس حفظ شود)
        $wrap.on('input change', '.pa-title,.pa-price,.pa-display,.pa-auto,.pa-allcats,.pa-desc,.pa-icon', function () {
          const $svcEl = $(this).closest('.boom-pa-service');
          const idx = $svcEl.data('idx');
          if (services[idx] === undefined) return;
          services[idx].title = $svcEl.find('.pa-title').val();
          services[idx].price = parseFloat($svcEl.find('.pa-price').val()) || 0;
          services[idx].price_type = $svcEl.find('.pa-ptype').val() || services[idx].price_type || 'fixed';
          services[idx].display = $svcEl.find('.pa-display').val();
          services[idx].auto_checked = $svcEl.find('.pa-auto').is(':checked');
          services[idx].all_categories = $svcEl.find('.pa-allcats').is(':checked');
          services[idx].description = $svcEl.find('.pa-desc').val();
          services[idx].icon = $svcEl.find('.pa-icon').val();
          save();
        });

        // تغییر فیلدهای گزینه‌ها
        $wrap.on('input change', '.pa-opt-label-in,.pa-opt-price-in', function () {
          const idx = $(this).closest('.boom-pa-service').data('idx');
          const oidx = $(this).closest('.boom-pa-opt').data('oidx');
          if (!services[idx] || !services[idx].options || !services[idx].options[oidx]) return;
          const $opt = $(this).closest('.boom-pa-opt');
          services[idx].options[oidx].label = $opt.find('.pa-opt-label-in').val();
          services[idx].options[oidx].price = parseFloat($opt.find('.pa-opt-price-in').val()) || 0;
          save();
        });

        render();
      }

      // ---- حالت محصولات پیشنهادی ----
      function toggleSuggestedMode() {
        const mode = $('input[name="custom_theme_options[purchase_suggested_mode]"]:checked').val();
        const $fixed = $('.boom-pa-fixed-products');
        $('.boom-pa-mode-hint').remove();
        if (mode === 'fixed') {
          $fixed.show();
        } else {
          $fixed.hide();
          const hint = mode === 'per_product'
            ? 'محصولات پیشنهادی برای هر محصول در صفحهٔ ویرایش همان محصول (متاباکس «محصولات پیشنهادی هنگام خرید») انتخاب می‌شود.'
            : 'محصولات پیشنهادی برای هر دسته‌بندی در صفحهٔ ویرایش همان دسته انتخاب می‌شود.';
          $('.boom-pa-mode').after('<div class="boom-pa-mode-hint">' + hint + '</div>');
        }
      }
      $(document).on('change', 'input[name="custom_theme_options[purchase_suggested_mode]"]', toggleSuggestedMode);

      // فعال‌سازی جستجوی محصول و حالت اولیه وقتی تب باز می‌شود
      $(document).on('click', '.custom-tab-btn[data-tab="purchase-addons"]', function () {
        setTimeout(function () {
          $(document).trigger('boom:init-product-search');
          toggleSuggestedMode();
        }, 50);
      });
      setTimeout(toggleSuggestedMode, 300);
    })();

    // نمایش/مخفی کردن فیلد تم پیشفرض بر اساس انتخاب حالت تم
    function toggleDarkThemeDefault() {
      var mode = $('#dark_theme_mode').val();
      var $defaultRow = $('#dark_theme_default').closest('tr');
      if (mode === 'both') {
        $defaultRow.show();
      } else {
        $defaultRow.hide();
      }
    }
    // اجرای اولیه با تأخیر (بعد از انتقال فیلدها)
    setTimeout(function () { toggleDarkThemeDefault(); }, 300);
    $(document).on('change', '#dark_theme_mode', function () { toggleDarkThemeDefault(); });

    // ───── سازنده‌ی تب‌های سفارشی پنل کاربری ─────
    (function () {
      const $hidden = $('#user_panel_custom_tabs');
      const $panel = $('#tab-content-user-panel');
      if (!$hidden.length || !$panel.length) return;

      // مخفی کردن ردیف خام input که در تب عمومی قرار گرفته
      $hidden.closest('tr').hide();

      let tabs;
      try { tabs = JSON.parse($hidden.val() || '[]'); } catch (e) { tabs = []; }
      if (!Array.isArray(tabs)) tabs = [];

      const esc = (v) => (v == null ? '' : String(v))
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      const sync = () => $hidden.val(JSON.stringify(tabs));

      const $wrap = $('<div style="max-width:860px;"></div>');
      $panel.empty().append($wrap);

      $wrap.append(`<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px 20px;margin-bottom:16px;">
        <h2 style="margin:0 0 6px;font-size:17px;">تب‌های سفارشی پنل کاربری</h2>
        <p style="margin:0;color:#64748b;font-size:13px;line-height:1.9;">تب‌های دلخواه با آیکون، اسلاگ و محتوای HTML بسازید. اگر «باز شدن لینک در تب جدید» را فعال کنید، با کلیک روی تب، لینک واردشده در یک تب جدید باز می‌شود (به‌جای نمایش محتوا).</p>
      </div>`);

      const $list = $('<div id="up-tabs-list" style="display:flex;flex-direction:column;gap:14px;"></div>');
      $wrap.append($list);
      const $add = $('<button type="button" class="button button-primary" style="margin-top:14px;">+ افزودن تب جدید</button>');
      $wrap.append($add);

      function card(t, i) {
        const openYes = t.open_in_new === 'yes';
        return $(`
          <div class="up-tab-card" data-idx="${i}" style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,0.04);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
              <strong style="font-size:14px;">تب شماره ${i + 1}</strong>
              <button type="button" class="button up-remove" style="color:#b91c1c;">حذف</button>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
              <div>
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">عنوان تب:</label>
                <input type="text" class="up-title" value="${esc(t.title)}" style="width:100%;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
              </div>
              <div>
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">اسلاگ (انگلیسی، یکتا):</label>
                <input type="text" class="up-slug" value="${esc(t.slug)}" dir="ltr" style="width:100%;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
              </div>
            </div>
            <div style="margin-bottom:12px;">
              <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">آیکون (کد SVG، ایموجی، یا آدرس تصویر):</label>
              <textarea class="up-icon" rows="2" style="width:100%;font-family:monospace;direction:ltr;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">${esc(t.icon)}</textarea>
            </div>
            <div style="margin-bottom:12px;">
              <label style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;">
                <input type="checkbox" class="up-open-new" ${openYes ? 'checked' : ''}> باز شدن لینک در تب جدید هنگام کلیک
              </label>
            </div>
            <div class="up-link-wrap" style="margin-bottom:12px;${openYes ? '' : 'display:none;'}">
              <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">لینک (هنگام باز شدن در تب جدید):</label>
              <input type="text" class="up-link" value="${esc(t.link)}" dir="ltr" placeholder="https://..." style="width:100%;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">
            </div>
            <div class="up-content-wrap" style="${openYes ? 'display:none;' : ''}">
              <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">محتوای تب (HTML، با پشتیبانی از style و script):</label>
              <textarea class="up-content" rows="6" style="width:100%;font-family:monospace;direction:ltr;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;">${esc(t.content)}</textarea>
            </div>
          </div>
        `);
      }

      function render() {
        $list.empty();
        tabs.forEach((t, i) => $list.append(card(t, i)));
      }

      function readDom() {
        const arr = [];
        $list.find('.up-tab-card').each(function () {
          const $b = $(this);
          arr.push({
            title: $b.find('.up-title').val(),
            slug: $b.find('.up-slug').val(),
            icon: $b.find('.up-icon').val(),
            content: $b.find('.up-content').val(),
            open_in_new: $b.find('.up-open-new').is(':checked') ? 'yes' : 'no',
            link: $b.find('.up-link').val()
          });
        });
        tabs = arr;
        sync();
      }

      $add.on('click', function () {
        readDom();
        tabs.push({ title: 'تب جدید', slug: 'tab-' + (tabs.length + 1), icon: '', content: '', open_in_new: 'no', link: '' });
        render(); sync();
      });

      $list.on('click', '.up-remove', function () {
        readDom();
        const idx = $(this).closest('.up-tab-card').data('idx');
        tabs.splice(idx, 1);
        render(); sync();
      });

      $list.on('change', '.up-open-new', function () {
        const $c = $(this).closest('.up-tab-card');
        const on = $(this).is(':checked');
        $c.find('.up-link-wrap').toggle(on);
        $c.find('.up-content-wrap').toggle(!on);
        readDom();
      });

      $list.on('input change', 'input, textarea', function () { readDom(); });

      render();
      sync();
    })();

    // اضافه کردن دکمه‌های ذخیره به همه تب‌ها (به جز تب عمومی)
    setTimeout(function () {
      const tabIds = ['main', 'style', 'jobs', 'about', 'contact', 'faq', 'stories', 'notification', 'security', 'font', 'customization', 'translations', 'dark-theme', 'user-panel', 'header-currency', 'purchase-addons', 'captcha', 'theme-usage'];
      const submitButtonHtml = '<p class="submit"><input type="submit" name="submit" class="button button-primary" value="ذخیرهٔ تغییرات"></p>';

      tabIds.forEach(function (tabId) {
        const $tab = $('#tab-content-' + tabId);
        if ($tab.length && !$tab.find('.submit').length) {
          $tab.append(submitButtonHtml);
        }
      });
    }, 200);

  });
})(jQuery);
